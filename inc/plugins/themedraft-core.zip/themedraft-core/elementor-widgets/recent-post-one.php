<?php
namespace Elementor;

class ThemeDraft_Recent_Post_One_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_recent_post_one';
	}

	public function get_title() {
		return esc_html__( 'Recent Post One', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon eicon-post-excerpt';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'recent_post_settings',
			[
				'label' => esc_html__( 'Post Settings', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'post_count',
			[
				'label'   => __( 'Number Of Post To Show', 'themedraft-core' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
				'default' => 4,
			]
		);

		$this->add_control(
			'category',
			[
				'label'       => __( 'Categories', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple'    => true,
				'options'     => themedraft_post_categories(),
			]
		);

		$this->add_control(
			'exclude_post',
			[
				'label'       => __( 'Exclude Posts', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple'    => true,
				'description' => __( 'Select post id.', 'themedraft-core' ),
				'options'     => themedraft_get_post_title_as_list(),
			]
		);


		$this->add_control(
			'post_offset',
			[
				'label'   => __( 'Post Offset', 'themedraft-core' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => '',
				'step'    => 1,
				'default' => 0,
			]
		);

		$this->add_control(
			'post_orderby',
			[
				'label'   => __( 'Order By', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => themedraft_post_orderby_options(),
				'default' => 'date',

			]
		);

		$this->add_control(
			'post_order',
			[
				'label'   => __( 'Order', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'asc'  => 'Ascending',
					'desc' => 'Descending'
				],
				'default' => 'desc',

			]
		);

		$this->add_control(
			'button_text',
			[
				'label'       => __( 'Button Text', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Read More',
			]
		);

        $this->add_control(
            'btn_icon',
            [
                'label'            => esc_html__( 'Button Icon', 'themedraft-core' ),
                'type'             => Controls_Manager::ICONS,
                'fa4compatibility' => 'icon',
                'label_block'      => true,
                'condition' => [
                    'button_text!' => '',
                ],
            ]
        );



		$this->add_control(
			'show_author',
			[
				'label'   => __( 'Show Author Name', 'themedraft-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_category',
			[
				'label'   => __( 'Show First Category Name', 'themedraft-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'no',
			]
		);

		$this->add_control(
			'show_date',
			[
				'label'   => __( 'Show Date', 'themedraft-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'title_word',
			[
				'label'   => __( 'Title Word Count', 'themedraft-core' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => '',
				'step'    => 1,
				'default' => 8,
			]
		);

		$this->add_control(
			'show_excerpt',
			[
				'label'   => __( 'Excerpt', 'themedraft-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'no',
			]
		);

		$this->add_control(
			'excerpt_length',
			[
				'label'     => __( 'Excerpt Length', 'themedraft-core' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 0,
				'max'       => '',
				'step'      => 1,
				'default'   => 21,
				'condition' => [
					'show_excerpt' => 'yes',
				]
			]
		);

        $this->add_control(
            'animation',
            [
                'label'   => __( 'Animation', 'themedraft-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => themedraft_core_get_animation_options(),
            ],
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'recent_post_slide_options_settings',
			[
				'label' => esc_html__( 'Slider Options', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'enable_slider',
			[
				'label'   => __( 'Enable Post Slider', 'themedraft-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'       => __( 'Autoplay', 'themedraft-core' ),
				'type'        => Controls_Manager::SWITCHER,
				'show_label'  => true,
				'label_block' => false,
				'default'     => 'yes',
				'condition'   => [
					'enable_slider' => 'yes',
				],
			]
		);

		$this->add_control(
			'autoplay_interval',
			[
				'label'       => __( 'Autoplay Interval', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					'2000'  => __( '2 seconds', 'themedraft-core' ),
					'3000'  => __( '3 seconds', 'themedraft-core' ),
					'4000'  => __( '4 seconds', 'themedraft-core' ),
					'5000'  => __( '5 seconds', 'themedraft-core' ),
					'6000'  => __( '6 seconds', 'themedraft-core' ),
					'7000'  => __( '7 seconds', 'themedraft-core' ),
					'8000'  => __( '8 seconds', 'themedraft-core' ),
					'9000'  => __( '9 seconds', 'themedraft-core' ),
					'10000' => __( '10 seconds', 'themedraft-core' ),
				],
				'default'     => '4000',
				'conditions'  => [
					'terms' => [
						[
							'name'     => 'enable_slider',
							'operator' => '==',
							'value'    => 'yes',
						],
						[
							'name'     => 'autoplay',
							'operator' => '==',
							'value'    => 'yes',
						]

					],
				],
			]
		);

		$this->add_control(
			'infinity_loop',
			[
				'label'       => __( 'Loop', 'themedraft-core' ),
				'type'        => Controls_Manager::SWITCHER,
				'show_label'  => true,
				'label_block' => false,
				'default'     => 'yes',
				'condition'   => [
					'enable_slider' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'recent_post_column_settings',
			[
				'label' => __( 'Post Column', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'columns_desktop',
			[
				'label'   => __( 'Columns On Desktop', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-lg-4',
				'options' => [
					'col-lg-12' => __( '1 Column', 'themedraft-core' ),
					'col-lg-6'  => __( '2 Column', 'themedraft-core' ),
					'col-lg-4'  => __( '3 Column', 'themedraft-core' ),
					'col-lg-3'  => __( '4 Column', 'themedraft-core' ),
				],
				'condition'   => [
					'enable_slider!' => 'yes',
				],
			]
		);

		$this->add_control(
			'columns_ipad_pro',
			[
				'label'   => __( 'Columns On iPad Pro', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-lg-4',
				'options' => [
					'col-lg-12' => __( '1 Column', 'themedraft-core' ),
					'col-lg-6'  => __( '2 Column', 'themedraft-core' ),
					'col-lg-4'  => __( '3 Column', 'themedraft-core' ),
					'col-lg-3'  => __( '4 Column', 'themedraft-core' ),
				],
				'condition'   => [
					'enable_slider!' => 'yes',
				],
			]
		);

		$this->add_control(
			'columns_tab',
			[
				'label'   => __( 'Columns On Tablet', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-sm-6',
				'options' => [
					'col-sm-12' => __( '1 Column', 'themedraft-core' ),
					'col-sm-6'  => __( '2 Column', 'themedraft-core' ),
					'col-sm-4'  => __( '3 Column', 'themedraft-core' ),
					'col-sm-3'  => __( '4 Column', 'themedraft-core' ),
				],
				'condition'   => [
					'enable_slider!' => 'yes',
				],
			]
		);

		$this->add_control(
			'desktop_count',
			[
				'label'       => __( 'Item Show On Desktop', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					1 => __( '1 Column', 'themedraft-core' ),
					2 => __( '2 Column', 'themedraft-core' ),
					3 => __( '3 Column', 'themedraft-core' ),
					4 => __( '4 Column', 'themedraft-core' ),
				],
				'default'     => 3,
				'condition'   => [
					'enable_slider' => 'yes',
				],
			]
		);

		$this->add_control(
			'ipad_pro_count',
			[
				'label'       => __( 'Item Show On iPad Pro', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					1 => __( '1 Column', 'themedraft-core' ),
					2 => __( '2 Column', 'themedraft-core' ),
					3 => __( '3 Column', 'themedraft-core' ),
					4 => __( '4 Column', 'themedraft-core' ),
				],
				'default'     => 3,
				'condition'   => [
					'enable_slider' => 'yes',
				],
			]
		);

		$this->add_control(
			'tab_count',
			[
				'label'       => __( 'Item Show On Tablet', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					1 => __( '1 Column', 'themedraft-core' ),
					2 => __( '2 Column', 'themedraft-core' ),
					3 => __( '3 Column', 'themedraft-core' ),
					4 => __( '4 Column', 'themedraft-core' ),
				],
				'default'     => 2,
				'condition'   => [
					'enable_slider' => 'yes',
				],
			]
		);

		$this->end_controls_section();


        $this->start_controls_section(
            'recent_post_style',
            [
                'label' => esc_html__( 'Recent Post Style', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'thumb_height',
            [
                'label' => esc_html__( 'Thumbnail Height', 'themedraft-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 200,
                        'max' => 500,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],

                'selectors' => [
                    '{{WRAPPER}} .td-recent-post-one-wrapper .td-post-thumbnail' => 'height: {{SIZE}}px;',
                ],
            ]
        );

		$this->add_responsive_control(
			'thumb_border_radius',
			[
				'label' => esc_html__( 'Thumbnail Border Radius', 'themedraft-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'%' => [
						'min' => 0,
						'max' => 50,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .td-recent-post-one-wrapper .td-post-thumbnail' => 'border-radius: {{SIZE}}px;',
				],
			]
		);

        $this->add_control(
            'meta_color',
            [
                'label'       => esc_html__('Post Meta Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-recent-post-one-wrapper .post-meta li,{{WRAPPER}} .td-recent-post-one-wrapper .post-meta li a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'meta_icon_color',
            [
                'label'       => esc_html__('Post Meta Icon Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-recent-post-one-wrapper .post-meta li i' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typo',
                'label' => esc_html__( 'Title Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .td-recent-post-one-wrapper article .post-title',
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'       => esc_html__('Title Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-recent-post-one-wrapper article .post-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'excerpt_typography',
                'label' => esc_html__( 'Excerpt Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .td-post-excerpt',
                'condition' => [
                    'show_excerpt' => 'yes',
                ],
            ]
        );

		$this->add_control(
			'excerpt_color',
			[
				'label'       => esc_html__('Excerpt Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-post-excerpt' => 'color: {{VALUE}};',
				],
				'condition' => [
					'show_excerpt' => 'yes',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'read_more_typo',
                'label' => esc_html__( 'Read More Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .td-text-button',
                'condition' => [
	                'button_text!' => '',
                ],
            ]
        );

        $this->add_control(
            'read_more_btn_color',
            [
                'label'       => esc_html__('Read More Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-text-button' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .td-text-button:hover' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'button_text!' => '',
                ],
            ]
        );

        $this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
        $slider_id = rand(100, 100000);
        if ($settings['enable_slider'] == 'yes'){
            $column = 'col-12';
        }else{
	        $column = $settings['columns_desktop'] . ' ' . $settings['columns_ipad_pro'] . ' ' . $settings['columns_tab'];
        }

		if ( ! empty( $settings['category'] ) ) {
			$post_query = new \WP_Query( array(
				'post_type'           => 'post',
				'posts_per_page'      => $settings['post_count'],
				'ignore_sticky_posts' => 1,
				'offset'              => $settings['post_offset'],
				'orderby'             => $settings['post_orderby'],
				'order'               => $settings['post_order'],
				'post__not_in'        => $settings['exclude_post'],
				'tax_query'           => array(
					array(
						'taxonomy' => 'category',
						'terms'    => $settings['category'],
						'field'    => 'slug',
					)
				)
			) );
		} else {

			$post_query = new \WP_Query(
				array(
					'posts_per_page'      => $settings['post_count'],
					'post_type'           => 'post',
					'ignore_sticky_posts' => 1,
					'offset'              => $settings['post_offset'],
					'orderby'             => $settings['post_orderby'],
					'order'               => $settings['post_order'],
					'post__not_in'        => $settings['exclude_post'],
				)
			);
		}
		?>

		<div class="td-recent-post-one-wrapper <?php echo $settings['animation'];?>">
			<div id="recent-post-wrapper-id-<?php echo $slider_id;?>" class="row">
                <?php while ( $post_query->have_posts() ) : $post_query->the_post(); ?>
				<div class="td-single-post-item <?php echo $column;?>">
                    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                        <a class="d-block" href="<?php echo esc_url( get_the_permalink() );?>">
                            <div class="td-post-thumbnail td-cover-bg" style="background-image: url(<?php the_post_thumbnail_url( 'full' ); ?>)"></div>
                        </a>

                        <div class="td-recent-post-content">
                            <div class="td-post-meta post-meta">
                                <ul class="td-list-style td-list-inline">
	                                <?php if($settings['show_author'] == 'yes' && function_exists('bizkorp_posted_by')) : ?>
                                        <li><?php bizkorp_posted_by(); ?></li>
	                                <?php endif;?>

			                        <?php if($settings['show_category'] == 'yes' && function_exists('bizkorp_post_first_category')) : ?>
                                        <li><?php bizkorp_post_first_category(); ?></li>
			                        <?php endif;?>

			                        <?php if($settings['show_date'] == 'yes') : ?>
                                        <li><?php bizkorp_posted_on(); ?></li>
			                        <?php endif;?>
                                </ul>
                            </div>

                            <div class="td-recent-post-title">
                                <a href="<?php echo esc_url( get_the_permalink() );?>">
                                    <h4 class="post-title"><?php echo wp_trim_words(get_the_title(), $settings['title_word'], ' ...');?></h4>
                                </a>
                            </div>

	                        <?php if ( $settings['show_excerpt'] === 'yes' ) : ?>
                                <div class="td-post-excerpt">
                                    <p><?php echo themedraft_get_excerpt( get_the_ID(), $settings['excerpt_length'] ); ?></p>
                                </div>
	                        <?php endif; ?>

                            <?php if ($settings['button_text']) : ?>
                            <div class="td-post-read-more">
                                <a class="td-text-button" href="<?php echo esc_url( get_the_permalink() ) ?>">
			                        <?php echo esc_html( $settings['button_text'] );
                                    themedraft_custom_icon_render( $settings, 'icon', 'btn_icon' ); ?>
                                </a>
                            </div>
                            <?php endif; ?>
                        </div>
                    </article>
                </div>
                <?php
                endwhile;
                wp_reset_query();
                ?>
			</div>

			<?php if ( $settings['enable_slider'] == 'yes' ) : ?>
                <script>
                    (function ($) {
                        "use strict";
                        $(document).ready(function () {
                            $("#recent-post-wrapper-id-<?php echo $slider_id;?>").slick({
                                slidesToShow: <?php echo json_encode( $settings['desktop_count'] )?>,
                                autoplay: <?php echo json_encode( $settings['autoplay'] == 'yes' ? true : false ); ?>,
                                autoplaySpeed: <?php echo json_encode( $settings['autoplay_interval'] )?>,
                                speed: 1500, // slide speed
                                dots: false,
                                arrows: false,
                                prevArrow: '<i class="slick-arrow slick-prev fas fa-arrow-left"></i>',
                                nextArrow: '<i class="slick-arrow slick-next fas fa-arrow-right"></i>',
                                infinite: <?php echo json_encode( $settings['infinity_loop'] == 'yes' ? true : false ); ?>,
                                pauseOnHover: false,
                                centerMode: false,
                                centerPadding: 30,
                                responsive: [
                                    {
                                        breakpoint: 1025,
                                        settings: {
                                            slidesToShow: <?php echo json_encode( $settings['ipad_pro_count'] )?>, //768-991
                                        }
                                    },
                                    {
                                        breakpoint: 992,
                                        settings: {
                                            slidesToShow: <?php echo json_encode( $settings['tab_count'] )?>, //768-991
                                        }
                                    },
                                    {
                                        breakpoint: 768,
                                        settings: {
                                            slidesToShow: 1, // 0 -767
                                        }
                                    }
                                ]
                            });
                        });
                    })(jQuery);
                </script>
			<?php endif; ?>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Recent_Post_One_Widget );