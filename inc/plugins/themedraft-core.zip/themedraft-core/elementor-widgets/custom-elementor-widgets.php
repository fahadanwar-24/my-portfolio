<?php
if (!defined('ABSPATH')) exit;
use Elementor\Controls_Manager;
require_once('controls/icons.php');
require_once ('controls/gradient-color.php');

class ThemeDraft_Elementor_Scripts
{

	public function __construct() {
		add_action('elementor/frontend/after_register_scripts', array($this, 'themedraft_core_register_scripts'));
	}

	public function themedraft_core_register_scripts() {
		wp_register_script('counterup', plugins_url('/', __FILE__) . 'assets/js/counterup.min.js', array('jquery'), '1.0', true);
	}
}

new ThemeDraft_Elementor_Scripts();


class ThemeDraft_Elementor_Custom_Widget
{

	private static $instance = null;

	public static function get_instance() {
		if (!self::$instance) {
			self::$instance = new self;
		}

		return self::$instance;
	}

	public function themedraft_add_elementor_custom_widgets() {
		require_once('accordion-one.php');
		require_once('awards.php');
		require_once('brand-image-slider.php');
		require_once('contact-info.php');
		require_once('contact-form-7.php');
		require_once('count-up-one.php');
		require_once('download-buttons.php');
		require_once('filterable-gallery-widget.php');
		require_once('gradient-button.php');
		require_once('hero-banner-one.php');
		require_once('hero-banner-two.php');
		require_once('hero-banner-three.php');
		require_once('image-one.php');
		require_once('marquee-text.php');
		require_once('pricing-table-one.php');
		require_once('project-section-one.php');
		require_once('project-slider-one.php');
		require_once('project-info-list.php');
		require_once('recent-post-one.php');
		require_once('recent-post-two.php');
		require_once('recent-post-three.php');
		require_once('section-title-one.php');
		require_once('service-one.php');
		require_once('service-two.php');
		require_once('service-features.php');
		require_once('service-slider-one.php');
		require_once('service-slider-two.php');
		require_once('tab-one.php');
		require_once('team-details.php');
		require_once('team-members-one.php');
		require_once('team-members-two.php');
		require_once('testimonial-one.php');
		require_once('testimonial-two.php');
		require_once('text-editor.php');
		require_once('top-services.php');
		require_once('video-button-one.php');
		require_once('video-popup-one.php');

		require_once('header-elements/header-template-one.php');
		require_once('footer-elements/about-company.php');
		require_once('footer-elements/contact-and-subscribe.php');
		require_once('footer-elements/copyright-text.php');
		require_once('footer-elements/footer-recent-post-one.php');
		require_once('footer-elements/quick-links.php');
	}

	public function themedraft_register_gradient_controls( Controls_Manager $controls_Manager ) {
		$foreground = 'ThemeDraft_Gradient_Color';

		$controls_Manager->add_group_control( $foreground::get_type(), new $foreground() );
	}

	public function init() {
		add_action('elementor/widgets/register', array($this, 'themedraft_add_elementor_custom_widgets'));
		add_action( 'elementor/controls/register', [ $this, 'themedraft_register_gradient_controls' ] );
	}
}

ThemeDraft_Elementor_Custom_Widget::get_instance()->init();


// Add New Category In Elementor Widget

function themedraft_elementor_widget_categories($elements_manager) {

	$elements_manager->add_category(
		'themedraft_elements',
		[
			'title' => __('ThemeDraft Elements', 'themedraft-core'),
		]
	);

	$elements_manager->add_category(
		'themedraft_header_template',
		[
			'title' => __('ThemeDraft Header Elements', 'themedraft-core'),
		]
	);

	$elements_manager->add_category(
		'themedraft_footer_elements',
		[
			'title' => __('ThemeDraft Footer Elements', 'themedraft-core'),
		]
	);

}

add_action('elementor/elements/categories_registered', 'themedraft_elementor_widget_categories');