<?php
namespace Elementor;

class ThemeDraft_Recent_Post_Three_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_recent_post_three';
	}

	public function get_title() {
		return esc_html__( 'Recent Post Three', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon eicon-post-excerpt';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'recent_post_settings',
			[
				'label' => esc_html__( 'Post Settings', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'post_count',
			[
				'label'   => __( 'Number Of Post To Show', 'themedraft-core' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
				'default' => 4,
			]
		);

		$this->add_control(
			'category',
			[
				'label'       => __( 'Categories', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple'    => true,
				'options'     => themedraft_post_categories(),
			]
		);

		$this->add_control(
			'exclude_post',
			[
				'label'       => __( 'Exclude Posts', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple'    => true,
				'description' => __( 'Select post id.', 'themedraft-core' ),
				'options'     => themedraft_get_post_title_as_list(),
			]
		);


		$this->add_control(
			'post_offset',
			[
				'label'   => __( 'Post Offset', 'themedraft-core' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => '',
				'step'    => 1,
				'default' => 0,
			]
		);

		$this->add_control(
			'post_orderby',
			[
				'label'   => __( 'Order By', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => themedraft_post_orderby_options(),
				'default' => 'date',

			]
		);

		$this->add_control(
			'post_order',
			[
				'label'   => __( 'Order', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'asc'  => 'Ascending',
					'desc' => 'Descending'
				],
				'default' => 'desc',

			]
		);

		$this->add_control(
			'button_text',
			[
				'label'       => __( 'Button Text', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Read More',
			]
		);

		$this->add_control(
			'show_author',
			[
				'label'   => __( 'Show Author Name', 'themedraft-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_category',
			[
				'label'   => __( 'Show First Category Name', 'themedraft-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'title_word',
			[
				'label'   => __( 'Title Word Count', 'themedraft-core' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => '',
				'step'    => 1,
				'default' => 8,
			]
		);

		$this->add_control(
			'show_excerpt',
			[
				'label'   => __( 'Excerpt', 'themedraft-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'excerpt_length',
			[
				'label'     => __( 'Excerpt Length', 'themedraft-core' ),
				'type'      => Controls_Manager::NUMBER,
				'min'       => 0,
				'max'       => '',
				'step'      => 1,
				'default'   => 19,
				'condition' => [
					'show_excerpt' => 'yes',
				]
			]
		);

        $this->add_control(
            'animation',
            [
                'label'   => __( 'Animation', 'themedraft-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => themedraft_core_get_animation_options(),
            ],
        );

		$this->end_controls_section();


        $this->start_controls_section(
            'recent_post_style',
            [
                'label' => esc_html__( 'Recent Post Style', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'meta_color',
            [
                'label'       => esc_html__('Post Meta Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-recent-post-three-wrapper .post-meta li,{{WRAPPER}} .td-recent-post-three-wrapper .post-meta li a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'meta_icon_color',
            [
                'label'       => esc_html__('Post Meta Icon Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-recent-post-three-wrapper .post-meta li i' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'read_more_btn_color',
            [
                'label'       => esc_html__('Read More Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-text-button' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .td-text-button:hover' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'button_text!' => '',
                ],
            ]
        );

        $this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( ! empty( $settings['category'] ) ) {
			$post_query = new \WP_Query( array(
				'post_type'           => 'post',
				'posts_per_page'      => $settings['post_count'],
				'ignore_sticky_posts' => 1,
				'offset'              => $settings['post_offset'],
				'orderby'             => $settings['post_orderby'],
				'order'               => $settings['post_order'],
				'post__not_in'        => $settings['exclude_post'],
				'tax_query'           => array(
					array(
						'taxonomy' => 'category',
						'terms'    => $settings['category'],
						'field'    => 'slug',
					)
				)
			) );
		} else {

			$post_query = new \WP_Query(
				array(
					'posts_per_page'      => $settings['post_count'],
					'post_type'           => 'post',
					'ignore_sticky_posts' => 1,
					'offset'              => $settings['post_offset'],
					'orderby'             => $settings['post_orderby'],
					'order'               => $settings['post_order'],
					'post__not_in'        => $settings['exclude_post'],
				)
			);
		}
		?>

		<div class="td-recent-post-three-wrapper">
			<div class="row">
                <?php while ( $post_query->have_posts() ) : $post_query->the_post(); ?>
				<div class="td-single-post-three-item col-xl-6 col-lg-6 col-md-6 <?php echo $settings['animation'];?>">
                    <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                        <a class="d-block td-post-three-thumbnail-wrapper" href="<?php echo esc_url( get_the_permalink() );?>">
                            <div class="td-post-three-thumbnail td-cover-bg" style="background-image: url(<?php the_post_thumbnail_url( 'full' ); ?>)"></div>
                        </a>

                        <div class="td-recent-post-three-content">
                            <div class="td-post-meta post-meta">
                                <ul class="td-list-style td-list-inline">
	                                <?php if($settings['show_author'] == 'yes' && function_exists('bizkorp_posted_by')) : ?>
                                        <li><?php bizkorp_posted_by(); ?></li>
	                                <?php endif;?>

			                        <?php if($settings['show_category'] == 'yes' && function_exists('bizkorp_post_first_category')) : ?>
                                        <li><?php bizkorp_post_first_category(); ?></li>
			                        <?php endif;?>
                                </ul>
                            </div>

                            <div class="td-recent-post-title">
                                <a href="<?php echo esc_url( get_the_permalink() );?>">
                                    <h4 class="post-three-title"><?php echo wp_trim_words(get_the_title(), $settings['title_word'], ' ...');?></h4>
                                </a>
                            </div>

	                        <?php if ( $settings['show_excerpt'] === 'yes' ) : ?>
                                <div class="td-post-three-excerpt">
                                    <p><?php echo themedraft_get_excerpt( get_the_ID(), $settings['excerpt_length'] ); ?></p>
                                </div>
	                        <?php endif; ?>

                            <?php if ($settings['button_text']) : ?>
                            <div class="td-post-read-more">
                                <a class="td-text-button" href="<?php echo esc_url( get_the_permalink() ) ?>">
			                        <?php echo esc_html( $settings['button_text'] ); ?>
                                </a>
                            </div>
                            <?php endif; ?>
                        </div>
                    </article>
                </div>
                <?php
                endwhile;
                wp_reset_query();
                ?>
			</div>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Recent_Post_Three_Widget );