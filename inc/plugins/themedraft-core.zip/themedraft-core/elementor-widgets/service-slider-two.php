<?php
namespace Elementor;
class ThemeDraft_Service_Slider_Two_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_service_slider_two';
	}

	public function get_title() {
		return esc_html__( 'Service Slider Two', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon flaticon-layers';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'service_slider_two_settings',
			[
				'label' => esc_html__( 'Service Box', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'       => __( 'Title', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 5,
				'default'     => 'Web Development',
			]
		);

		$repeater->add_control(
			'thumbnail_image',
			[
				'label'     => esc_html__( 'Image', 'themedraft-core' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'dynamic'   => [
					'active' => true,
				]
			]
		);

		$repeater->add_control(
			'details_url',
			[
				'label'         => __( 'Details Url', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'services',
			[
				'label'       => __( 'Service List', 'themedraft-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title' => 'Web Development',
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

        $this->add_control(
            'animation',
            [
                'label'   => __( 'Animation', 'themedraft-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => themedraft_core_get_animation_options(),
            ],
        );

		$this->end_controls_section();


		$this->start_controls_section(
			'service_slider_options',
			[
				'label' => esc_html__( 'Slider Options', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'desktop_count',
			[
				'label'       => __( 'Item Show On Desktop', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					1 => __( '1 Column', 'themedraft-core' ),
					2 => __( '2 Column', 'themedraft-core' ),
					3 => __( '3 Column', 'themedraft-core' ),
					4 => __( '4 Column', 'themedraft-core' ),
					5 => __( '5 Column', 'themedraft-core' ),
				],
				'default'     => 4,
			]
		);

		$this->add_control(
			'small_desktop_count',
			[
				'label'       => __( 'Item Show On Small Desktop', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					1 => __( '1 Column', 'themedraft-core' ),
					2 => __( '2 Column', 'themedraft-core' ),
					3 => __( '3 Column', 'themedraft-core' ),
					4 => __( '4 Column', 'themedraft-core' ),
					5 => __( '5 Column', 'themedraft-core' ),
				],
				'default'     => 3,
			]
		);


		$this->add_control(
			'ipad_pro_count',
			[
				'label'       => __( 'Item Show On iPad Pro', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					1 => __( '1 Column', 'themedraft-core' ),
					2 => __( '2 Column', 'themedraft-core' ),
					3 => __( '3 Column', 'themedraft-core' ),
					4 => __( '4 Column', 'themedraft-core' ),
				],
				'default'     => 2,
			]
		);

		$this->add_control(
			'tab_count',
			[
				'label'       => __( 'Item Show On Tablet', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					1 => __( '1 Column', 'themedraft-core' ),
					2 => __( '2 Column', 'themedraft-core' ),
					3 => __( '3 Column', 'themedraft-core' ),
					4 => __( '4 Column', 'themedraft-core' ),
				],
				'default'     => 2,
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label' => __( 'Autoplay', 'themedraft-core' ),
				'type' => Controls_Manager::SWITCHER,
				'show_label' => true,
				'label_block' => false,
				'default' => 'yes',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'autoplay_interval',
			[
				'label' => __( 'Autoplay Interval', 'themedraft-core' ),
				'type' => Controls_Manager::SELECT,
				'show_label' => true,
				'label_block' => false,
				'options' => [
					'2000'  => __( '2 seconds', 'themedraft-core' ),
					'3000'  => __( '3 seconds', 'themedraft-core' ),
					'4000'  => __( '4 seconds', 'themedraft-core' ),
					'5000'  => __( '5 seconds', 'themedraft-core' ),
					'6000'  => __( '6 seconds', 'themedraft-core' ),
					'7000'  => __( '7 seconds', 'themedraft-core' ),
					'8000'  => __( '8 seconds', 'themedraft-core' ),
					'9000'  => __( '9 seconds', 'themedraft-core' ),
					'10000'  => __( '10 seconds', 'themedraft-core' ),
				],
				'default' => '5000',
				'condition' => [
					'autoplay' => 'yes',
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'td_service_title_style_options',
			[
				'label' => esc_html__('Title', 'themedraft-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typo',
				'label' => esc_html__( 'Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .td-service-slider-two-title',
			]
		);

		$this->add_responsive_control(
			'title_margin',
			[
				'label'      => esc_html__( 'Margin', 'themedraft-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .td-service-slider-two-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$slider_id = rand(100, 100000);
		?>

        <div class="td-service-slider-two-wrapper">

            <div id="service-slider-id-<?php echo $slider_id;?>" class="service-slider-two">
                <?php if ( $settings['services'] ) {
                    foreach ( $settings['services'] as $service ) {
                        $details_url      = $service['details_url']['url'];
                        $target   = $service['details_url']['is_external'] ? ' target="_blank"' : '';
                        $nofollow = $service['details_url']['nofollow'] ? ' rel="nofollow"' : '';
                        ?>
                        <div class="service-slider-two-col">
                            <div class="td-single-service-slider-two-item <?php echo $settings['animation'];?>">
                                <div class="td-single-service-slider-two-item-hover"></div>
                                <div class="td-service-two-thumbnail">
                                    <?php
                                    $thumb_image_src = $service['thumbnail_image']['url'];
                                    $thumb_image_alt = get_post_meta( $service['thumbnail_image']['id'], '_wp_attachment_image_alt', true );
                                    $thumb_image_title = get_the_title( $service['thumbnail_image']['id']);
                                    ?>
                                    <img src="<?php echo $thumb_image_src;?>" alt="<?php echo $thumb_image_alt;?>" title="<?php echo $thumb_image_title;?>">
                                </div>

                                <div class="td-service-two-content">
                                    <a href="<?php echo $details_url;?>" class="service-slider-two-details-btn">
                                        <i class="flaticon-right-arrow-1"></i>
                                    </a>
                                    <div></div>
                                    <a href="<?php echo $details_url;?>">
                                        <h4 class="td-service-slider-two-title"><?php echo nl2br($service['title']);?></h4>
                                    </a>
                                </div>


                            </div>
                        </div>
                    <?php }
                } ?>
            </div>

            <script>
                (function ($) {
                    "use strict";
                    $(document).ready(function () {
                        $("#service-slider-id-<?php echo $slider_id;?>").slick({
                            slidesToShow: <?php echo json_encode( $settings['desktop_count'] )?>,
                            autoplay: <?php echo json_encode($settings['autoplay'] == 'yes' ? true : false); ?>,
                            autoplaySpeed: <?php echo json_encode($settings['autoplay_interval'])?>,
                            speed: 1500, // slide speed
                            dots: false,
                            arrows: false,
                            infinite: true,
                            pauseOnHover: false,
                            centerMode: false,
                            centerPadding: 30,
                            responsive: [
                                {
                                    breakpoint: 1281,
                                    settings: {
                                        slidesToShow: <?php echo json_encode( $settings['small_desktop_count'] )?>,
                                    }
                                },
                                {
                                    breakpoint: 1025,
                                    settings: {
                                        slidesToShow: <?php echo json_encode( $settings['ipad_pro_count'] )?>, //768-991
                                    }
                                },
                                {
                                    breakpoint: 992,
                                    settings: {
                                        slidesToShow: <?php echo json_encode( $settings['tab_count'] )?>, //768-991
                                    }
                                },
                                {
                                    breakpoint: 768,
                                    settings: {
                                        slidesToShow: 1, // 0 -767
                                    }
                                }
                            ]
                        });
                    });
                })(jQuery);
            </script>

        </div>
		<?php
	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Service_Slider_Two_Widget );