<?php
namespace Elementor;
class ThemeDraft_Testimonial_One_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_testimonial_one';
	}

	public function get_title() {
		return esc_html__( 'Testimonials One', 'themedraft-core' );
	}

	public function get_icon() {

		return 'td-icon flaticon-quotation-1';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {

		//Content tab start
		$this->start_controls_section(
			'testimonial_settings',
			[
				'label' => esc_html__( 'Testimonial One', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'author_name',
			[
				'label'       => __('Author Name', 'themedraft-core'),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Darrell Steward',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'designation',
			[
				'label'       => __('Designation', 'themedraft-core'),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'UI/UX Designer',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'photo',
			[
				'label'       => __( 'Image', 'themedraft-core' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'default'     => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'testimonial_text',
			[
				'label'   => __('Description', 'themedraft-core'),
				'type'    => Controls_Manager::WYSIWYG,
				'default' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more less normal distribution of letters, as opposed to using Content here, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their mo text, and a search for lorem ipsum will uncover many web sites still in their infancy. Various versions have evolved over the years humour and the like.',
			]
		);

		$this->add_control(
			'testimonials',
			[
				'label'       => __('Testimonial List', 'themedraft-core'),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'author_name'        => 'Darrell Steward',
						'designation'        => 'UI/UX Designer',
						'testimonial_text' => 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more less normal distribution of letters, as opposed to using Content here, making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their mo text, and a search for lorem ipsum will uncover many web sites still in their infancy. Various versions have evolved over the years humour and the like.',
					],
				],
				'title_field' => '{{{ author_name }}}',
			]
		);

		$this->add_control(
			'image_animation',
			[
				'label'   => __( 'Image Animation', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => themedraft_core_get_animation_options(),
			],
		);

		$this->add_control(
			'content_animation',
			[
				'label'   => __( 'Content Animation', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => themedraft_core_get_animation_options(),
			],
		);

        $this->add_control(
            'selected_icon',
            [
                'label'            => esc_html__( 'Testimonial Icon', 'themedraft-core' ),
                'type'             => Controls_Manager::ICONS,
                'fa4compatibility' => 'icon',
                'label_block'      => true,
                'default'          => [
                    'value'   => 'flaticon-quotation',
                    'library' => 'themedraft-bizkorp-icon',
                ],
            ]
        );

        $this->add_control(
            'star_image',
            [
                'label'       => __( 'Star Image', 'themedraft-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'slider_options',
			[
				'label' => esc_html__( 'Slider Options', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'       => __( 'Autoplay', 'themedraft-core' ),
				'type'        => Controls_Manager::SWITCHER,
				'show_label'  => true,
				'label_block' => false,
				'default'     => 'yes',
			]
		);

		$this->add_control(
			'autoplay_interval',
			[
				'label'       => __( 'Autoplay Interval', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					'2000'  => __( '2 seconds', 'themedraft-core' ),
					'3000'  => __( '3 seconds', 'themedraft-core' ),
					'4000'  => __( '4 seconds', 'themedraft-core' ),
					'5000'  => __( '5 seconds', 'themedraft-core' ),
					'6000'  => __( '6 seconds', 'themedraft-core' ),
					'7000'  => __( '7 seconds', 'themedraft-core' ),
					'8000'  => __( '8 seconds', 'themedraft-core' ),
					'9000'  => __( '9 seconds', 'themedraft-core' ),
					'10000' => __( '10 seconds', 'themedraft-core' ),
				],
				'default'     => '4000',
				'condition'   => [
					'autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'infinity_loop',
			[
				'label'       => __( 'Loop', 'themedraft-core' ),
				'type'        => Controls_Manager::SWITCHER,
				'show_label'  => true,
				'label_block' => false,
				'default'     => 'yes',
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'testimonial_style',
            [
                'label' => esc_html__( 'Testimonial', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'text_bg_color',
            [
                'label'       => esc_html__('Background Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .testimonial-one-right-content' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'text_color',
            [
                'label'       => esc_html__('Text Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .testimonial-one-text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'name_color',
            [
                'label'       => esc_html__('Name Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .testimonial-one-person-name' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'designation_color',
            [
                'label'       => esc_html__('Designation Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .testimonial-one-person-designation' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_height',
            [
                'label' => esc_html__( 'Image Height', 'themedraft-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['%'],
                'range' => [
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],

                'selectors' => [
                    '{{WRAPPER}} .testimonial-one-image' => 'height: {{SIZE}}%;',
                ],
            ]
        );

        $this->add_responsive_control(
            'text_content_padding',
            [
                'label'      => esc_html__( 'Content Padding', 'themedraft-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .testimonial-one-right-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
        $slide_id = rand(100, 100000);
		?>

        <div class="td-testimonial-one-wrapper" id="td-testimonial-slider-<?php echo esc_attr($slide_id);?>">
	        <?php if($settings['testimonials']){
	        foreach ($settings['testimonials'] as $testimonial){
                $img_src = $testimonial['photo']['url'];
                $image_alt = get_post_meta( $testimonial['photo']['id'], '_wp_attachment_image_alt', true );
                $image_title = get_the_title( $testimonial['photo']['id']);
	        ?>
            <div class="td-testimonial-one-item">
                <div class="row">
                    <div class="col-xl-4 col-lg-4 my-auto">
                        <div class="testimonial-one-image td-testimonial-big-image <?php echo $settings['image_animation'];?>">
                            <img src="<?php echo esc_url ($img_src);?>" alt="<?php echo esc_url ($image_alt);?>" title="<?php echo esc_html ($image_title);?>">
                        </div>
                    </div>

                    <div class="col-xl-8 col-lg-8">
                        <div class="testimonial-one-right-content  <?php echo $settings['content_animation'];?>">
                            <div class="testimonial-one-star-image">
                                <img src="<?php echo $settings['star_image']['url'];?>" alt="<?php echo get_post_meta( $settings['star_image']['id'], '_wp_attachment_image_alt', true );?>">
                            </div>

                            <div class="testimonial-one-text td-last-p-0">
                                <?php echo wp_kses($testimonial['testimonial_text'], bizkorp_allow_html());?>
                            </div>
                            <div class="testimonial-one-person">
                                <div class="testimonial-one-image td-testimonial-small-image">
                                    <img src="<?php echo esc_url ($img_src);?>" alt="<?php echo esc_url ($image_alt);?>" title="<?php echo esc_html ($image_title);?>">
                                </div>

                                <span class="testimonial-one-person-name"><?php echo esc_html($testimonial['author_name']);?></span>
                                <span class="testimonial-one-person-designation"><?php echo esc_html($testimonial['designation']);?></span>
                            </div>

                            <div class="td-testimonial-one-icon">
		                        <?php themedraft_custom_icon_render( $settings, 'icon', 'selected_icon' );?>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
		        <?php
	        }
	        } ?>
        </div>

        <script>
            (function ($) {
                "use strict";
                $(document).ready(function () {
                    $("#td-testimonial-slider-<?php echo esc_attr($slide_id);?>").slick({
                        slidesToShow: 1,
                        autoplay: <?php echo json_encode( $settings['autoplay'] == 'yes' ? true : false ); ?>,
                        autoplaySpeed: <?php echo json_encode( $settings['autoplay_interval'] )?>, //interval
                        speed: 1500, // slide speed
                        dots: false,
                        arrows: false,
                        fade: true,
                        infinite: <?php echo json_encode( $settings['infinity_loop'] == 'yes' ? true : false ); ?>,
                        pauseOnHover: false,
                        centerMode: false,
                    });
                });
            })(jQuery);
        </script>

		<?php
	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Testimonial_One_Widget );