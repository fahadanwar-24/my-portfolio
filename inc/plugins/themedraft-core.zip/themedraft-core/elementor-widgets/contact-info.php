<?php
namespace Elementor;

class ThemeDraft_Contact_Info_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_contact_info';
	}

	public function get_title() {
		return esc_html__( 'Contact Info', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon flaticon-customer-service';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'footer_contact_info_options',
			[
				'label' => esc_html__( 'Contact Info', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'widget_title',
			[
				'label'       => __( 'Widget Title', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Feel Free to contact with us',
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
            'info_title',
            [
                'label'       => esc_html__( 'Title', 'themedraft-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => esc_html__( 'Call Us', 'themedraft-core' ),
                'placeholder' => esc_html__( '', 'themedraft-core' ),
            ]
        );

		$repeater->add_control(
			'selected_icon',
			[
				'label'            => esc_html__( 'Select Icon', 'themedraft-core' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'flaticon-phone-call-1',
					'library' => 'bizkorp-icon',
				],
			]
		);

		$repeater->add_control(
            'desc',
            [
                'label'       => __( 'Description', 'themedraft-core' ),
                'type'        => Controls_Manager::WYSIWYG,
                'default'     => '175 10th Street, Office 375 Berlin, Devonian 21562',
                'label_block' => true,
            ]
        );


		$this->add_control(
			'info_items',
			[
				'label'       => __( 'Info List', 'themedraft-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),

				'default'     => [
					[
						'selected_icon' => 'fas fa-map-marker-alt',
						'desc' => '175 10th Street, Office 375 Berlin, Devonian 21562',
					],
				],
				'title_field' => '<i class="{{{selected_icon.value}}}"></i>'.'{{{ info_title }}}',
			]
		);

        $this->add_control(
            'image',
            [
                'label'       => esc_html__( 'Background Image', 'themedraft-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

		$this->end_controls_section();

        $this->start_controls_section(
            'contact_info_style',
            [
                'label' => esc_html__( 'Contact Info', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'widget_title_color',
            [
                'label'       => esc_html__('Title Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .contact-info-one-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'info_icon_color',
            [
                'label'       => esc_html__('Info Icon Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .contact-info-one-list li .contact-info-one-icon i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .contact-info-one-list li .contact-info-one-icon svg path' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'info_text_color',
            [
                'label'       => esc_html__('Info Text Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .contact-info-one .contact-info-one-list li,{{WRAPPER}} .contact-info-one .contact-info-one-list li a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'overlay_background',
                'label' => esc_html__( 'Background', 'themedraft-core' ),
                'types' => [ 'gradient' ],
                'selector' => '{{WRAPPER}} .td-contact-info-wrapper-overlay',
            ]
        );

        $this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<div class="contact-info-one" style="background-image: url(<?php echo $settings['image']['url'];?>)">
            <div class="td-contact-info-wrapper-overlay"></div>
            <h4 class="contact-info-one-title"><?php echo $settings['widget_title'];?></h4>

            <div class="td-contact-info-wrapper">
                <ul class="td-list-style contact-info-one-list">
	                <?php if ($settings['info_items']) {
		                foreach ($settings['info_items'] as $info_item) { ?>
                        <li>
                            <div class="contact-info-one-icon">
                                <?php themedraft_custom_icon_render( $info_item, 'icon', 'selected_icon' );?>
                            </div>
                            <div>
                                <div class="info-one-title-desc">
	                                <div class="contact-info-one-info-title"><?php echo $info_item['info_title'];?></div>
	                                <div class="contact-info-one-info-desc td-last-p-0">
		                                <?php echo $info_item['desc'];?>
                                    </div>
                                </div>
                            </div>
                        </li>
		                <?php }
	                } ?>
                </ul>
            </div>
		</div>
		<?php
	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Contact_Info_Widget );