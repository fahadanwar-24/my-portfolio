<?php
namespace Elementor;

class ThemeDraft_Recent_Post_Two_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_recent_post_two';
	}

	public function get_title() {
		return esc_html__( 'Recent Post Two', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon eicon-post-excerpt';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'recent_post_settings',
			[
				'label' => esc_html__( 'Post Settings', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'post_count',
			[
				'label'   => __( 'Number Of Post To Show', 'themedraft-core' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 12,
				'step'    => 1,
				'default' => 4,
			]
		);

		$this->add_control(
			'category',
			[
				'label'       => __( 'Categories', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple'    => true,
				'options'     => themedraft_post_categories(),
			]
		);

		$this->add_control(
			'post_offset',
			[
				'label'   => __( 'Post Offset', 'themedraft-core' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => '',
				'step'    => 1,
				'default' => 0,
			]
		);

		$this->add_control(
			'post_orderby',
			[
				'label'   => __( 'Order By', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => themedraft_post_orderby_options(),
				'default' => 'date',

			]
		);

		$this->add_control(
			'post_order',
			[
				'label'   => __( 'Order', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'asc'  => 'Ascending',
					'desc' => 'Descending'
				],
				'default' => 'desc',

			]
		);

		$this->add_control(
			'comment_count',
			[
				'label'     => esc_html__( 'Comment Count', 'themedraft-core' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Yes', 'themedraft-core' ),
				'label_off' => esc_html__( 'No', 'themedraft-core' ),
				'default'   => 'yes',
			]
		);

		$this->add_control(
			'show_author',
			[
				'label'   => __( 'Show Author', 'themedraft-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'show_first_cat',
			[
				'label'   => __( 'First Category', 'themedraft-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'title_word',
			[
				'label'   => __( 'Title Word Count', 'themedraft-core' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => '',
				'step'    => 1,
				'default' => 10,
			]
		);

		$this->add_control(
			'details_btn_text',
			[
				'label'       => esc_html__( 'Details Button Text', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => esc_html__( 'Read More', 'themedraft-core' ),
			]
		);

        $this->add_control(
            'animation',
            [
                'label'   => __( 'Animation', 'themedraft-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => themedraft_core_get_animation_options(),
            ],
        );
		$this->end_controls_section();

		$this->start_controls_section(
			'recent_post_style',
			[
				'label' => esc_html__( 'Post Style', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'icon_color',
			[
				'label'     => esc_html__( 'Icon Color', 'themedraft-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-meta li i,{{WRAPPER}} .post-meta li a:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_bg_color',
			[
				'label'     => esc_html__( 'Button Background Color', 'themedraft-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .td-post-meta-and-button .td-icon-button' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_hover_bg_color',
			[
				'label'     => esc_html__( 'Button Hover Background Color', 'themedraft-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .td-post-meta-and-button .td-icon-button:hover' => 'background-color: {{VALUE}};',
				],
			]
		);


		$this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( ! empty( $settings['category'] ) ) {
			$post_query = new \WP_Query( array(
				'post_type'           => 'post',
				'posts_per_page'      => $settings['post_count'],
				'ignore_sticky_posts' => 1,
				'offset'              => $settings['post_offset'],
				'orderby'             => $settings['post_orderby'],
				'order'               => $settings['post_order'],
				'tax_query'           => array(
					array(
						'taxonomy' => 'category',
						'terms'    => $settings['category'],
						'field'    => 'slug',
					)
				)
			) );
		} else {

			$post_query = new \WP_Query(
				array(
					'posts_per_page'      => $settings['post_count'],
					'post_type'           => 'post',
					'ignore_sticky_posts' => 1,
					'offset'              => $settings['post_offset'],
					'orderby'             => $settings['post_orderby'],
					'order'               => $settings['post_order'],
				)
			);
		}
		?>

        <div class="td-recent-post-two-wrapper">

			<?php
			$counter = 0;
			$group = [];

			while ($post_query->have_posts()) : $post_query->the_post();
				$group[] = get_post();
				$counter++;

				// Render every group of 4 or at the end of the loop
				if ($counter % 4 === 0 || $counter === $post_query->post_count) :

					// Big Post
					$big_post = $group[0];
					global $post;
					$post = $big_post;
					setup_postdata($post);
					?>

                    <div class="row">
                        <div class="col-xl-6">
                            <div class="recent-post-two-item recent-post-two-big-item <?php echo $settings['animation'];?>">
                                <a class="post-thumb-url" href="<?php echo esc_url(get_permalink($big_post)); ?>">
                                    <div class="td-post-thumbnail td-cover-bg"
                                         style="background-image: url(<?php echo get_the_post_thumbnail_url($big_post, 'full'); ?>)">
                                    </div>
                                </a>


                                <div class="td-post-meta post-meta">
                                    <ul class="td-list-style td-list-inline">
										<?php if ($settings['show_author'] == 'yes' && function_exists('bizkorp_posted_by')) : ?>
                                            <li><?php bizkorp_posted_by(); ?></li>
										<?php endif; ?>

										<?php if ($settings['comment_count'] == 'yes' && get_comments_number() > 0 && function_exists('bizkorp_comment_count')) : ?>
                                            <li class="comment-number"><?php bizkorp_comment_count(); ?></li>
										<?php endif; ?>

										<?php if($settings['show_first_cat'] == 'yes') :
											// Display first category link
											$categories = get_the_category();
											if ( ! empty($categories) ) :
												$first_category = $categories[0]; ?>
                                                <li>
                                                    <span class="cat-links">
                                                        <i class="far fa-folder"></i>
                                                        <a href="<?php echo esc_url(get_category_link($first_category->term_id)); ?>">
				                                            <?php echo esc_html($first_category->name); ?>
                                                        </a>
                                                    </span>
                                                </li>
											<?php endif; endif; ?>
                                    </ul>
                                </div>

                                <div class="td-recent-post-title">
                                    <a href="<?php echo esc_url(get_permalink($big_post)); ?>">
                                        <h4 class="post-title">
											<?php echo wp_trim_words(get_the_title($big_post), $settings['title_word'], ' ...'); ?>
                                        </h4>
                                    </a>
                                </div>

                                <div class="td-recent-post-button">
                                    <a class="td-button td-gradient-button"  href="<?php echo esc_url(get_permalink($big_post)); ?>">
                                        <span><?php echo $settings['details_btn_text'];?></span>
                                    </a>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-6">
							<?php for ($i = 1; $i < count($group); $i++) :
								$small_post = $group[$i];
								global $post;
								$post = $small_post;
								setup_postdata($post);
								?>
                                <div class="recent-post-two-item recent-post-two-small-item <?php echo $settings['animation'];?>">
                                    <a class="post-thumb-url"  href="<?php echo esc_url(get_permalink($small_post)); ?>">
                                        <div class="td-post-thumbnail td-cover-bg"
                                             style="background-image: url(<?php echo get_the_post_thumbnail_url($small_post, 'full'); ?>)">
                                        </div>
                                    </a>

                                    <div class="post-small-content">
                                        <div class="td-post-meta post-meta">
                                            <ul class="td-list-style td-list-inline">
												<?php if ($settings['show_author'] === 'yes' && function_exists('bizkorp_posted_by')) : ?>
                                                    <li><?php bizkorp_posted_by(); ?></li>
												<?php endif; ?>

												<?php if ($settings['comment_count'] == 'yes' && get_comments_number() > 0 && function_exists('bizkorp_comment_count')) : ?>
                                                    <li class="comment-number"><?php bizkorp_comment_count(); ?></li>
												<?php endif; ?>

												<?php if($settings['show_first_cat'] == 'yes') :
													// Display first category link
													$categories = get_the_category();
													if ( ! empty($categories) ) :
														$first_category = $categories[0]; ?>
                                                        <li>
                                                    <span class="cat-links">
                                                        <i class="far fa-folder"></i>
                                                        <a href="<?php echo esc_url(get_category_link($first_category->term_id)); ?>">
				                                            <?php echo esc_html($first_category->name); ?>
                                                        </a>
                                                    </span>
                                                        </li>
													<?php endif; endif;?>
                                            </ul>
                                        </div>

                                        <div class="td-recent-post-title">
                                            <a href="<?php echo esc_url(get_permalink($small_post)); ?>">
                                                <h4 class="post-title">
													<?php echo wp_trim_words(get_the_title($small_post), $settings['title_word'], ' ...'); ?>
                                                </h4>
                                            </a>
                                        </div>

                                        <div class="td-recent-post-button">
                                            <a class="td-button td-gradient-button" href="<?php echo esc_url(get_permalink($small_post)); ?>">
												<span><?php echo $settings['details_btn_text'];?></span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
							<?php endfor; ?>
                        </div>
                    </div>

					<?php
					wp_reset_postdata(); // Reset after each group
					$group = []; // Clear group for next batch
				endif;

			endwhile;
			?>


        </div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Recent_Post_Two_Widget );