<?php
namespace Elementor;
use ThemeDraft_Gradient_Color;
class ThemeDraft_Video_Button_One_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_video_button_one';
	}

	public function get_title() {
		return esc_html__( 'Video Button', 'themedraft-core' );
	}

	public function get_icon() {

		return 'eicon-youtube td-icon';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'video_popup_options',
			[
				'label' => esc_html__( 'Video', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'video_btn_text',
			[
				'label' => __( 'Video Button Text', 'themedraft-core' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'default' => 'Watch Video',
			]
		);

		$this->add_control(
			'video_url',
			[
				'label'       => __( 'Video URL', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'https://vimeo.com/100902001',
			]
		);

		$this->add_control(
			'animation',
			[
				'label'   => __( 'Animation', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => themedraft_core_get_animation_options(),
			],
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'video_popup_style',
			[
				'label' => esc_html__( 'Video', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'btn_size',
			[
				'label' => esc_html__( 'Button Size', 'themedraft-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 50,
						'max' => 250,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .video-btn-one-icon' => 'line-height: {{SIZE}}px;height: {{SIZE}}px;width: {{SIZE}}px;',
				],
			]
		);

		$this->add_responsive_control(
			'btn_icon_size',
			[
				'label' => esc_html__( 'Play Icon Size', 'themedraft-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 15,
						'max' => 50,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .video-btn-one-icon i' => 'font-size: {{SIZE}}px;',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'btn_text_typo',
				'label' => esc_html__( 'Text Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .td-video-button-one-text',
			]
		);

        $this->add_control(
            'btn+text_color',
            [
                'label'       => esc_html__('Text Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-video-button-one-text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'btn_background',
                'label' => esc_html__( 'Background', 'themedraft-core' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .video-btn-one-icon',
                'exclude' => ['image'],
            ]
        );

		$this->add_control(
			'btn_color',
			[
				'label'       => esc_html__('Play Icon Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .video-btn-one-icon i' => 'color: {{VALUE}};',
				],
			]
		);

        $this->add_control(
            'btn_border_color',
            [
                'label'       => esc_html__('Border Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .video-btn-one-icon' => 'border-color: {{VALUE}};',
                ],
            ]
        );

		$this->add_control(
			'close_icon_bg_color',
			[
				'label'       => esc_html__('Popup Close Background', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
			]
		);

		$this->add_control(
			'close_icon_cross_color',
			[
				'label'       => esc_html__('Popup Close Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
			]
		);

		$this->add_responsive_control(
			'btn_margin',
			[
				'label'      => esc_html__( 'Margin', 'themedraft-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .td-video-button-one-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<div class="td-video-button-one-wrapper <?php echo $settings['animation'];?>">
			<a href="<?php echo esc_url($settings['video_url']);?>" class="td-video-button-one mfp-iframe">
				<span class="video-btn-one-icon">
                    <i class="fas fa-play"></i>
                </span>
				<span class="td-video-button-one-text"><?php echo esc_html($settings['video_btn_text']);?></span>
			</a>
		</div>


		<script>
            jQuery(document).ready(function ($) {
                $(".td-video-button-one").magnificPopup({
                    type: 'video',
                    mainClass: 'td-mfp-<?php echo $this->get_id();?>',
                });
            });
		</script>

		<?php if ($settings['close_icon_bg_color']) :?>
			<style>
                .td-mfp-<?php echo $this->get_id();?> .mfp-close{
                    background-color: <?php echo $settings['close_icon_bg_color'];?>;
                    color: <?php echo $settings['close_icon_cross_color'];?>;

                }
			</style>
		<?php endif; ?>

		<?php

	}


}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Video_Button_One_Widget );