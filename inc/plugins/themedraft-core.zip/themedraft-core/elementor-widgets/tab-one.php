<?php
namespace Elementor;
class ThemeDraft_Tab_One_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_tab_one';
	}

	public function get_title() {
		return esc_html__( 'Tabs One', 'themedraft-core' );
	}

	public function get_icon() {

		return 'td-icon eicon-tabs';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'tab_content_settings',
			[
				'label' => esc_html__( 'Tabs', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'menu_text',
			[
				'label'       => esc_html__('Menu Text', 'themedraft-core'),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Menu 1',
				'label_block' => true,
			]
		);


		$repeater->add_control(
			'content_text',
			[
				'label'   => esc_html__('Content Text', 'themedraft-core'),
				'type'    => Controls_Manager::WYSIWYG,
				'default' => '<p>It is a long established fact that is reader will be then distracted buy then thing and readable content off page when looking at that page layout. It is a long fact that on readable content of page. It is a long established fact that is reader will be the then distracted by the thing and readable content then page when looking at our and on established fact that page layout and more.</p>',
			]
		);

		$this->add_control(
			'tab_items',
			[
				'label'       => esc_html__('Tab List', 'themedraft-core'),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'menu_text'        => 'Menu 1',
						'content_text' => '<p>It is a long established fact that is reader will be then distracted by the thing and readable content off page when looking at that page layout. It is a long fact that a readable content of page. It is a long established fact that is reader will be the then distracted by the thing and readable content then page when looking at our established fact that page layout.</p>',
					],
				],
				'title_field' => '{{{ menu_text }}}',
			]
		);

		$this->add_control(
			'open_by_default',
			[
				'label'       => esc_html__('Open By Default', 'themedraft-core'),
				'type'        => Controls_Manager::NUMBER,
				'min'         => 1,
				'max'         => 1000,
				'step'        => 1,
				'default'     => 1,
				'description' => esc_html__('Which tab you want to open by default.', 'themedraft-core'),
			]
		);

        $this->add_control(
            'animation',
            [
                'label'   => __( 'Animation', 'themedraft-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => themedraft_core_get_animation_options(),
            ],
        );

		$this->end_controls_section();


        // Start Button section
        $this->start_controls_section(
            'bizkorp_tab_style',
            [
                'label' => esc_html__('Bizkorp Tabs', 'themedraft-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'tab_btn_typo',
                'label' => esc_html__( 'Tab Button Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .td-bizkorp-tab-wrapper .nav-tabs .nav-link',
            ]
        );

        $this->start_controls_tabs('td_button_style_tabs');

        //Default style tab start
        $this->start_controls_tab(
            'td_btn_style_default',
            [
                'label' => esc_html__('Default', 'themedraft-core'),
            ]
        );

        $this->add_control(
            'button_default_bg',
            [
                'label'       => esc_html__('Nav Button Background', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-bizkorp-tab-wrapper .nav-link' => 'background-color: {{VALUE}};',
                ],
            ]
        );

		$this->add_control(
			'button_default_color',
			[
				'label'       => esc_html__('Nav Button Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-bizkorp-tab-wrapper .nav-link' => 'color: {{VALUE}};',
				],
			]
		);


        $this->end_controls_tab();//Default style tab end

        //Hover style tab start
        $this->start_controls_tab(
            'td_btn_style_hover',
            [
                'label' => esc_html__('Hover', 'themedraft-core'),
            ]
        );

		$this->add_control(
			'button_hover_bg',
			[
				'label'       => esc_html__('Nav Button Background', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-bizkorp-tab-wrapper .nav-tabs .nav-item.show .nav-link,
					{{WRAPPER}} .td-bizkorp-tab-wrapper .nav-tabs .nav-link.active,{{WRAPPER}} .td-bizkorp-tab-wrapper .nav-tabs .nav-link:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_hover_color',
			[
				'label'       => esc_html__('Nav Button Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-bizkorp-tab-wrapper .nav-tabs .nav-item.show .nav-link,
					{{WRAPPER}} .td-bizkorp-tab-wrapper .nav-tabs .nav-link.active,{{WRAPPER}} .td-bizkorp-tab-wrapper .nav-tabs .nav-link:hover' => 'color: {{VALUE}};',
				],
			]
		);


        $this->end_controls_tabs();//Hover style tab end

        $this->add_control(
            'list_icon_color',
            [
                'label'       => esc_html__('List Icon Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'separator' => 'before',
                'selectors'   => [
                    '{{WRAPPER}} .td-bizkorp-tab-wrapper div.td-text-wrapper ul li:before' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();// End Button section
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$td_tab_id = rand(10, 10000);
		?>

		<div class="td-bizkorp-tab-wrapper <?php echo $settings['animation'];?>">
            <div class="nav nav-tabs" role=tablist>
                <?php
                if ($settings['tab_items']) {
                    $menu_count = 0;
                    foreach ($settings['tab_items'] as $tab_menu) {
                        $menu_count++;
                        ?>
                        <button class="nav-link <?php if($menu_count == $settings['open_by_default']){ echo 'active';}?>" data-bs-toggle="tab" data-bs-target="#td-tab-number-<?php echo $td_tab_id.$menu_count?>" type="button" role="tab">
                            <?php echo $tab_menu['menu_text'];?>
                        </button>
                    <?php }
                }
                ?>
            </div>

            <div class="tab-content">
                <?php
                if ($settings['tab_items']) {
                    $content_count = 0;
                    foreach ($settings['tab_items'] as $tab_content) {
                        $content_count++;
                        ?>
                            <div class="td-tab-item tab-pane fade <?php if($content_count == $settings['open_by_default'] ){ echo 'active show';}?>" id="td-tab-number-<?php echo $td_tab_id.$content_count?>" role="tabpanel">
                                <div class="td-text-wrapper">
	                                <?php echo $tab_content['content_text'];?>
                                </div>
                            </div>
                        <?php
                    }
                }
                ?>
            </div>

		</div>

		<?php
	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Tab_One_Widget );