<?php
namespace Elementor;
use WP_Query;

class ThemeDraft_Team_Member_Two_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_team_member_two';
	}

	public function get_title() {
		return esc_html__( 'Team Member Two', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon flaticon-customer-service';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'team_two_options',
			[
				'label' => esc_html__( 'Team Members', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'member_name',
			[
				'label'       => __( 'Member Name', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Darlene Robertson',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'designation',
			[
				'label'       => __( 'Designation', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Web Designer',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'image',
			[
				'label'       => __( 'Member Image', 'themedraft-core' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'default'     => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'selected_member_profile',
			[
				'label'       => __( 'Details Link', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'default'     => '',
				'options'     => themedraft_team_member_list(),
				'description' => esc_html__( 'Select member name to associate his/her details page link.', 'themedraft-core' ),
			]
		);

		$this->add_control(
			'members',
			[
				'label'       => __( 'Members List', 'themedraft-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'member_name' => 'Darlene Robertson',
						'designation' => 'Web Designer',
					],
				],
				'title_field' => '{{{ member_name }}}',
			]
		);

        $this->add_control(
            'animation',
            [
                'label'   => __( 'Animation', 'themedraft-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => themedraft_core_get_animation_options(),
            ],
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'team_member_column',
			[
				'label' => esc_html__( 'Column', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'xl_col',
			[
				'label'   => __( 'Columns On Desktop', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-xl-4',
				'options' => [
					'col-xl-12' => __( '1 Column', 'themedraft-core' ),
					'col-xl-6'  => __( '2 Column', 'themedraft-core' ),
					'col-xl-4'  => __( '3 Column', 'themedraft-core' ),
					'col-xl-3'  => __( '4 Column', 'themedraft-core' ),
				],
			]
		);

		$this->add_control(
			'lg_col',
			[
				'label'   => __( 'Columns On iPad Pro', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-lg-4',
				'options' => [
					'col-lg-12' => __( '1 Column', 'themedraft-core' ),
					'col-lg-6'  => __( '2 Column', 'themedraft-core' ),
					'col-lg-4'  => __( '3 Column', 'themedraft-core' ),
					'col-lg-3'  => __( '4 Column', 'themedraft-core' ),
				],
			]
		);

		$this->add_control(
			'md_col',
			[
				'label'   => __( 'Columns On iPad', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-md-6',
				'options' => [
					'col-md-12' => __( '1 Column', 'themedraft-core' ),
					'col-md-6'  => __( '2 Column', 'themedraft-core' ),
					'col-md-4'  => __( '3 Column', 'themedraft-core' ),
					'col-md-3'  => __( '4 Column', 'themedraft-core' ),
				],
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'team_style_options',
            [
                'label' => esc_html__( 'Team Members', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'name_typo',
                'label' => esc_html__( 'Name Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .td-member-two-name',
            ]
        );

        $this->add_control(
            'name_color',
            [
                'label'       => esc_html__('Name Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-member-two-name' => 'color: {{VALUE}};',
                ],
            ]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'designation_typo',
				'label' => esc_html__( 'Designation Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .td-member-two-designation',
			]
		);

        $this->add_control(
            'designation_color',
            [
                'label'       => esc_html__('Designation Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-member-two-designation' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'text_align',
            [
                'label'       => esc_html__('Text Align', 'themedraft-core'),
                'type'        => Controls_Manager::CHOOSE,
                'label_block' => false,

                'options' => [
                    'left' => [
                        'title' => __('Left', 'themedraft-core'),
                        'icon'  => 'eicon-text-align-left',
                    ],

                    'center' => [
                        'title' => __('Center', 'themedraft-core'),
                        'icon'  => 'eicon-text-align-center',
                    ],

                    'right' => [
                        'title' => __('Right', 'themedraft-core'),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],

                'devices' => ['desktop', 'tablet', 'mobile'],

                'selectors' => [
                    '{{WRAPPER}} .td-single-team-member-two' => 'text-align: {{VALUE}};',
                ],

            ]
        );

        $this->add_responsive_control(
            'team_item_margin',
            [
                'label'      => esc_html__( 'Item Margin', 'themedraft-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .td-single-team-member-two' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_size',
            [
                'label' => esc_html__( 'Image Size', 'themedraft-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 250,
                        'max' => 500,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],

                'selectors' => [
                    '{{WRAPPER}} .td-member-two-image' => 'width: {{SIZE}}px;height: {{SIZE}}px;',
                ],
            ]
        );

        $this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$col = $settings['xl_col'] . ' ' . $settings['lg_col'] . ' ' . $settings['md_col'];
		?>

		<div class="row">
			<?php
			if ( $settings['members'] ) {
				foreach ( $settings['members'] as $member ) {
					$image_src   = $member['image']['url'];
					$image_alt   = get_post_meta( $member['image']['id'], '_wp_attachment_image_alt', true );
					$image_title = get_the_title( $member['image']['id'] );
					$name        = $member['member_name'];
					$designation = $member['designation'];

					$member_query = new WP_Query(
						array(
							'posts_per_page' => 1,
							'post_type'      => 'bizkorp_team',
							'p'              => $member['selected_member_profile'],
						)
					);

					while ( $member_query->have_posts() ) :
						$member_query->the_post();
						if ( get_post_meta( get_the_ID(), 'bizkorp_team_meta', true ) ) {
							$team_meta = get_post_meta( get_the_ID(), 'bizkorp_team_meta', true );
						} else {
							$team_meta = array();
						}

						if ( array_key_exists( 'member_social_profile', $team_meta ) ) {
							$member_social = $team_meta['member_social_profile'];
						} else {
							$member_social = array();
						}
						?>
						<div class="<?php echo $col;?>">
							<div class="td-single-team-member-two <?php echo $settings['animation'];?>">
                                <div class="td-member-two-image">
									<?php if ( $member['selected_member_profile'] ) : ?>
                                    <a class="td-member-details-url" href="<?php the_permalink(); ?>">
										<?php endif; ?>
                                        <img src="<?php echo $image_src; ?>" alt="<?php echo $image_alt; ?>"
                                             title="<?php echo $image_title; ?>">
										<?php if ( $member['selected_member_profile'] ) : ?>
                                    </a>
								    <?php endif; ?>

	                                <?php if ( $member['selected_member_profile'] ) : ?>
                                        <div class="td-team-member-two-social">
                                            <ul class="td-list-style td-list-inline">
				                                <?php
				                                foreach ( $member_social as $social ) {
					                                $icon = $social['site_icon'];
					                                $url  = $social['profile_url']; ?>
                                                    <li>
                                                        <a target="_blank" href="<?php echo esc_url($url); ?>">
                                                            <i class="<?php echo $icon; ?>"></i>
                                                        </a>
                                                    </li>
					                                <?php
				                                }
				                                ?>
                                            </ul>
                                        </div>
	                                <?php endif; ?>
                                </div>

                                <div class="td-team-two-member-info">
                                    <h3 class="td-member-two-name"><?php echo $name;?></h3>
                                    <span class="td-member-two-designation"><?php echo $designation;?></span>
                                </div>
							</div>
						</div>
					<?php
					endwhile;
					wp_reset_query();
				}
			}
			?>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Team_Member_Two_Widget );