<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class ThemeDraft_Project_Info_List_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_project_info_list';
	}

	public function get_title() {
		return __( 'Project Info List', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon eicon-bullet-list';
	}
	public function get_categories() {
		return array( 'themedraft_elements' );
	}

	protected function register_controls() {

		$this->start_controls_section(
			'project_info_list_options',
			[
				'label'     => esc_html__( 'List', 'themedraft-core' ),
				'tab'       => Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
            'main_title',
            [
                'label'       => esc_html__( 'Title', 'themedraft-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => esc_html__( 'Project Info', 'themedraft-core' ),
            ]
        );

		$this->add_control(
		    'list',
		    [
		        'label'       => esc_html__( 'List', 'themedraft-core' ),
		        'type'        => Controls_Manager::WYSIWYG,
		        'default'     => '
		            <ul>
		                <li><strong>Clients:</strong>Md Nadim Khan</li>
		                <li><strong>Services:</strong>Web Development</li>
		                <li><strong>Category:</strong>Web SEO</li>
		                <li><strong>Date:</strong>15 May 2025</li>
		                <li><strong>Location:</strong>New York</li>
                    </ul>
		        ',
		        'description' => esc_html__( 'Create List Here', 'themedraft-core' ),
		        'label_block' => true,
		    ]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'info_list_style',
            [
                'label' => esc_html__( 'Info List', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'bg_color',
            [
                'label'       => esc_html__('Background Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .project-info-list-wrapper' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'border_color',
            [
                'label'       => esc_html__('Border Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .project-info-list ul li' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'wrapper_margin',
            [
                'label'      => esc_html__( 'Wrapper Margin', 'themedraft-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .project-info-list-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

	}

	protected function render()  {
		$settings = $this->get_settings();
		?>
			<div class="project-info-list-wrapper">
			    <h4 class="project-info-title"><?php echo $settings['main_title'];?></h4>

                <div class="project-info-list">
                    <?php echo $settings['list'];?>
                </div>
			</div>
		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Project_Info_List_Widget );