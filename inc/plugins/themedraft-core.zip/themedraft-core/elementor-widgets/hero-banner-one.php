<?php
namespace Elementor;
use ThemeDraft_Gradient_Color;
class ThemeDraft_Hero_Banner_One_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_hero_banner_one';
	}

	public function get_title() {
		return esc_html__( 'Hero Banner One', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon flaticon-flag';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'hero_banner_content',
			[
				'label' => esc_html__( 'Banner Content', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
		    'subtitle',
		    [
		        'label'       => __( 'Subtitle', 'themedraft-core' ),
		        'type'        => Controls_Manager::TEXTAREA,
		        'rows'        => 5,
		        'default'     => 'A brief supporting statement',
		    ]
		);

		$this->add_control(
		    'title_one',
		    [
		        'label'       => __( 'Title One', 'themedraft-core' ),
		        'type'        => Controls_Manager::TEXTAREA,
		        'rows'        => 5,
		        'default'     => 'We Are Next Gen',
		    ]
		);

		$this->add_control(
			'title_one_tag',
			[
				'label'   => __( 'Title One Tag', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => [
					'h1' => __( 'H1', 'themedraft-core' ),
					'h2' => __( 'H2', 'themedraft-core' ),
					'h3' => __( 'H3', 'themedraft-core' ),
					'h4' => __( 'H4', 'themedraft-core' ),
					'h5' => __( 'H5', 'themedraft-core' ),
					'h6' => __( 'H6', 'themedraft-core' ),
					'span' => __( 'SPAN', 'themedraft-core' ),
				],
				'condition' => [
					'title_one!' => '',
				],
			]
		);

		$this->add_control(
			'title_two',
			[
				'label'       => __( 'Title Two', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 5,
				'default'     => 'Creative Agency.',
			]
		);

		$this->add_control(
			'title_two_tag',
			[
				'label'   => __( 'Title Two Tag', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => [
					'h1' => __( 'H1', 'themedraft-core' ),
					'h2' => __( 'H2', 'themedraft-core' ),
					'h3' => __( 'H3', 'themedraft-core' ),
					'h4' => __( 'H4', 'themedraft-core' ),
					'h5' => __( 'H5', 'themedraft-core' ),
					'h6' => __( 'H6', 'themedraft-core' ),
					'span' => __( 'SPAN', 'themedraft-core' ),
				],
				'condition' => [
					'title_two!' => '',
				],
			]
		);

		$this->add_control(
			'insert_image',
			[
				'label'     => esc_html__( 'Insert Image', 'themedraft-core' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Yes', 'themedraft-core' ),
				'label_off' => esc_html__( 'No', 'themedraft-core' ),
				'default'   => 'yes',
			]
		);

		$this->add_control(
			'title_two_image',
			[
				'label'       => __( 'Title Two Image', 'themedraft-core' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'default'     => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'insert_image' => 'yes',
				],
			]
		);

		$this->add_control(
			'word_count',
			[
				'label'       => __( 'Word Count', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 1,
				'condition' => [
					'insert_image' => 'yes',
				],
				'description'       => __( 'After which number of word you want to show image.', 'themedraft-core' ),
			]
		);

		$this->add_control(
		    'desc',
		    [
		        'label'       => __( 'Description', 'themedraft-core' ),
		        'type'        => Controls_Manager::WYSIWYG,
		        'default'     => 'Whether you\'re a small business looking to streamline operations or an enterprise aiming to scale seamlessly, our platform offers cutting-edge tools.',
		        'label_block' => true,
		    ]
		);

		$this->add_control(
			'circle_btn_text',
			[
				'label'       => __( 'Circle Button Text', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'get in touch - get in touch - get in touch -',
			]
		);

		$this->add_control(
			'circle_btn_url',
			[
				'label'         => __( 'Button URL', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '#',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'subtitle_style',
            [
                'label' => esc_html__( 'Subtitle', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'subtitle!' => '',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'subtitle_typo',
                'label' => esc_html__( 'Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .td-banner-one-subtitle',
            ]
        );

		$this->add_group_control(
			Themedraft_Gradient_Color::get_type(),
			[
				'label' => esc_html__( 'Color', 'themedraft-core' ),
				'name' => 'subtitle_text_color_type',
				'selector' => '{{WRAPPER}} .td-banner-one-subtitle',
			]
		);

        $this->add_responsive_control(
            'subtitle_text_align',
            [
                'label'       => esc_html__('Text Align', 'themedraft-core'),
                'type'        => Controls_Manager::CHOOSE,
                'label_block' => false,

                'options' => [
                    'left' => [
                        'title' => __('Left', 'themedraft-core'),
                        'icon'  => 'eicon-text-align-left',
                    ],

                    'center' => [
                        'title' => __('Center', 'themedraft-core'),
                        'icon'  => 'eicon-text-align-center',
                    ],

                    'right' => [
                        'title' => __('Right', 'themedraft-core'),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],

                'devices' => ['desktop', 'tablet', 'mobile'],

                'selectors' => [
                    '{{WRAPPER}} .td-banner-one-subtitle' => 'text-align: {{VALUE}};',
                ],

            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'title_one_style',
            [
                'label' => esc_html__( 'Title One', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_one_typo',
                'label' => esc_html__( 'Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .banner-title-one',
            ]
        );

        $this->add_control(
            'title_one_color',
            [
                'label'       => esc_html__('Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .banner-title-one' => 'color: {{VALUE}};',
                ],
            ]
        );

		$this->add_responsive_control(
			'title_one_text_align',
			[
				'label'       => esc_html__('Text Align', 'themedraft-core'),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,

				'options' => [
					'left' => [
						'title' => __('Left', 'themedraft-core'),
						'icon'  => 'eicon-text-align-left',
					],

					'center' => [
						'title' => __('Center', 'themedraft-core'),
						'icon'  => 'eicon-text-align-center',
					],

					'right' => [
						'title' => __('Right', 'themedraft-core'),
						'icon'  => 'eicon-text-align-right',
					],
				],

				'devices' => ['desktop', 'tablet', 'mobile'],

				'selectors' => [
					'{{WRAPPER}} .banner-title-one' => 'text-align: {{VALUE}};',
				],

			]
		);

        $this->end_controls_section();

		$this->start_controls_section(
			'title_two_style',
			[
				'label' => esc_html__( 'Title Two', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_two_typo',
				'label' => esc_html__( 'Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .banner-title-two',
			]
		);

		$this->add_control(
			'title_two_color',
			[
				'label'       => esc_html__('Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .banner-title-two' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_two_text_align',
			[
				'label'       => esc_html__('Text Align', 'themedraft-core'),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,

				'options' => [
					'left' => [
						'title' => __('Left', 'themedraft-core'),
						'icon'  => 'eicon-text-align-left',
					],

					'center' => [
						'title' => __('Center', 'themedraft-core'),
						'icon'  => 'eicon-text-align-center',
					],

					'right' => [
						'title' => __('Right', 'themedraft-core'),
						'icon'  => 'eicon-text-align-right',
					],
				],

				'devices' => ['desktop', 'tablet', 'mobile'],

				'selectors' => [
					'{{WRAPPER}} .banner-title-two' => 'text-align: {{VALUE}};',
				],

			]
		);

        $this->add_responsive_control(
            'title_img_height',
            [
                'label' => esc_html__( 'Image Height & Width', 'themedraft-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 300,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],

                'selectors' => [
                    '{{WRAPPER}} div .banner-title-two img' => 'width: {{SIZE}}px;height: {{SIZE}}px;',
                ],
            ]
        );

		$this->end_controls_section();

        $this->start_controls_section(
            'desc_style',
            [
                'label' => esc_html__( 'Description', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'desc_typo',
                'label' => esc_html__( 'Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .td-banner-one-desc',
            ]
        );

        $this->add_responsive_control(
            'desc_padding',
            [
                'label'      => esc_html__( 'Padding', 'themedraft-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .td-banner-one-desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'desc_margin',
            [
                'label'      => esc_html__( 'Margin', 'themedraft-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .td-banner-one-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'circle_btn_style',
            [
                'label' => esc_html__( 'Circle Button', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'circle_btn_typo',
                'label' => esc_html__( 'Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .td-circle-button-one-wrapper',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'circle_btn_background',
                'label' => esc_html__( 'Background', 'themedraft-core' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .td-circle-button-one-wrapper',
                'exclude' => ['image'],
            ]
        );

		$this->add_responsive_control(
			'circle_btn_size',
			[
				'label' => esc_html__( 'Button Size', 'themedraft-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 100,
						'max' => 300,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .td-circle-button-one-wrapper' => 'width: {{SIZE}}px;height: {{SIZE}}px;',
				],
			]
		);

        $this->add_responsive_control(
            'circle_btn_text_align',
            [
                'label'       => esc_html__('Text Align', 'themedraft-core'),
                'type'        => Controls_Manager::CHOOSE,
                'label_block' => false,

                'options' => [
                    'left' => [
                        'title' => __('Left', 'themedraft-core'),
                        'icon'  => 'eicon-text-align-left',
                    ],

                    'center' => [
                        'title' => __('Center', 'themedraft-core'),
                        'icon'  => 'eicon-text-align-center',
                    ],

                    'right' => [
                        'title' => __('Right', 'themedraft-core'),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],

                'devices' => ['desktop', 'tablet', 'mobile'],

                'selectors' => [
                    '{{WRAPPER}} .td-banner-one-circle-button' => 'text-align: {{VALUE}};',
                ],

            ]
        );

        $this->add_control(
            'circle_btn_color',
            [
                'label'       => esc_html__('Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-circle-button-one-wrapper svg' => 'fill: {{VALUE}};',
                    '{{WRAPPER}} .td-circle-button-one-wrapper i' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'wrapper_style',
            [
                'label' => esc_html__( 'Wrapper', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

		$this->add_responsive_control(
			'wrapper_height',
			[
				'label' => esc_html__( 'Height', 'themedraft-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 400,
						'max' => 1000,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .td-banner-one-wrapper' => 'height: {{SIZE}}px;',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'wrapper_background',
                'label' => esc_html__( 'Background', 'themedraft-core' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .td-banner-one-wrapper',
            ]
        );

        $this->end_controls_section();

	}


	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$subtitle       = $settings['subtitle'];
		$title_one       = $settings['title_one'];
		$title_two       = $settings['title_two'];
		?>

        <div class="td-banner-one-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="td-banner-one-content">
                            <div class="td-banner-one-subtitle wow td-top-to-bottom">
                                <?php echo $subtitle;?>
                            </div>

                            <<?php echo $settings['title_one_tag'];?> class="banner-title-one wow td-top-to-bottom">
	                            <?php echo wp_kses( $title_one, bizkorp_allow_html() ); ?>
                                <span class="banner-one-title-two"><?php echo wp_kses( $title_two, bizkorp_allow_html() ); ?></span>
                            </<?php echo $settings['title_one_tag'];?>>

                            <<?php echo $settings['title_two_tag'];?> class="banner-title-two wow td-top-to-bottom">
                            <?php if($settings['insert_image'] == 'yes'){
                                $image_src = $settings['title_two_image']['url'];
                                $image_alt = get_post_meta( $settings['title_two_image']['id'], '_wp_attachment_image_alt', true );
                                $image_title = get_the_title( $settings['title_two_image']['id']);
                                $word_position = $settings['word_count'];
                                $words = explode(' ', $title_two);
                                $image_html = '<img src="' . $image_src . '" alt="' . $image_alt . '" title="' . $image_title . '">';
                                if (isset($words[$word_position])) {
                                    array_splice($words, $word_position, 0, $image_html);
                                }
                                $title = implode(' ', $words);
                                echo $title;
                            }else{
                                echo wp_kses( $title_two, bizkorp_allow_html() );
                            } ?>
                            </<?php echo $settings['title_two_tag'];?>>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xl-4 my-auto">
                        <div class="td-banner-one-desc wow td-top-to-bottom td-last-p-0">
		                    <?php echo $settings['desc'];?>
                        </div>
                    </div>

                    <div class="col-xl-8">
                        <div class="td-banner-one-circle-button wow td-top-to-bottom">
                            <a href="<?php echo esc_url($settings['circle_btn_url']['url']);?>" class="td-circle-button-one-wrapper">
                                <i class="icon-button-arrow-one"></i>
                                <svg viewBox="0 0 100 100" class="td-spin-animation">
                                    <defs>
                                        <path id="td-circle-button-one" d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0"></path>
                                    </defs>
                                    <text>
                                        <textPath xlink:href="#td-circle-button-one">
	                                        <?php echo esc_html($settings['circle_btn_text']);?>
                                        </textPath>
                                    </text>
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Hero_Banner_One_Widget );