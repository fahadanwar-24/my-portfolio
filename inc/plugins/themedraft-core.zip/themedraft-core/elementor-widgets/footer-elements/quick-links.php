<?php
namespace Elementor;

class ThemeDraft_Quick_Links_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_quick_links';
	}

	public function get_title() {
		return esc_html__( 'Quick Links', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon flaticon-link-1';
	}

	public function get_categories() {
		return [ 'themedraft_footer_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'quick_links',
			[
				'label' => esc_html__( 'Quick Links', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
            'layout_style',
            [
                'label'   => esc_html__( 'Layout Style', 'themedraft-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'style-one',
                'options' => [
                    'style-one' => esc_html__( 'Style One', 'themedraft-core' ),
                    'style-two' => esc_html__( 'Style Two', 'themedraft-core' ),
                ],
            ]
        );

		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Quick Links',
			]
		);

		$this->add_control(
		    'select_a_menu',
		    [
		        'label'     => esc_html__( 'Select A menu', 'themedraft-core' ),
		        'type'      => Controls_Manager::SWITCHER,
		        'label_on'  => esc_html__( 'Yes', 'themedraft-core' ),
		        'label_off' => esc_html__( 'No', 'themedraft-core' ),
		        'default'   => 'yes',
		    ]
		);

		$this->add_control(
			'menu_list',
			[
				'label'   => __( 'Select Menu', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' =>themedraft_get_custom_menu(),
				'condition' => [
				    'select_a_menu' => 'yes',
				],
			]
		);

		$repeater = new Repeater();
		$repeater->add_control(
			'list_text',
			[
				'label'       => __( 'List Text', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'List Text Here', 'themedraft-core' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'list_url',
			[
				'label'         => __( 'URL', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'list_items',
			[
				'label'       => __( 'List Items', 'themedraft-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'list_text' => __( 'List Text Here', 'themedraft-core' ),
					],
				],
				'title_field' => '{{{ list_text }}}',
                'condition' => [
                    'select_a_menu!' => 'yes',
                ],
			]
		);

        $this->add_control(
            'enable_space_between',
            [
                'label'     => esc_html__( 'Enable Same Space For Menu Item', 'themedraft-core' ),
                'type'      => Controls_Manager::SWITCHER,
                'label_on'  => esc_html__( 'Yes', 'themedraft-core' ),
                'label_off' => esc_html__( 'No', 'themedraft-core' ),
                'default'   => 'no',
            ]
        );

		$this->add_responsive_control(
			'layout',
			[
				'label'       => esc_html__('Layout', 'themedraft-core'),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options' => [
					'layout_default' => [
						'title' => __('Default', 'themedraft-core'),
						'icon'  => 'eicon-editor-list-ul',
					],

					'inline-block' => [
						'title' => __('Inline', 'themedraft-core'),
						'icon'  => 'eicon-ellipsis-h',
					],
				],

				'devices' => ['desktop', 'tablet', 'mobile'],

				'selectors' => [
					'{{WRAPPER}} .td-elementor-widget.widget ul li' => 'display: {{VALUE}}; margin-right:25px',
					'{{WRAPPER}} .td-elementor-widget.widget ul li a' => 'margin-bottom:0',
					'{{WRAPPER}} .td-elementor-widget.widget ul li:last-child' => 'margin-right:0',
				],

			]
		);

        $this->add_responsive_control(
            'text_align',
            [
                'label'       => esc_html__('Text Align', 'themedraft-core'),
                'type'        => Controls_Manager::CHOOSE,
                'label_block' => false,

                'options' => [
                    'left' => [
                        'title' => __('Left', 'themedraft-core'),
                        'icon'  => 'eicon-text-align-left',
                    ],

                    'center' => [
                        'title' => __('Center', 'themedraft-core'),
                        'icon'  => 'eicon-text-align-center',
                    ],

                    'right' => [
                        'title' => __('Right', 'themedraft-core'),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],

                'default' => 'left',
                'devices' => ['desktop', 'tablet', 'mobile'],

                'selectors' => [
                    '{{WRAPPER}} .td-elementor-widget.widget ul' => 'text-align: {{VALUE}};',
                ],

            ]
        );

		$this->end_controls_section();


		$this->start_controls_section(
			'title_style',
			[
				'label' => esc_html__( 'Title', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'title!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typo',
				'label' => esc_html__( 'Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .widget-title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'       => esc_html__('Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .widget-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_margin',
			[
				'label'      => esc_html__( 'Title Margin', 'themedraft-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .widget-title,{{WRAPPER}} .style-two .widget-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


        // Start List Style section
        $this->start_controls_section(
            'td_list_style_options',
            [
                'label' => esc_html__('List Style', 'themedraft-core'),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'links_typo',
                'label' => esc_html__( 'Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .td-elementor-widget .menu',
            ]
        );

        $this->add_responsive_control(
            'item_margin',
            [
                'label'      => esc_html__( 'Item Margin', 'themedraft-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .td-elementor-widget.widget ul li' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('td_list_style_tabs');

        //Default style tab start
        $this->start_controls_tab(
            'td_list_style_default',
            [
                'label' => esc_html__('Default', 'themedraft-core'),
            ]
        );

        $this->add_control(
            'list_default_text_color',
            [
                'label'     => esc_html__('Color', 'themedraft-core'),
                'type'      => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .td-elementor-widget.widget_themedraft_nav_menu li a' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .td-elementor-widget.widget_themedraft_nav_menu li a:before' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'list_default_border_color',
            [
                'label'       => esc_html__('Border Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-elementor-widget.widget_themedraft_nav_menu.style-two li a' => 'border-color: {{VALUE}};',
                ],
                'condition' => [
                    'layout_style' => 'style-two',
                ],
            ]
        );

        $this->add_control(
            'list_default_background_color',
            [
                'label'       => esc_html__('Background Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-elementor-widget.widget_themedraft_nav_menu.style-two li a' => 'background-color: {{VALUE}};',
                ],
                'condition' => [
                    'layout_style' => 'style-two',
                ],
            ]
        );

        $this->end_controls_tab();//Default style tab end

        //Hover style tab start
        $this->start_controls_tab(
            'td_list_style_hover',
            [
                'label' => esc_html__('Hover', 'themedraft-core'),
            ]
        );

		$this->add_control(
			'list_hover_text_color',
			[
				'label'     => esc_html__('Color', 'themedraft-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .td-elementor-widget.widget_themedraft_nav_menu li a:hover,{{WRAPPER}} .td-elementor-widget.widget_themedraft_nav_menu.style-two li a:hover,{{WRAPPER}} .td-elementor-widget.widget_themedraft_nav_menu.style-two li.current-menu-item a' => 'color: {{VALUE}};',
					'{{WRAPPER}} .td-elementor-widget.widget_themedraft_nav_menu li a:hover:before' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'list_hover_border_color',
			[
				'label'       => esc_html__('Border Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-elementor-widget.widget_themedraft_nav_menu.style-two li a:hover,{{WRAPPER}} .td-elementor-widget.widget_themedraft_nav_menu.style-two li.current-menu-item a' => 'border-color: {{VALUE}};',
				],
				'condition' => [
					'layout_style' => 'style-two',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'list_default_background_color',
                'label' => esc_html__( 'Background Color', 'themedraft-core' ),
                'types' => ['gradient'],
                'selector' => '{{WRAPPER}} .td-elementor-widget.widget_themedraft_nav_menu.style-two li a:before',
                'condition' => [
	                'layout_style' => 'style-two',
                ],
            ]
        );

        $this->end_controls_tabs();//Hover style tab end

        $this->end_controls_section();// End Button section

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<div class="td-elementor-widget widget widget_nav_menu widget_themedraft_nav_menu widget_nav_menu <?php echo $settings['layout_style'];?>">
			<?php if ($settings['title']) : ?>
            <h4 class="widget-title"><?php echo $settings['title'];?></h4>
            <?php endif; ?>

			<?php
            if ($settings['select_a_menu'] == 'yes'){
	            if($settings['menu_list']){
		            $header_menu = $settings['menu_list'];
	            }else{
		            $header_menu = '';
	            }

	            wp_nav_menu( array(
		            'menu'            => $header_menu,
	            ) );
            }else{ ?>
                <ul class="menu <?php if ($settings['enable_space_between']=='yes'){echo 'td-space-between';}?>">
		            <?php if ( $settings['list_items'] ) {
			            foreach ( $settings['list_items'] as $list ) {
				            $list_text = $list['list_text'];
				            $list_url = $list['list_url']['url'];
				            $list_target      = $list['list_url']['is_external'] ? ' target="_blank"' : '';
				            $list_nofollow    = $list['list_url']['nofollow'] ? ' rel="nofollow"' : '';
				            ?>
                            <li>
                                <a href="<?php echo $list_url; ?>" <?php echo $list_target . $list_nofollow ?>><?php echo $list_text;?></a>
                            </li>
			            <?php }
		            } ?>
                </ul>
            <?php }
			?>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Quick_Links_Widget );