<?php
namespace Elementor;

class ThemeDraft_Footer_Contact_And_Subscribe_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_footer_contact_and_subscribe';
	}

	public function get_title() {
		return esc_html__( 'Contact & Subscribe', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon flaticon-customer-service';
	}

	public function get_categories() {
		return [ 'themedraft_footer_elements' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'footer_contact_and_subscribe_options',
			[
				'label' => esc_html__( 'Contact & Subscribe', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'widget_title',
			[
				'label'       => __( 'Widget Title', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Contact Us',
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'selected_icon',
			[
				'label'            => esc_html__( 'Select Icon', 'themedraft-core' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fas fa-map-marker-alt',
					'library' => 'solid',
				],
			]
		);

		$repeater->add_control(
            'desc',
            [
                'label'       => __( 'Description', 'themedraft-core' ),
                'type'        => Controls_Manager::WYSIWYG,
                'default'     => '175 10th Street, Office 375 Berlin, Devonian 21562',
                'label_block' => true,
            ]
        );


		$this->add_control(
			'info_items',
			[
				'label'       => __( 'Info List', 'themedraft-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),

				'default'     => [
					[
						'selected_icon' => 'fas fa-map-marker-alt',
						'desc' => '175 10th Street, Office 375 Berlin, Devonian 21562',
					],
				],
				'title_field' => '<i class="{{{selected_icon.value}}}"></i>'.'{{{ desc }}}',
			]
		);

        $this->add_control(
            'subscribe_title',
            [
                'label'       => __( 'Subscribe Title', 'themedraft-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => __( 'Subscribe Now', 'themedraft-core' ),
            ]
        );

		$this->add_control(
			'subscribe_shortcode',
			[
				'label'       => __( 'Subscribe Form Shortcode', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'subscribe_style',
            [
                'label' => esc_html__( 'Contact & Subscribe', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'widget_title_color',
            [
                'label'       => esc_html__('Widget Title Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .widget-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'info_icon_color',
            [
                'label'       => esc_html__('Info Icon Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .widget-contact-info-list li i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .widget-contact-info-list li svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'info_text_color',
            [
                'label'       => esc_html__('Info Text Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .widget-contact-info-list li,{{WRAPPER}} .widget-contact-info-list li a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'subscribe_title_color',
            [
                'label'       => esc_html__('Subscribe Title Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .subscribe-us' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'subscribe_form_border_color',
            [
                'label'       => esc_html__('Subscribe Form Border Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .themedraft_contact_info_widget .td-subscribe-form input[type="email"]' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'subscribe_form_focus_border_color',
            [
                'label'       => esc_html__('Subscribe Form Focus Border Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .themedraft_contact_info_widget .td-subscribe-form input[type="email"]:focus' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'subscribe_form_text_color',
            [
                'label'       => esc_html__('Subscribe Form Text Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .themedraft_contact_info_widget .td-subscribe-form input[type="email"]' => 'color: {{VALUE}};',
                ],
            ]
        );

		$this->add_control(
			'subscribe_field_placeholder_color',
			[
				'label'       => esc_html__('Placeholder Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .footer-widget-subscribe-form ::placeholder' => 'color: {{VALUE}};',
					'{{WRAPPER}} .footer-widget-subscribe-form :-ms-input-placeholder' => 'color: {{VALUE}};',
					'{{WRAPPER}} .footer-widget-subscribe-form ::-ms-input-placeholder' => 'color: {{VALUE}};',
				],
			]
		);

        $this->add_control(
            'subscribe_button_icon_color',
            [
                'label'       => esc_html__('Button Icon Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .themedraft_contact_info_widget .td-subscribe-button i' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<div class="td-elementor-widget widget themedraft_contact_info_widget">
            <h4 class="widget-title"><?php echo $settings['widget_title'];?></h4>

            <div class="td-contact-info-wrapper">
                <ul class="td-list-style widget-contact-info-list">
	                <?php if ($settings['info_items']) {
		                foreach ($settings['info_items'] as $info_item) { ?>
                        <li>
                            <?php themedraft_custom_icon_render( $info_item, 'icon', 'selected_icon' );?>
                            <?php echo $info_item['desc'];?>
                        </li>
		                <?php }
	                } ?>
                </ul>

                <div class="footer-widget-subscribe-form">
                    <div class="subscribe-us"><?php echo $settings['subscribe_title'];?></div>

	                <?php echo do_shortcode( ''.$settings['subscribe_shortcode'].'');?>
                </div>
            </div>
		</div>
		<?php
	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Footer_Contact_And_Subscribe_Widget );