<?php
namespace Elementor;

class ThemeDraft_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_';
	}

	public function get_title() {
		return esc_html__( 'Copyright Text', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon flaticon-arroba';
	}

	public function get_categories() {
		return [ 'themedraft_footer_elements' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'copyright_text_option',
			[
				'label' => esc_html__( 'Copyright Text', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
		    'copyright_text',
		    [
		        'label'       => __( 'Copyright Text', 'themedraft-core' ),
		        'type'        => Controls_Manager::WYSIWYG,
		        'default'     => '&copy; Bizkorp 2025 All Rights Reserved.'
		    ]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'copyright_style',
            [
                'label' => esc_html__( 'Copyright Text', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'text_typo',
                'label' => esc_html__( 'Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .td-copyright-text',
            ]
        );

        $this->add_control(
            'text_color',
            [
                'label'       => esc_html__('Text Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-copyright-text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'text_align',
            [
                'label'       => esc_html__('Text Align', 'themedraft-core'),
                'type'        => Controls_Manager::CHOOSE,
                'label_block' => false,

                'options' => [
                    'left' => [
                        'title' => __('Left', 'themedraft-core'),
                        'icon'  => 'eicon-text-align-left',
                    ],

                    'center' => [
                        'title' => __('Center', 'themedraft-core'),
                        'icon'  => 'eicon-text-align-center',
                    ],

                    'right' => [
                        'title' => __('Right', 'themedraft-core'),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],

                'devices' => ['desktop', 'tablet', 'mobile'],

                'selectors' => [
                    '{{WRAPPER}} .td-copyright-text' => 'text-align: {{VALUE}};',
                ],

            ]
        );

        $this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<div class="td-copyright-text">
			<?php echo wp_kses($settings['copyright_text'], bizkorp_allow_html());?>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Widget );