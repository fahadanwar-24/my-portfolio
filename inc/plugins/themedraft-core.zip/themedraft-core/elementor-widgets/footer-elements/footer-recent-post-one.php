<?php
namespace Elementor;

class ThemeDraft_Footer_Recent_Post_One_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_footer_recent_post_one';
	}

	public function get_title() {
		return esc_html__( 'Footer Recent Post One', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon eicon-post-excerpt';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'recent_post_settings',
			[
				'label' => esc_html__( 'Post Settings', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
            'widget_title',
            [
                'label'       => __( 'Widget Title', 'themedraft-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => 'Recent Posts',
            ]
        );

		$this->add_control(
			'post_count',
			[
				'label'   => __( 'Number Of Post To Show', 'themedraft-core' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 100,
				'step'    => 1,
				'default' => 3,
			]
		);

		$this->add_control(
			'category',
			[
				'label'       => __( 'Categories', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple'    => true,
				'options'     => themedraft_post_categories(),
			]
		);

		$this->add_control(
			'exclude_post',
			[
				'label'       => __( 'Exclude Posts', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT2,
				'label_block' => true,
				'multiple'    => true,
				'description' => __( 'Select post id.', 'themedraft-core' ),
				'options'     => themedraft_get_post_title_as_list(),
			]
		);


		$this->add_control(
			'post_offset',
			[
				'label'   => __( 'Post Offset', 'themedraft-core' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => '',
				'step'    => 1,
				'default' => 0,
			]
		);

		$this->add_control(
			'post_orderby',
			[
				'label'   => __( 'Order By', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => themedraft_post_orderby_options(),
				'default' => 'date',

			]
		);

		$this->add_control(
			'post_order',
			[
				'label'   => __( 'Order', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'asc'  => 'Ascending',
					'desc' => 'Descending'
				],
				'default' => 'desc',

			]
		);

		$this->add_control(
			'show_date',
			[
				'label'   => __( 'Show Date', 'themedraft-core' ),
				'type'    => Controls_Manager::SWITCHER,
				'default' => 'yes',
			]
		);

		$this->add_control(
			'title_word',
			[
				'label'   => __( 'Title Word Count', 'themedraft-core' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => '',
				'step'    => 1,
				'default' => 8,
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'recent_post_widget_title_style',
			[
				'label' => esc_html__( 'Widget Title', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'widget_title_typo',
				'label' => esc_html__( 'Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .td-elementor-widget.widget.td-footer-recent-post-one-wrapper .widget-title',
			]
		);

		$this->add_control(
			'widget_title_color',
			[
				'label'       => esc_html__('Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-elementor-widget.widget.td-footer-recent-post-one-wrapper .widget-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();


        $this->start_controls_section(
            'recent_post_style',
            [
                'label' => esc_html__( 'Recent Post Style', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typo',
                'label' => esc_html__( 'Title Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .td-recent-post-one-wrapper article .post-title',
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'       => esc_html__('Title Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .footer-recent-post-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'date_background',
                'label' => esc_html__( 'Date Background', 'themedraft-core' ),
                'types' => [ 'classic', 'gradient'],
                'exclude' => [ 'image'],
                'selector' => '{{WRAPPER}} .footer-recent-post-date a',
            ]
        );

        $this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();

		if ( ! empty( $settings['category'] ) ) {
			$post_query = new \WP_Query( array(
				'post_type'           => 'post',
				'posts_per_page'      => $settings['post_count'],
				'ignore_sticky_posts' => 1,
				'offset'              => $settings['post_offset'],
				'orderby'             => $settings['post_orderby'],
				'order'               => $settings['post_order'],
				'post__not_in'        => $settings['exclude_post'],
				'tax_query'           => array(
					array(
						'taxonomy' => 'category',
						'terms'    => $settings['category'],
						'field'    => 'slug',
					)
				)
			) );
		} else {

			$post_query = new \WP_Query(
				array(
					'posts_per_page'      => $settings['post_count'],
					'post_type'           => 'post',
					'ignore_sticky_posts' => 1,
					'offset'              => $settings['post_offset'],
					'orderby'             => $settings['post_orderby'],
					'order'               => $settings['post_order'],
					'post__not_in'        => $settings['exclude_post'],
				)
			);
		}
		?>

		<div class="td-elementor-widget widget td-footer-recent-post-one-wrapper">

			<?php if ($settings['widget_title']) : ?>
                <h4 class="widget-title"><?php echo $settings['widget_title'];?></h4>
			<?php endif; ?>

            <?php while ( $post_query->have_posts() ) : $post_query->the_post(); ?>
            <div class="td-footer-single-post-item">
	            <?php if($settings['show_date'] == 'yes') : ?>
                    <span class="footer-recent-post-date"><?php bizkorp_posted_on(); ?></span>
	            <?php endif;?>

                <a href="<?php echo esc_url( get_the_permalink() );?>">
                    <h4 class="footer-recent-post-title"><?php echo wp_trim_words(get_the_title(), $settings['title_word'], ' ...');?></h4>
                </a>

            </div>
            <?php
            endwhile;
            wp_reset_query();
            ?>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Footer_Recent_Post_One_Widget );