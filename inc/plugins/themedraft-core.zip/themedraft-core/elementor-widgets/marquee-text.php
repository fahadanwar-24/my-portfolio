<?php
namespace Elementor;

class ThemeDraft_Marquee_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_marquee_text';
	}

	public function get_title() {
		return esc_html__( 'Marquee Text', 'themedraft-core' );
	}

	public function get_icon() {
		return 'eicon-text';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'marquee_text_options',
			[
				'label' => esc_html__( 'Marquee Text', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

        $repeater = new Repeater();

        $repeater->add_control(
            'text',
            [
                'label'       => esc_html__( 'Text', 'themedraft-core' ),
                'type'        => Controls_Manager::TEXT,
                'default'     => esc_html__( 'Web Development', 'themedraft-core' ),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'marquees',
            [
                'label'       => esc_html__( 'Marquee List', 'themedraft-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [
                    [
                        'text' => esc_html__( 'Web Development', 'themedraft-core' ),
                    ],
                ],
                'title_field' => '{{{ text }}}',
            ]
        );

        $this->add_control(
            'marquee_icon',
            [
                'label'            => esc_html__( 'Marquee Icon', 'themedraft-core' ),
                'type'             => Controls_Manager::ICONS,
                'fa4compatibility' => 'icon',
                'label_block'      => true,
                'default'          => [
                    'value'   => 'fas fa-star-of-life',
                    'library' => 'solid',
                ],
            ]
        );

		$this->end_controls_section();

        $this->start_controls_section(
            'marquee_text_style',
            [
                'label' => esc_html__( 'Marquee Text', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'text_typography',
				'label' => esc_html__( 'Text Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .marquee-item-wrapper .swiper-slide',
			]
		);

        $this->add_control(
            'text_color',
            [
                'label'       => esc_html__('Text Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .marquee-item-wrapper .swiper-slide' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label'       => esc_html__('Icon Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-marquee-icon i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .td-marquee-icon svg path' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_size',
            [
                'label' => esc_html__( 'Icon Size', 'themedraft-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],

                'selectors' => [
                    '{{WRAPPER}} .marquee-item-wrapper .td-marquee-icon' => 'height: {{SIZE}}px;width: {{SIZE}}px;line-height: {{SIZE}}px;font-size: {{SIZE}}px;',
                    '{{WRAPPER}} .td-marquee-icon svg' => 'width: {{SIZE}}px;height: {{SIZE}}px;line-height: {{SIZE}}px;',
                ],
            ]
        );
        $this->add_responsive_control(
            'icon_gap',
            [
                'label' => esc_html__( 'Icon Gap', 'themedraft-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],

                'selectors' => [
                    '{{WRAPPER}} .td-marquee-icon' => 'margin: 0 {{SIZE}}px;',
                ],
            ]
        );

		$this->add_control(
			'wrapper_background',
			[
				'label'       => esc_html__('Background Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .marquee-item-wrapper' => 'background-color: {{VALUE}};',
				],
			]
		);

        $this->add_responsive_control(
            'wrapper_padding',
            [
                'label'      => esc_html__( 'Wrapper Padding', 'themedraft-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .marquee-item-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
        $id = rand(100, 1000);
		?>

		<div class="marquee-item-wrapper">
            <div class="marquee-slider-<?php echo $id;?>">
                <div class="swiper-wrapper">
	                <?php if ($settings['marquees']) {
		                foreach ($settings['marquees'] as $marquee) { ?>
                            <div class="swiper-slide">
	                            <?php echo $marquee['text'];?>

                                <div class="td-marquee-icon">
					                <?php themedraft_custom_icon_render( $settings, 'icon', 'marquee_icon' );?>
                                </div>
                            </div>
		                <?php }
	                } ?>
                </div>
            </div>

            <script>
                document.addEventListener("DOMContentLoaded", function() {
                    let Marquee_<?php echo $id;?> = new Swiper('.marquee-slider-<?php echo $id;?>', {
                        spaceBetween: 0,
                        centeredSlides: true,
                        speed: 3000,
                        autoplay: {
                            delay: 0,
                        },
                        loop: true,
                        slidesPerView: 'auto',
                        allowTouchMove: false,
                        disableOnInteraction: true
                    });
                });
            </script>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Marquee_Widget );