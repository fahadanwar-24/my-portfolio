<?php
namespace Elementor;
class ThemeDraft_Project_Slider_One_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_project_slider_one';
	}

	public function get_title() {
		return esc_html__( 'Project Slider One', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon flaticon-layers';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'project_slider_settings',
			[
				'label' => esc_html__( 'Project Box', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'subtitle',
			[
				'label'       => __( 'Subtitle', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 5,
				'default'     => 'Marketing',
			]
		);

		$repeater->add_control(
			'title',
			[
				'label'       => __( 'Title', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 5,
				'default'     => 'Quality in digital industrial Projects Limited.',
			]
		);

		$repeater->add_control(
			'thumbnail_image',
			[
				'label'     => esc_html__( 'Image', 'themedraft-core' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'dynamic'   => [
					'active' => true,
				]
			]
		);

		$repeater->add_control(
			'details_url',
			[
				'label'         => __( 'Details Url', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'projects',
			[
				'label'       => __( 'Project List', 'themedraft-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'subtitle' => 'Marketing',
						'title' => 'Quality in digital industrial Projects Limited.',
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

        $this->add_control(
            'animation',
            [
                'label'   => __( 'Animation', 'themedraft-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => themedraft_core_get_animation_options(),
            ],
        );

		$this->end_controls_section();


		$this->start_controls_section(
			'project_slider_options',
			[
				'label' => esc_html__( 'Slider Options', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'desktop_count',
			[
				'label'       => __( 'Item Show On Desktop', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					1 => __( '1 Column', 'themedraft-core' ),
					2 => __( '2 Column', 'themedraft-core' ),
					3 => __( '3 Column', 'themedraft-core' ),
					4 => __( '4 Column', 'themedraft-core' ),
					5 => __( '5 Column', 'themedraft-core' ),
				],
				'default'     => 4,
			]
		);

		$this->add_control(
			'small_desktop_count',
			[
				'label'       => __( 'Item Show On Small Desktop', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					1 => __( '1 Column', 'themedraft-core' ),
					2 => __( '2 Column', 'themedraft-core' ),
					3 => __( '3 Column', 'themedraft-core' ),
					4 => __( '4 Column', 'themedraft-core' ),
					5 => __( '5 Column', 'themedraft-core' ),
				],
				'default'     => 3,
			]
		);


		$this->add_control(
			'ipad_pro_count',
			[
				'label'       => __( 'Item Show On iPad Pro', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					1 => __( '1 Column', 'themedraft-core' ),
					2 => __( '2 Column', 'themedraft-core' ),
					3 => __( '3 Column', 'themedraft-core' ),
					4 => __( '4 Column', 'themedraft-core' ),
				],
				'default'     => 2,
			]
		);

		$this->add_control(
			'tab_count',
			[
				'label'       => __( 'Item Show On Tablet', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					1 => __( '1 Column', 'themedraft-core' ),
					2 => __( '2 Column', 'themedraft-core' ),
					3 => __( '3 Column', 'themedraft-core' ),
					4 => __( '4 Column', 'themedraft-core' ),
				],
				'default'     => 2,
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label' => __( 'Autoplay', 'themedraft-core' ),
				'type' => Controls_Manager::SWITCHER,
				'show_label' => true,
				'label_block' => false,
				'default' => 'yes',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'autoplay_interval',
			[
				'label' => __( 'Autoplay Interval', 'themedraft-core' ),
				'type' => Controls_Manager::SELECT,
				'show_label' => true,
				'label_block' => false,
				'options' => [
					'2000'  => __( '2 seconds', 'themedraft-core' ),
					'3000'  => __( '3 seconds', 'themedraft-core' ),
					'4000'  => __( '4 seconds', 'themedraft-core' ),
					'5000'  => __( '5 seconds', 'themedraft-core' ),
					'6000'  => __( '6 seconds', 'themedraft-core' ),
					'7000'  => __( '7 seconds', 'themedraft-core' ),
					'8000'  => __( '8 seconds', 'themedraft-core' ),
					'9000'  => __( '9 seconds', 'themedraft-core' ),
					'10000'  => __( '10 seconds', 'themedraft-core' ),
				],
				'default' => '5000',
				'condition' => [
					'autoplay' => 'yes',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'td_project_subtitle_style_options',
			[
				'label' => esc_html__('Subtitle', 'themedraft-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'subtitle_typo',
				'label' => esc_html__( 'Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .td-project-slider-one-subtitle',
			]
		);

		$this->add_control(
			'subtitle_color',
			[
				'label'       => esc_html__('Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-project-slider-one-subtitle' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'subtitle_margin',
			[
				'label'      => esc_html__( 'Margin', 'themedraft-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .td-project-slider-one-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'td_project_title_style_options',
			[
				'label' => esc_html__('Title', 'themedraft-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typo',
				'label' => esc_html__( 'Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .td-project-slider-one-title',
			]
		);

        $this->add_control(
            'title_color',
            [
                'label'       => esc_html__('Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-project-slider-one-title' => 'color: {{VALUE}};',
                ],
            ]
        );

		$this->add_responsive_control(
			'title_margin',
			[
				'label'      => esc_html__( 'Margin', 'themedraft-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .td-project-slider-two-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$slider_id = rand(100, 100000);
		?>

        <div class="td-project-slider-one-wrapper">

            <div id="project-slider-id-<?php echo $slider_id;?>" class="project-slider-one row">
                <?php if ( $settings['projects'] ) {
                    foreach ( $settings['projects'] as $project ) {
                        $details_url      = $project['details_url']['url'];
                        $target   = $project['details_url']['is_external'] ? ' target="_blank"' : '';
                        $nofollow = $project['details_url']['nofollow'] ? ' rel="nofollow"' : '';

                        $thumb_image_alt = get_post_meta( $project['thumbnail_image']['id'], '_wp_attachment_image_alt', true );
                        $thumb_image_title = get_the_title( $project['thumbnail_image']['id']);
                        $thumb_image_src = $project['thumbnail_image']['url'];
                        ?>

                        <div class="col-12 project-slider-one-col">
                            <div class="td-single-project-slider-one-item td-project-one-item <?php echo $settings['animation'];?>">
                                <div class="td-project-one-image-wrapper">
                                    <img src="<?php echo esc_url($thumb_image_src);?>" alt="<?php echo esc_attr($thumb_image_alt);?>">
                                    <div class="image-animation">
                                        <img src="<?php echo esc_url($thumb_image_src);?>" alt="<?php echo esc_attr($thumb_image_alt);?>">
                                    </div>
                                    <a class="td-project-image-link" href="<?php echo esc_url($project['details_url']['url']); ?>"></a>
                                </div>

                                <div class="td-project-slider-one-content">
                                    <span class="td-project-slider-one-subtitle"><?php echo $project['subtitle'];?></span>

                                    <a href="<?php echo $details_url;?>">
                                        <h4 class="td-project-slider-one-title"><?php echo nl2br($project['title']);?></h4>
                                    </a>
                                </div>


                            </div>
                        </div>
                    <?php }
                } ?>
            </div>

            <script>
                (function ($) {
                    "use strict";
                    $(document).ready(function () {
                        $("#project-slider-id-<?php echo $slider_id;?>").slick({
                            slidesToShow: <?php echo json_encode( $settings['desktop_count'] )?>,
                            autoplay: <?php echo json_encode($settings['autoplay'] == 'yes' ? true : false); ?>,
                            autoplaySpeed: <?php echo json_encode($settings['autoplay_interval'])?>,
                            speed: 1500, // slide speed
                            dots: false,
                            arrows: false,
                            infinite: true,
                            pauseOnHover: false,
                            centerMode: false,
                            centerPadding: 30,
                            responsive: [
                                {
                                    breakpoint: 1281,
                                    settings: {
                                        slidesToShow: <?php echo json_encode( $settings['small_desktop_count'] )?>,
                                    }
                                },
                                {
                                    breakpoint: 1025,
                                    settings: {
                                        slidesToShow: <?php echo json_encode( $settings['ipad_pro_count'] )?>, //768-991
                                    }
                                },
                                {
                                    breakpoint: 992,
                                    settings: {
                                        slidesToShow: <?php echo json_encode( $settings['tab_count'] )?>, //768-991
                                    }
                                },
                                {
                                    breakpoint: 768,
                                    settings: {
                                        slidesToShow: 1, // 0 -767
                                    }
                                }
                            ]
                        });
                    });
                })(jQuery);
            </script>

        </div>
		<?php
	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Project_Slider_One_Widget );