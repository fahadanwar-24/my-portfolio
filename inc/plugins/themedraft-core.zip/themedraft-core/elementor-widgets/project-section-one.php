<?php
namespace Elementor;

class ThemeDraft_Projects_Section_One_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_projects_section_one';
	}

	public function get_title() {
		return esc_html__( 'Projects Section One', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon flaticon-layers';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_title_options',
			[
				'label' => esc_html__( 'Section Title', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'subtitle',
			[
				'label'       => __( 'Subtitle', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Latest Project.',
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 5,
				'default'     => 'We Believe in Quality Not Quantity.',
			]
		);

		$this->add_control(
			'title_tag',
			[
				'label'   => __( 'Title Tag', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => [
					'h1' => __( 'H1', 'themedraft-core' ),
					'h2' => __( 'H2', 'themedraft-core' ),
					'h3' => __( 'H3', 'themedraft-core' ),
					'h4' => __( 'H4', 'themedraft-core' ),
					'h5' => __( 'H5', 'themedraft-core' ),
					'h6' => __( 'H6', 'themedraft-core' ),
					'span' => __( 'SPAN', 'themedraft-core' ),
				],
			]
		);

		$this->add_control(
			'title_animation',
			[
				'label'   => __( 'Title Animation', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => themedraft_core_get_animation_options(),
			],
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'project_box_settings',
			[
				'label' => esc_html__( 'Project Box', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);



		$repeater = new Repeater();

		$repeater->add_control(
			'service_title',
			[
				'label'       => __( 'Service Image', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 5,
				'default'     => 'Social Media Branding',
			]
		);

		$repeater->add_control(
            'service_image',
            [
                'label'       => __( 'Service Image', 'themedraft-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

		$repeater->add_control(
			'details_url',
			[
				'label'         => __( 'Details Url', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$repeater->add_control(
            'btn_one_text',
            [
                'label'       => __( 'Button One Text', 'themedraft-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => 'Ui Design',
            ]
        );

		$repeater->add_control(
            'btn_one_url',
            [
                'label'         => __( 'Button One URL', 'themedraft-core' ),
                'type'          => Controls_Manager::URL,
                'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
                'show_external' => true,
                'default'       => [
                    'url'         => '',
                    'is_external' => false,
                    'nofollow'    => false,
                ],
                'condition' => [
                    'btn_one_text!' => '',
                ],
            ]
        );
		$repeater->add_control(
            'btn_two_text',
            [
                'label'       => __( 'Button Two Text', 'themedraft-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => 'Branding',
            ]
        );

		$repeater->add_control(
            'btn_two_url',
            [
                'label'         => __( 'Button Two URL', 'themedraft-core' ),
                'type'          => Controls_Manager::URL,
                'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
                'show_external' => true,
                'default'       => [
                    'url'         => '',
                    'is_external' => false,
                    'nofollow'    => false,
                ],
                'condition' => [
                    'btn_two_text!' => '',
                ],
            ]
        );

		$this->add_control(
			'services',
			[
				'label'       => __( 'Service List', 'themedraft-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'service_title' => 'Social Media Branding',
						'btn_one_text' => 'Ui Design',
					],
				],
				'title_field' => '{{{ service_title }}}',
			]
		);

        $this->add_control(
            'box_animation',
            [
                'label'   => __( 'Box Animation', 'themedraft-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => themedraft_core_get_animation_options(),
            ],
        );

        $this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
        $subtitle = $settings['subtitle'];
		?>

		<div class="td-project-section-one-wrapper">
            <div class="row td-project-section-top-title">
                <div class="col-12">
                    <div class="td-section-title-one-wrapper <?php echo $settings['title_animation'];?>">
                        <div class="td-section-title-one-content">
	                        <?php if (!empty($subtitle)) : ?>
                                <div class="td-section-title-one-subtitle">
			                        <?php echo $subtitle;?>
                                </div>
	                        <?php endif; ?>
                            <<?php echo $settings['title_tag'];?> class="td-section-title-one-title">
                                <?php echo $settings['title'];?>
                            </<?php echo $settings['title_tag'];?>>
                        </div>
                    </div>
                </div>
            </div>

			<?php
			// Fetch repeater data
			$services = $settings['services'];
			$chunked_services = array_chunk($services, 2); // Split services into groups of 2

			foreach ($chunked_services as $index => $chunk) {
				?>
                <div class="row">
                    <div class="col-xxl-<?php echo ($index % 2 == 0) ? '6' : '5'; ?> col-xl-6 col-lg-6 col-md-6">
                        <div class="td-project-one-item <?php echo $settings['box_animation'];?> <?php echo ($index % 2 == 1) ? 'td-project-one-small-item' : ''; ?>">
                            <div class="td-project-one-image-wrapper">
                                <img src="<?php echo esc_url($chunk[0]['service_image']['url']); ?>" alt="<?php echo esc_attr($chunk[0]['service_title']); ?>">
                                <div class="image-animation">
                                    <img src="<?php echo esc_url($chunk[0]['service_image']['url']); ?>" alt="<?php echo esc_attr($chunk[0]['service_title']); ?>">
                                </div>
                                <a class="td-project-image-link" href="<?php echo esc_url($chunk[0]['details_url']['url']); ?>"></a>
                            </div>

                            <div class="td-project-one-content">
                                <div class="td-project-one-content-hover"></div>
                                <a href="<?php echo esc_url($chunk[0]['details_url']['url']); ?>">
                                    <h3 class="td-project-one-title"><?php echo esc_html($chunk[0]['service_title']); ?></h3>
                                </a>
                                <div class="td-project-one-category">
				                    <?php if($chunk[0]['btn_one_text']) :?>
                                    <a href="<?php echo esc_url($chunk[0]['btn_one_url']['url']); ?>"><?php echo esc_html($chunk[0]['btn_one_text']); ?></a>
                                    <?php endif; ?>
				                    <?php if($chunk[0]['btn_two_text']) :?>
                                    <a href="<?php echo esc_url($chunk[0]['btn_two_url']['url']); ?>"><?php echo esc_html($chunk[0]['btn_two_text']); ?></a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

					<?php if (isset($chunk[1])) : ?>
                        <div class="col-xxl-<?php echo ($index % 2 == 0) ? '5 offset-xxl-1' : '6 offset-xxl-1'; ?>  col-xl-6 offset-xl-0 col-lg-6 col-md-6">
                            <div class="td-project-one-item <?php echo $settings['box_animation'];?> <?php echo ($index % 2 == 0) ? 'td-project-one-small-item' : ''; ?>">
                                <div class="td-project-one-image-wrapper">
                                    <img src="<?php echo esc_url($chunk[1]['service_image']['url']); ?>" alt="<?php echo esc_attr($chunk[1]['service_title']); ?>">
                                    <div class="image-animation">
                                        <img src="<?php echo esc_url($chunk[1]['service_image']['url']); ?>" alt="<?php echo esc_attr($chunk[1]['service_title']); ?>">
                                    </div>
                                    <a class="td-project-image-link" href="<?php echo esc_url($chunk[1]['details_url']['url']); ?>"></a>
                                </div>

                                <div class="td-project-one-content">
                                    <div class="td-project-one-content-hover"></div>
                                    <a href="<?php echo esc_url($chunk[1]['details_url']['url']); ?>">
                                        <h3 class="td-project-one-title"><?php echo esc_html($chunk[1]['service_title']); ?></h3>
                                    </a>
                                    <div class="td-project-one-category">
                                        <?php if($chunk[1]['btn_one_text']) :?>
                                        <a href="<?php echo esc_url($chunk[1]['btn_one_url']['url']); ?>"><?php echo esc_html($chunk[1]['btn_one_text']); ?></a>
                                        <?php endif; ?>
					                    <?php if($chunk[1]['btn_two_text']) :?>
                                        <a href="<?php echo esc_url($chunk[1]['btn_two_url']['url']); ?>"><?php echo esc_html($chunk[1]['btn_two_text']); ?></a>
					                    <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
					<?php endif; ?>
                </div>

				<?php
				// Insert the title block only after the first two items (first iteration)
				if ($index === 0) {
					?>
                    <div class="row td-project-section-middle-title">
                        <div class="col-12">
                            <div class="td-section-title-one-wrapper <?php echo $settings['title_animation'];?>">
                                <div class="td-section-title-one-content">
			                        <?php if (!empty($subtitle)) : ?>
                                        <div class="td-section-title-one-subtitle">
					                        <?php echo $subtitle;?>
                                        </div>
			                        <?php endif; ?>
                                    <<?php echo $settings['title_tag'];?> class="td-section-title-one-title">
			                        <?php echo $settings['title'];?>
                                </<?php echo $settings['title_tag'];?>>
                            </div>
                        </div>
                        </div>
                    </div>
					<?php
				}
			}
			?>
        </div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Projects_Section_One_Widget );