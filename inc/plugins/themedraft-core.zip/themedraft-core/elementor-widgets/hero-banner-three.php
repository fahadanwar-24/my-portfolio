<?php
namespace Elementor;

class ThemeDraft_Hero_Banner_Three_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_hero_banner_three';
	}

	public function get_title() {
		return esc_html__( 'Hero Banner Three', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon flaticon-flag';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'hero_banner_content',
			[
				'label' => esc_html__( 'Banner Content', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
		    'title',
		    [
		        'label'       => __( 'Title', 'themedraft-core' ),
		        'type'        => Controls_Manager::TEXTAREA,
		        'rows'        => 5,
		        'default'     => 'We Will Manage Your Business For You',
		    ]
		);

		$this->add_control(
			'title_tag',
			[
				'label'   => __( 'Title Tag', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => [
					'h1' => __( 'H1', 'themedraft-core' ),
					'h2' => __( 'H2', 'themedraft-core' ),
					'h3' => __( 'H3', 'themedraft-core' ),
					'h4' => __( 'H4', 'themedraft-core' ),
					'h5' => __( 'H5', 'themedraft-core' ),
					'h6' => __( 'H6', 'themedraft-core' ),
					'span' => __( 'SPAN', 'themedraft-core' ),
				],
			]
		);

        $this->add_control(
            'title_animation',
            [
                'label'   => __( 'Title Animation', 'themedraft-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => themedraft_core_get_animation_options(),
            ],
        );

		$this->add_control(
		    'desc',
		    [
		        'label'       => __( 'Description', 'themedraft-core' ),
		        'type'        => Controls_Manager::WYSIWYG,
		        'default'     => 'Whether you\'re a small business looking to streamline operations or an the enterprise aiming to scale seamlessly, our platform offers cutting edge tools. We specialize in your services, e.g. competitive landscape.',
		        'label_block' => true,
		    ]
		);

		$this->add_control(
			'desc_animation',
			[
				'label'   => __( 'Description Animation', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => themedraft_core_get_animation_options(),
			],
		);

		$this->add_control(
			'btn_one_text',
			[
				'label'       => __( 'Button One Text', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Get Started',
			]
		);

		$this->add_control(
			'btn_one_url',
			[
				'label'         => __( 'Button One URL', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'btn_two_text',
			[
				'label'       => __( 'Button Two Text', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Get Started',
			]
		);

		$this->add_control(
			'btn_two_url',
			[
				'label'         => __( 'Button Two URL', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'btn_animation',
			[
				'label'   => __( 'Button Animation', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => themedraft_core_get_animation_options(),
			],
		);

		$this->end_controls_section();

        

        $this->start_controls_section(
            'title_style',
            [
                'label' => esc_html__( 'Title', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typo',
                'label' => esc_html__( 'Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .banner-three-title',
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label'       => esc_html__('Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .banner-three-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_width',
            [
                'label' => esc_html__( 'Width', 'themedraft-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['%'],
                'range' => [
                    '%' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],

                'selectors' => [
                    '{{WRAPPER}} .td-banner-three-title-wrapper' => 'width: {{SIZE}}%;',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'desc_style',
            [
                'label' => esc_html__( 'Description', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'desc_typo',
                'label' => esc_html__( 'Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .td-banner-three-desc',
            ]
        );

		$this->add_responsive_control(
			'desc_width',
			[
				'label' => esc_html__( 'Width', 'themedraft-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['%'],
				'range' => [
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .td-banner-three-desc' => 'width: {{SIZE}}%;',
				],
			]
		);

		$this->add_responsive_control(
		    'desc_align',
		    [
		        'label'       => esc_html__('Description Align', 'themedraft-core'),
		        'type'        => Controls_Manager::CHOOSE,
		        'label_block' => false,

		        'options' => [
		            'left' => [
		                'title' => esc_html__('Left', 'themedraft-core'),
		                'icon'  => 'eicon-text-align-left',
		            ],

		            'center' => [
		                'title' => esc_html__('Center', 'themedraft-core'),
		                'icon'  => 'eicon-text-align-center',
		            ],

		            'right' => [
		                'title' => esc_html__('Right', 'themedraft-core'),
		                'icon'  => 'eicon-text-align-right',
		            ],
		        ],

		        'devices' => ['desktop', 'tablet', 'mobile'],

		        'selectors' => [
		            '{{WRAPPER}} .td-banner-three-desc-wrapper' => 'text-align: {{VALUE}};',
		        ],
		    ],
		);

		$this->add_responsive_control(
			'desc_text_align',
			[
				'label'       => esc_html__('Description Text Align', 'themedraft-core'),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,

				'options' => [
					'left' => [
						'title' => esc_html__('Left', 'themedraft-core'),
						'icon'  => 'eicon-text-align-left',
					],

					'center' => [
						'title' => esc_html__('Center', 'themedraft-core'),
						'icon'  => 'eicon-text-align-center',
					],

					'right' => [
						'title' => esc_html__('Right', 'themedraft-core'),
						'icon'  => 'eicon-text-align-right',
					],
				],

				'devices' => ['desktop', 'tablet', 'mobile'],

				'selectors' => [
					'{{WRAPPER}} .td-banner-three-desc' => 'text-align: {{VALUE}};',
				],
			],
		);

        $this->end_controls_section();

		$this->start_controls_section(
			'button_style_options',
			[
				'label' => esc_html__( 'Buttons', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs('td_default_and_hover_style_tabs_start');

		//Default style tab start
		$this->start_controls_tab(
			'td_btn_style_default',
			[
				'label' => esc_html__('Default', 'themedraft-core'),
			]
		);

		$this->add_control(
			'btn_one_default_bg_color',
			[
				'label'       => esc_html__('Button One Background', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-button.home-banner-three-btn-one' => 'background: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_one_default_text_color',
			[
				'label'       => esc_html__('Button One Text Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-button.home-banner-three-btn-one' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_two_default_bg_color',
			[
				'label'       => esc_html__('Button Two Background', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-button.home-banner-three-btn-two' => 'background-color: {{VALUE}};',
				],
			]
		);


		$this->add_control(
			'btn_two_default_text_color',
			[
				'label'       => esc_html__('Button Two Text Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-button.home-banner-three-btn-two' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();//Default style tab end

		//Hover style tab start
		$this->start_controls_tab(
			'td_btns_style_hover',
			[
				'label' => esc_html__('Hover', 'themedraft-core'),
			]
		);

		$this->add_control(
			'btn_one_hover_bg_color',
			[
				'label'       => esc_html__('Button One Background', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-button.home-banner-three-btn-one:hover' => 'background-color: {{VALUE}};',
				],
			]
		);


		$this->add_control(
			'btn_one_hover_text_color',
			[
				'label'       => esc_html__('Button One Text Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-button.home-banner-three-btn-one:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_two_hover_bg_color',
			[
				'label'       => esc_html__('Button Two Background', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-button.home-banner-three-btn-two:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'btn_two_hover_text_color',
			[
				'label'       => esc_html__('Button Two Text Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-button.home-banner-three-btn-two:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tabs();//Hover style tab end

		$this->end_controls_section();

        $this->start_controls_section(
            'wrapper_style',
            [
                'label' => esc_html__( 'Wrapper', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

		$this->add_responsive_control(
		    'wrapper_padding',
		    [
		        'label'      => esc_html__( 'Wrapper Padding', 'themedraft-core' ),
		        'type'       => Controls_Manager::DIMENSIONS,
		        'size_units' => [ 'px', '%', 'em' ],
		        'selectors'  => [
		            '{{WRAPPER}} .td-banner-three-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
		        ],
		    ]
		);

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'wrapper_background',
                'label' => esc_html__( 'Background', 'themedraft-core' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .td-banner-three-wrapper',
            ]
        );

        $this->end_controls_section();

	}


	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$title       = $settings['title'];
		$desc       = $settings['desc'];
		?>

        <div class="td-banner-three-wrapper td-cover-bg">
            <div class="banner-three-overlay"></div>
            <div class="container">
                <div class="row">
                    <div class="col-12">
                        <div class="td-banner-three-title-wrapper <?php echo $settings['title_animation'];?>">
                            <<?php echo $settings['title_tag'];?> class="banner-three-title">
	                            <?php echo wp_kses( $title, bizkorp_allow_html() ); ?>
                            </<?php echo $settings['title_tag'];?>>
                        </div>

                        <div class="home-banner-three-btn-wrapper <?php echo $settings['btn_animation'];?>">
                            <?php
                            $btn_one_text = $settings['btn_one_text'];
                            $btn_one_url = $settings['btn_one_url']['url'];
    
                            $btn_two_text = $settings['btn_two_text'];
                            $btn_two_url = $settings['btn_two_url']['url'];
                            ?>
                            <a class="td-button home-banner-three-btn-one" href="<?php echo $btn_one_url;?>"><?php echo $btn_one_text;?></a>
                            <?php if($btn_two_text) : ?>
                                <a class="td-button home-banner-three-btn-two" href="<?php echo $btn_two_url;?>"><?php echo $btn_two_text;?></a>
                            <?php endif; ?>
                        </div>

                    <div class="td-banner-three-desc-wrapper  <?php echo $settings['desc_animation'];?>">
                        <div class="td-banner-three-desc td-last-p-0">
			                <?php echo $desc;?>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Hero_Banner_Three_Widget );