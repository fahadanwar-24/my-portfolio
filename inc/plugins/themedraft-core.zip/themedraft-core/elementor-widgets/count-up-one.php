<?php
namespace Elementor;
class ThemeDraft_Counter_Up_One_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_counter_up_one';
	}

	public function get_title() {
		return esc_html__( 'Count Up One', 'themedraft-core' );
	}

	public function get_icon() {

		return 'td-icon eicon-counter';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	public function get_script_depends() {
		return ['counterup'];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'counter_up_options',
			[
				'label' => esc_html__( 'Counter Up', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'       => __( 'Title', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Trusted Companies',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'number',
			[
				'label'       => __( 'Number', 'themedraft-core' ),
				'label_block'       => false,
				'type'        => Controls_Manager::TEXT,
				'default'     => '100',
			]
		);

		$repeater->add_control(
			'unit',
			[
				'label'   => 'Counter Unit',
				'type'    => Controls_Manager::TEXT,
				'default' => '+',
			]
		);

		$this->add_control(
			'count_boxes',
			[
				'label'       => __('Count Box List', 'themedraft-core'),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title'        => 'Trusted Companies',
						'unit' => '+',
						'number' => '100',
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

        $this->add_control(
            'animation',
            [
                'label'   => __( 'Animation', 'themedraft-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => themedraft_core_get_animation_options(),
            ],
        );

		$this->end_controls_section();



		$this->start_controls_section(
			'count_box_column',
			[
				'label' => esc_html__( 'Column', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'xl_col',
			[
				'label'   => __( 'Columns On Desktop', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-xl-3',
				'options' => [
					'col-xl-12' => __( '1 Column', 'themedraft-core' ),
					'col-xl-6'  => __( '2 Column', 'themedraft-core' ),
					'col-xl-4'  => __( '3 Column', 'themedraft-core' ),
					'col-xl-3'  => __( '4 Column', 'themedraft-core' ),
				],
			]
		);

		$this->add_control(
			'lg_col',
			[
				'label'   => __( 'Columns On iPad Pro', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-lg-3',
				'options' => [
					'col-lg-12' => __( '1 Column', 'themedraft-core' ),
					'col-lg-6'  => __( '2 Column', 'themedraft-core' ),
					'col-lg-4'  => __( '3 Column', 'themedraft-core' ),
					'col-lg-3'  => __( '4 Column', 'themedraft-core' ),
				],
			]
		);

		$this->add_control(
			'md_col',
			[
				'label'   => __( 'Columns On iPad', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-md-6',
				'options' => [
					'col-md-12' => __( '1 Column', 'themedraft-core' ),
					'col-md-6'  => __( '2 Column', 'themedraft-core' ),
					'col-md-4'  => __( '3 Column', 'themedraft-core' ),
					'col-md-3'  => __( '4 Column', 'themedraft-core' ),
				],
			]
		);

		$this->add_control(
			'sm_col',
			[
				'label'   => __( 'Columns On  Mobile', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-6',
				'options' => [
					'col-12' => __( '1 Column', 'themedraft-core' ),
					'col-6'  => __( '2 Column', 'themedraft-core' ),
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'counter_up_option',
			[
				'label' => esc_html__( 'Counter Up', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'number_unit_color',
			[
				'label'       => esc_html__('Number & Unit Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-count-number-and-unit' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'       => esc_html__('Title Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-count-one-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'counter_up_wrapper',
			[
				'label' => esc_html__( 'Wrapper', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'box_text_align',
			[
				'label'       => esc_html__('Box Align', 'themedraft-core'),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,

				'options' => [
					'left' => [
						'title' => __('Left', 'themedraft-core'),
						'icon'  => 'eicon-text-align-left',
					],

					'center' => [
						'title' => __('Center', 'themedraft-core'),
						'icon'  => 'eicon-text-align-center',
					],

					'right' => [
						'title' => __('Right', 'themedraft-core'),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'devices' => ['desktop', 'tablet', 'mobile'],

				'selectors' => [
					'{{WRAPPER}} .td-counter-box-one' => 'text-align: {{VALUE}};',
				],

			]
		);

		$this->add_responsive_control(
			'wrapper_margin',
			[
				'label'      => esc_html__( 'Wrapper Margin', 'themedraft-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .counter-up-one-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'wrapper_padding',
			[
				'label'      => esc_html__( 'Wrapper Padding', 'themedraft-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .counter-up-one-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$count_id = rand(100, 100000);
		$col = $settings['xl_col'] . ' ' . $settings['lg_col'] . ' ' . $settings['md_col'] . ' ' . $settings['sm_col'];
		?>
		<div class="counter-up-one-wrapper td-counter-box-<?php echo esc_attr($count_id);?>">
			<div class="row">
				<?php if ( $settings['count_boxes'] ) {
					foreach ( $settings['count_boxes'] as $count_box ) {
						?>
						<div class="<?php echo $col;?>  <?php echo $settings['animation'];?>">
							<div class="td-counter-box-one">
								<div class="td-count-one-content">
									<div class="td-count-number-and-unit">
										<span class="td-count-number"><?php echo esc_html( $count_box['number'] ) ?></span><?php echo esc_html( $count_box['unit'] ) ?>
									</div>

									<div class="td-count-one-title"><?php echo esc_html( $count_box['title'] ) ?></div>
								</div>
							</div>
						</div>
						<?php
					}
				} ?>
			</div>

		</div>

		<script>
            (function ($) {
                "use strict";
                /*====  Document Ready Function =====*/
                jQuery(document).ready(function($){
                    $(".td-counter-box-<?php echo esc_attr($count_id);?> .td-count-number").counterUp({
                        delay: 10,
                        time: 2000
                    });
                });
            }(jQuery));
		</script>
		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Counter_Up_One_Widget );