<?php

namespace Elementor;

class ThemeDraft_Filterable_Gallery_Widget extends Widget_Base {

	public function get_name() {

		return "themedraft_filterable_gallery";
	}

	public function get_title() {
		return __( "Filterable Gallery", 'themedraft-core' );
	}

	public function get_icon() {

		return "td-icon eicon-gallery-grid";
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'filter_button_section',
			[
				'label' => esc_html__( 'Filter Buttons', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'enable_filter_buttons',
			[
				'label'     => esc_html__( 'Enable Filter Buttons', 'themedraft-core' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Yes', 'themedraft-core' ),
				'label_off' => esc_html__( 'No', 'themedraft-core' ),
				'default'   => 'yes',
			]
		);

		$this->add_control(
			'button_all_label',
			[
				'label'     => esc_html__( 'Button All Label', 'themedraft-core' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => 'All',
				'condition' => [
					'enable_filter_buttons' => 'yes',
				],
			]
		);

		//Repeater Start
		$repeater = new Repeater();

		$repeater->add_control(
			'button_text',
			[
				'label'       => esc_html__( 'Button Label', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     =>  'Button Text',
				'label_block' => true,
			]
		);


		$this->add_control(
			'filter_buttons',
			[
				'label'       => esc_html__( 'Button List', 'themedraft-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'button_text' => 'Button Text',
					],
				],
				'title_field' => '{{{ button_text }}}',
				'condition'   => [
					'enable_filter_buttons' => 'yes',
				],
			]
		);
		//Repeater End

		$this->add_responsive_control(
			'filter_button_align',
			[
				'label'   => esc_html__( 'Button Align', 'themedraft-core' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'themedraft-core' ),
						'icon'  => 'eicon-text-align-left',
					],

					'center' => [
						'title' => __( 'Center', 'themedraft-core' ),
						'icon'  => 'eicon-text-align-center',
					],

					'right' => [
						'title' => __( 'Right', 'themedraft-core' ),
						'icon'  => 'eicon-text-align-right',
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .td-gallery-filter-button-wrapper' => 'text-align: {{VALUE}};',
				],

				'condition'   => [
					'enable_filter_buttons' => 'yes',
				],

			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'gallery_items_section',
			[
				'label' => esc_html__( 'Gallery Items', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		//Repeater Start
		$repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'       => __( 'Title', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 5,
				'default'     => 'Digital Branding',
			]
		);

		$repeater->add_control(
			'subtitle',
			[
				'label'       => __( 'Subtitle', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Marketing',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'controls',
			[
				'label'       => esc_html__( 'Controls', 'themedraft-core' ),
				'description' => esc_html__( 'Use buttons name from Filter Buttons settings. Separate multiple name with comma (e.g. Button Name 1, Button Name 2)', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'image',
			[
				'label'   => esc_html__( 'Image', 'themedraft-core' ),
				'type'    => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);


		$repeater->add_control(
			'link',
			[
				'label'         => esc_html__( 'Item Url', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_url( 'https://your-link.com' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'gallery_items',
			[
				'label'       => esc_html__( 'Gallery Lists', 'themedraft-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title' => 'Digital Branding',
						'subtitle' => 'Marketing',
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

        $this->add_control(
            'animation',
            [
                'label'   => __( 'Animation', 'themedraft-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => themedraft_core_get_animation_options(),
            ],
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'gallery_settings',
			[
				'label' => esc_html__( 'Column Settings', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'desktop_column',
			[
				'label'   => __( 'Desktop Column', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-xl-4',
				'options' => [
					'col-xl-12' => __( '1 Column', 'themedraft-core' ),
					'col-xl-6'  => __( '2 Column', 'themedraft-core' ),
					'col-xl-4'  => __( '3 Column', 'themedraft-core' ),
				],
			]
		);

		$this->add_control(
			'ipad_pro_column',
			[
				'label'   => __( 'iPad Pro Column', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-lg-4',
				'options' => [
					'col-lg-12' => __( '1 Column', 'themedraft-core' ),
					'col-lg-6'  => __( '2 Column', 'themedraft-core' ),
					'col-lg-4'  => __( '3 Column', 'themedraft-core' ),
				],
			]
		);

		$this->add_control(
			'ipad_column',
			[
				'label'   => __( 'iPad Column', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-md-6',
				'options' => [
					'col-md-12' => __( '1 Column', 'themedraft-core' ),
					'col-md-6'  => __( '2 Column', 'themedraft-core' ),
					'col-md-4'  => __( '3 Column', 'themedraft-core' ),
				],
			]
		);

		$this->add_control(
			'mobile_column',
			[
				'label'   => __( 'Mobile Column', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-12',
				'options' => [
					'col-12' => __( '1 Column', 'themedraft-core' ),
					'col-6'  => __( '2 Column', 'themedraft-core' ),
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'filter_button_style',
			[
				'label' => esc_html__( 'Filter Button', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'enable_filter_buttons' => 'yes',
				],
			]
		);

		$this->add_control(
			'button_bg_color',
			[
				'label'       => esc_html__('Background Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-gallery-filter-button-wrapper li' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_color',
			[
				'label'       => esc_html__('Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-gallery-filter-button-wrapper li' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_active_bg_color',
			[
				'label'       => esc_html__('Hover & Active Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-gallery-filter-button-wrapper li.active,{{WRAPPER}} .td-gallery-filter-button-wrapper li:hover' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'button_active_color',
			[
				'label'       => esc_html__('Hover & Active Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-gallery-filter-button-wrapper li.active,{{WRAPPER}} .td-gallery-filter-button-wrapper li:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'mobile_filter_bg_color',
			[
				'label'       => esc_html__('Mobile Button Background', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-filter-mobile-title' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'item_style',
			[
				'label' => esc_html__( 'Gallery Item', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'overlay_bg_color',
			[
				'label'       => esc_html__('Overlay Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-project-item-details' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'top_link_bg',
			[
				'label'       => esc_html__('Details Arrow Background Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-project-item-details a' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	//Render In HTML
	protected function render() {
		$settings = $this->get_settings_for_display();
		$randId   = rand( 100, 10000 );
		$item_column = $settings['desktop_column'] . ' ' . $settings['ipad_pro_column'] . ' ' . $settings['ipad_column'] . ' ' . $settings['mobile_column'];
		?>

        <div class="td-gallery-items-main-container">
			<?php if ( $settings['enable_filter_buttons'] == 'yes' ) : ?>
                <div class="row">
                    <div class="col-lg-12 td-gallery-filter-button-wrapper <?php echo $settings['animation'];?>">
                        <div class="td-filter-mobile-title mt-<?php echo $randId ?>"><?php echo $settings['button_all_label'] ?></div>
                        <ul class="td-list-style td-list-inline td-gallery-filter-button fbtn-<?php echo $randId ?>">
                            <li class="active" data-filter="*"><span
                                        class="title-text"> <?php echo $settings['button_all_label'] ?> </span></li>
							<?php
							if ( $settings['filter_buttons'] ) {
								foreach ( $settings['filter_buttons'] as $button ) {
									echo '<li data-filter=".' . themedraft_core_class_sorter( $button['button_text'] ) . '"><span class="title-text">' . $button['button_text'] . '</span></li>';
								}
							}
							?>
                        </ul>
                    </div>
                </div>
			<?php endif; ?>


            <div class="row td-gallery-item-wrapper td-gallery-grid-<?php echo $randId ?>">

				<?php if ( $settings['gallery_items'] ) {
					foreach ( $settings['gallery_items'] as $gallery_item ) {
						$controls_name = themedraft_core_class_sorter( $gallery_item['controls'] );
						$target        = $gallery_item['link']['is_external'] ? ' target="_blank"' : '';
						$nofollow      = $gallery_item['link']['nofollow'] ? ' rel="nofollow"' : '';
						?>

                        <div class="<?php echo $item_column;?>  single-td-gallery-item <?php echo $controls_name; ?>">

                            <div class="td-single-project-item-wrapper  <?php echo $settings['animation'];?>">
                                <div class="td-single-project-item">
                                    <div class="td-project-one-image-wrapper">
                                        <img src="<?php echo $gallery_item['image']['url']; ?>" alt="<?php echo get_post_meta( $gallery_item['image']['id'], '_wp_attachment_image_alt', true ); ?>">
                                        <div class="image-animation">
                                            <img src="<?php echo $gallery_item['image']['url']; ?>" alt="<?php echo get_post_meta( $gallery_item['image']['id'], '_wp_attachment_image_alt', true ); ?>">
                                        </div>
                                        <a class="td-project-image-link" href="<?php echo esc_url( $gallery_item['link']['url'] ); ?>"></a>
                                    </div>

                                    <div class="td-project-content-wrapper">
                                        <div class="td-project-title-subtitle">
                                            <a href="<?php echo esc_url( $gallery_item['link']['url'] ); ?>" class="project-title" <?php echo  $target . $nofollow?>><?php echo $gallery_item['title'];?></a>
                                            <p class="project-subtitle"><?php echo $gallery_item['subtitle'];?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
						<?php
					}
				} ?>
            </div>
        </div>

        <script>
            jQuery(window).on('load',function ($) {

                jQuery(".td-gallery-grid-<?php echo $randId?>").imagesLoaded(function () {
                    jQuery(".mt-<?php echo $randId ?>").on("click", function () {
                        jQuery(this).toggleClass("active").next(".fbtn-<?php echo $randId?>").slideToggle();
                        return false;
                    });

                    jQuery(".fbtn-<?php echo $randId?> li").on("click", function () {
                        if (jQuery(this).hasClass("active")) return false;
                        jQuery(".mt-<?php echo $randId?>, .fbtn-<?php echo $randId?> li").removeClass("active");
                        jQuery(this).addClass("active");
                        jQuery(".mt-<?php echo $randId?>").text(jQuery(this).find(".title-text").text());
                        if (jQuery(".mt-<?php echo $randId?>").is(":visible")) jQuery(".fbtn-<?php echo $randId?>").slideUp();
                        var filterValue = jQuery(this).attr("data-filter");
                        $grid.isotope({filter: filterValue});
                    });

                    var $grid = jQuery(".td-gallery-grid-<?php echo $randId?>").isotope({
                        itemSelector: ".single-td-gallery-item",
                        percentPosition: true,
                        transitionDuration: '.8s',
                        masonry: {
                            columnWidth: 1
                        }
                    });
                });
            });
        </script>
		<?php
	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Filterable_Gallery_Widget );