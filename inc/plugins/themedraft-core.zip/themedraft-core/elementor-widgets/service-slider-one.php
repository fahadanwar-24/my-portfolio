<?php
namespace Elementor;
use ThemeDraft_Gradient_Color;
class ThemeDraft_Service_Slider_One_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_service_slider_one';
	}

	public function get_title() {
		return esc_html__( 'Service Slider One', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon flaticon-layers';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'service_slider_one_settings',
			[
				'label' => esc_html__( 'Service Box', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'       => __( 'Title', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 5,
				'default'     => 'Web Development',
			]
		);

		$repeater->add_control(
			'desc',
			[
				'label'       => __( 'Description', 'themedraft-core' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => 'Whether you\'re a small business look in streamline operations enterprise is then aiming to scale seamlessly.',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'type',
			[
				'label'       => esc_html__( 'Icon Type', 'themedraft-core' ),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options'     => [
					'icon'  => [
						'title' => esc_html__( 'Icon', 'themedraft-core' ),
						'icon'  => 'fa fa-smile',
					],
					'image' => [
						'title' => esc_html__( 'Image', 'themedraft-core' ),
						'icon'  => 'fa fa-image',
					],
				],
				'default'     => 'icon',
				'toggle'      => false,
			]
		);

		$repeater->add_control(
			'selected_icon',
			[
				'label'            => esc_html__( 'Select Icon', 'themedraft-core' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'flaticon-computer',
					'library' => 'themedraft-bizkorp-icon',
				],
				'condition'        => [
					'type' => 'icon'
				]
			]
		);

		$repeater->add_control(
			'image',
			[
				'label'     => esc_html__( 'Image', 'themedraft-core' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'type' => 'image'
				],
				'dynamic'   => [
					'active' => true,
				]
			]
		);

		$repeater->add_control(
			'details_url',
			[
				'label'         => __( 'Details Url', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'services',
			[
				'label'       => __( 'Service List', 'themedraft-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title' => 'Web Development',
						'desc' => 'Whether you\'re a small business look in streamline operations enterprise is then aiming to scale seamlessly.',
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

        $this->add_control(
            'details_btn_text',
            [
                'label'       => __( 'Button Text', 'themedraft-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => 'Get Start Now',
            ]
        );

        $this->add_control(
            'animation',
            [
                'label'   => __( 'Animation', 'themedraft-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => themedraft_core_get_animation_options(),
            ],
        );

		$this->end_controls_section();


		$this->start_controls_section(
			'service_slider_options',
			[
				'label' => esc_html__( 'Slider Options', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'desktop_count',
			[
				'label'       => __( 'Item Show On Desktop', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					1 => __( '1 Column', 'themedraft-core' ),
					2 => __( '2 Column', 'themedraft-core' ),
					3 => __( '3 Column', 'themedraft-core' ),
					4 => __( '4 Column', 'themedraft-core' ),
					5 => __( '5 Column', 'themedraft-core' ),
				],
				'default'     => 3,
			]
		);

		$this->add_control(
			'small_desktop_count',
			[
				'label'       => __( 'Item Show On Small Desktop', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					1 => __( '1 Column', 'themedraft-core' ),
					2 => __( '2 Column', 'themedraft-core' ),
					3 => __( '3 Column', 'themedraft-core' ),
					4 => __( '4 Column', 'themedraft-core' ),
					5 => __( '5 Column', 'themedraft-core' ),
				],
				'default'     => 3,
			]
		);


		$this->add_control(
			'ipad_pro_count',
			[
				'label'       => __( 'Item Show On iPad Pro', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					1 => __( '1 Column', 'themedraft-core' ),
					2 => __( '2 Column', 'themedraft-core' ),
					3 => __( '3 Column', 'themedraft-core' ),
					4 => __( '4 Column', 'themedraft-core' ),
				],
				'default'     => 2,
			]
		);

		$this->add_control(
			'tab_count',
			[
				'label'       => __( 'Item Show On Tablet', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					1 => __( '1 Column', 'themedraft-core' ),
					2 => __( '2 Column', 'themedraft-core' ),
					3 => __( '3 Column', 'themedraft-core' ),
					4 => __( '4 Column', 'themedraft-core' ),
				],
				'default'     => 2,
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label' => __( 'Autoplay', 'themedraft-core' ),
				'type' => Controls_Manager::SWITCHER,
				'show_label' => true,
				'label_block' => false,
				'default' => 'yes',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'autoplay_interval',
			[
				'label' => __( 'Autoplay Interval', 'themedraft-core' ),
				'type' => Controls_Manager::SELECT,
				'show_label' => true,
				'label_block' => false,
				'options' => [
					'2000'  => __( '2 seconds', 'themedraft-core' ),
					'3000'  => __( '3 seconds', 'themedraft-core' ),
					'4000'  => __( '4 seconds', 'themedraft-core' ),
					'5000'  => __( '5 seconds', 'themedraft-core' ),
					'6000'  => __( '6 seconds', 'themedraft-core' ),
					'7000'  => __( '7 seconds', 'themedraft-core' ),
					'8000'  => __( '8 seconds', 'themedraft-core' ),
					'9000'  => __( '9 seconds', 'themedraft-core' ),
					'10000'  => __( '10 seconds', 'themedraft-core' ),
				],
				'default' => '5000',
				'condition' => [
					'autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'stretch_to_right',
			[
				'label' => __( 'Stretch To Right', 'themedraft-core' ),
				'type' => Controls_Manager::SWITCHER,
				'show_label' => true,
				'label_block' => false,
				'default' => 'no',
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'td_service_title_style_options',
			[
				'label' => esc_html__('Title', 'themedraft-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typo',
				'label' => esc_html__( 'Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .td-service-slider-one-title',
			]
		);

		$this->add_responsive_control(
			'title_margin',
			[
				'label'      => esc_html__( 'Margin', 'themedraft-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .td-service-slider-one-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'td_service_desc_style_options',
			[
				'label' => esc_html__('Description', 'themedraft-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'desc_typo',
				'label' => esc_html__( 'Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .td-service-slider-one-desc',
			]
		);

		$this->add_responsive_control(
			'desc_margin',
			[
				'label'      => esc_html__( 'Margin', 'themedraft-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .td-service-slider-one-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'td_service_details_link_style_options',
			[
				'label' => esc_html__('Details Button', 'themedraft-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'details_btn_typo',
				'label' => esc_html__( 'Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .service-slider-one-details-btn',
			]
		);

		$this->add_responsive_control(
			'details_btn_margin',
			[
				'label'      => esc_html__( 'Margin', 'themedraft-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .service-slider-one-details-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'box_style',
            [
                'label' => esc_html__( 'Box', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs('td_default_and_hover_style_tabs_start');

        //Default style tab start
        $this->start_controls_tab(
            'td_box_style_default',
            [
                'label' => esc_html__('Default', 'themedraft-core'),
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'box_background',
                'label' => esc_html__( 'Box Background', 'themedraft-core' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .td-single-service-slider-one-item',
                'exclude' => [ 'image'],
            ]
        );

		$this->add_group_control(
			Themedraft_Gradient_Color::get_type(),
			[
				'label' => esc_html__( 'Icon Color', 'themedraft-core' ),
				'name' => 'icon_color',
				'selector' => '{{WRAPPER}} .td-service-slider-one-icon i',
			]
		);

        $this->add_control(
            'title_color',
            [
                'label'       => esc_html__('Title Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-service-slider-one-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'desc_color',
            [
                'label'       => esc_html__('Description Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-service-slider-one-desc' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();//Default style tab end

        //Hover style tab start
        $this->start_controls_tab(
            'td_box_style_hover',
            [
                'label' => esc_html__('Hover', 'themedraft-core'),
            ]
        );

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'box_hover_background',
				'label' => esc_html__( 'Box Background', 'themedraft-core' ),
				'types' => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .td-single-service-slider-one-item-hover',
				'exclude' => [ 'image'],
			]
		);

		$this->add_group_control(
			Themedraft_Gradient_Color::get_type(),
			[
				'label' => esc_html__( 'Icon Color', 'themedraft-core' ),
				'name' => 'hover_icon_color',
				'selector' => '{{WRAPPER}} .td-single-service-slider-one-item:hover .td-service-slider-one-icon i',
			]
		);

		$this->add_control(
			'hover_title_color',
			[
				'label'       => esc_html__('Title Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-single-service-slider-one-item:hover .td-service-slider-one-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'hover_desc_color',
			[
				'label'       => esc_html__('Description Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-single-service-slider-one-item:hover .td-service-slider-one-desc' => 'color: {{VALUE}};',
				],
			]
		);

        $this->end_controls_tabs();//Hover style tab end

        $this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$slider_id = rand(100, 100000);
		?>

        <div class="td-service-slider-one-wrapper">

            <div id="service-slider-id-<?php echo $slider_id;?>" class="row service-slider-one <?php if ($settings['stretch_to_right'] == 'yes'){echo 'slider-stretch';} ?>">
                <?php if ( $settings['services'] ) {
                    foreach ( $settings['services'] as $service ) {
                        $details_url      = $service['details_url']['url'];
                        $target   = $service['details_url']['is_external'] ? ' target="_blank"' : '';
                        $nofollow = $service['details_url']['nofollow'] ? ' rel="nofollow"' : '';
                        ?>
                        <div class="col-12">
                            <div class="td-single-service-slider-one-item <?php echo $settings['animation'];?>">
                                <div class="td-single-service-slider-one-item-hover"></div>
                                <div class="td-service-slider-one-icon">
                                    <?php if ( $service['type'] === 'image' && $service['image']['id'] ) : ?>
                                        <img src="<?php echo $service['image']['url']; ?>"
                                             alt="<?php echo get_post_meta( $service['image']['id'], '_wp_attachment_image_alt', true ); ?>">
                                    <?php elseif ( ! empty( $service['icon'] ) || ! empty( $service['selected_icon'] ) ) :
                                        themedraft_custom_icon_render( $service, 'icon', 'selected_icon' );?>
                                    <?php endif; ?>
                                </div>
                                <h4 class="td-service-slider-one-title"><?php echo nl2br($service['title']);?></h4>

                                <div class="td-service-slider-one-desc td-last-p-0"><?php echo $service['desc'];?></div>

                                <a href="<?php echo $details_url;?>" class="service-slider-one-details-btn">
                                    <?php echo $settings['details_btn_text'];?>
                                </a>
                            </div>
                        </div>
                    <?php }
                } ?>
            </div>

            <script>
                (function ($) {
                    "use strict";
                    $(document).ready(function () {
                        $("#service-slider-id-<?php echo $slider_id;?>").slick({
                            slidesToShow: <?php echo json_encode( $settings['desktop_count'] )?>,
                            autoplay: <?php echo json_encode($settings['autoplay'] == 'yes' ? true : false); ?>,
                            autoplaySpeed: <?php echo json_encode($settings['autoplay_interval'])?>,
                            speed: 1500, // slide speed
                            dots: false,
                            arrows: false,
                            infinite: true,
                            pauseOnHover: false,
                            centerMode: false,
                            centerPadding: 30,
                            responsive: [
                                {
                                    breakpoint: 1281,
                                    settings: {
                                        slidesToShow: <?php echo json_encode( $settings['small_desktop_count'] )?>,
                                    }
                                },
                                {
                                    breakpoint: 1025,
                                    settings: {
                                        slidesToShow: <?php echo json_encode( $settings['ipad_pro_count'] )?>, //768-991
                                    }
                                },
                                {
                                    breakpoint: 992,
                                    settings: {
                                        slidesToShow: <?php echo json_encode( $settings['tab_count'] )?>, //768-991
                                    }
                                },
                                {
                                    breakpoint: 768,
                                    settings: {
                                        slidesToShow: 1, // 0 -767
                                    }
                                }
                            ]
                        });
                    });
                })(jQuery);
            </script>

        </div>
		<?php
	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Service_Slider_One_Widget );