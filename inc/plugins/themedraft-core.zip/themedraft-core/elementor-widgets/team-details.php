<?php
namespace Elementor;

class ThemeDraft_Team_Details_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_team_details';
	}

	public function get_title() {
		return esc_html__( 'Team Details', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon flaticon-working';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'member_details_options',
			[
				'label' => esc_html__( 'Member Details', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
            'member_name',
            [
                'label'       => esc_html__( 'Name', 'themedraft-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => 'Darlene Robertson',
            ]
        );

        $this->add_control(
            'member_designation',
            [
                'label'       => esc_html__( 'Designation', 'themedraft-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => 'CEO & FOUNDER',
            ]
        );

        $this->add_control(
            'member_image',
            [
                'label'       => esc_html__( 'Image', 'themedraft-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'img_animation',
            [
                'label'   => __( 'Image Animation', 'themedraft-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => themedraft_core_get_animation_options(),
            ],
        );

        $this->add_control(
            'member_desc',
            [
                'label'       => esc_html__( 'Description', 'themedraft-core' ),
                'type'        => Controls_Manager::WYSIWYG,
                'default'     => 'Our commitment to excellence, and strategic thinking ensures that every project we udertake exceeds expectations. Whether you\'re a startup looking to establish your brand or an more established company seeking a fresh approach, we tailoor our services to meet your unique needs more lorem ipsum text like this preset.',
                'label_block' => true,
            ]
        );

        $repeater = new Repeater();

		$repeater->add_control(
            'info_text',
            [
                'label'       => esc_html__( 'Info Text', 'themedraft-core' ),
                'type'        => Controls_Manager::WYSIWYG,
                'default'     => '<a href="tel:123456">+(123) 1800-567-8990</a>',
                'label_block' => true,
            ]
        );

		$repeater->add_control(
            'selected_icon',
            [
                'label'            => esc_html__( 'Select Icon', 'themedraft-core' ),
                'type'             => Controls_Manager::ICONS,
                'fa4compatibility' => 'icon',
                'label_block'      => true,
                'default'          => [
                    'value'   => 'flaticon-phone-call',
                    'library' => 'bizkorp-icon',
                ],
            ]
        );

        $this->add_control(
            'infos',
            [
                'label'       => esc_html__( 'Info List', 'themedraft-core' ),
                'type'        => Controls_Manager::REPEATER,
                'fields'      => $repeater->get_controls(),
                'default'     => [
                    [
                        'info_text' => '<a href="tel:123456">+(123) 1800-567-8990</a>',
                    ],
                ],
                'title_field' => '{{{ info_text }}}',
            ]
        );

        $repeater = new Repeater();

		$repeater->add_control(
			'selected_social_icon',
			[
				'label'            => esc_html__( 'Select Icon', 'themedraft-core' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fab fa-facebook-f',
					'library' => 'brands',
				],
			]
		);

		$repeater->add_control(
			'profile_url',
			[
				'label'         => __( 'Profile URL', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'socials',
			[
				'label'       => __( 'Social Profile List', 'themedraft-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'selected_social_icon' => 'fab fa-facebook-f',
					],
				],
				'title_field' => '<i class="{{{selected_social_icon.value}}}"></i>',
			]
		);

		$this->add_control(
			'content_animation',
			[
				'label'   => __( 'Content Animation', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => themedraft_core_get_animation_options(),
			],
		);

		$this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
        $member_image_src = $settings['member_image']['url'];
        $member_image_alt = get_post_meta( $settings['member_image']['id'], '_wp_attachment_image_alt', true );
        $member_image_title = get_the_title( $settings['member_image']['id']);
		?>

		<div class="team-details-wrapper">
			<div class="row">
				<div class="col-xl-4">
					<div class="member-details-image <?php echo $settings['img_animation'];?>">
						<img src="<?php echo $member_image_src;?>" alt="<?php echo $member_image_alt;?>" title="<?php echo $member_image_title;?>">
					</div>
				</div>
				
				<div class="col-xl-8 my-auto">
					<div class="member-details-content <?php echo $settings['content_animation'];?>">
                        <div class="member-designation"><?php echo $settings['member_designation'];?></div>
                        <h3 class="member-name"><?php echo $settings['member_name'];?></h3>
                        <div class="member-details-desc td-last-p-0">
                            <?php echo $settings['member_desc'];?>
                        </div>

                        <div class="member-details-info-list">
                            <ul class="td-list-style">
	                            <?php if ($settings['infos']) {
		                            foreach ($settings['infos'] as $info) { ?>
                                        <li>
                                            <span class="member-details-info-icon">
                                                <?php themedraft_custom_icon_render( $info, 'icon', 'selected_icon' );?>
                                            </span>
                                            <?php echo $info['info_text'];?>
                                        </li>
		                            <?php }
	                            } ?>
                            </ul>
                        </div>

                        <div class="member-details-social">
                            <ul class="td-list-style td-list-inline">
	                            <?php if ( $settings['socials'] ) {
		                            foreach ( $settings['socials'] as $social ) {
			                            $profile_url = $social['profile_url']['url'];
			                            $target      = $social['profile_url']['is_external'] ? ' target="_blank"' : '';
			                            $nofollow    = $social['profile_url']['nofollow'] ? ' rel="nofollow"' : '';
			                            ?>
                                        <li>
                                            <a href="<?php echo $profile_url; ?>" <?php echo $target . $nofollow ?>>

                                                <i class="<?php echo $social['selected_social_icon']['value']; ?>"></i>
                                            </a>
                                        </li>
		                            <?php }
	                            } ?>
                            </ul>
                        </div>
                    </div>
				</div>
			</div>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Team_Details_Widget );