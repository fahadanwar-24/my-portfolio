<?php
namespace Elementor;
class ThemeDraft_Testimonial_Two_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_testimonial_two';
	}

	public function get_title() {
		return esc_html__( 'Testimonials Two', 'themedraft-core' );
	}

	public function get_icon() {

		return 'td-icon flaticon-quotation-1';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {

		//Content tab start
		$this->start_controls_section(
			'testimonial_settings',
			[
				'label' => esc_html__( 'Testimonial Two', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'author_name',
			[
				'label'       => __('Author Name', 'themedraft-core'),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Darrell Steward',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'designation',
			[
				'label'       => __('Designation', 'themedraft-core'),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'UI/UX Designer',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'photo',
			[
				'label'       => __( 'Top Image', 'themedraft-core' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'default'     => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'testimonial_text',
			[
				'label'   => __('Description', 'themedraft-core'),
				'type'    => Controls_Manager::WYSIWYG,
				'default' => 'It is ore long established fact that a reader will been distracted by the readable content of a page whent looking at its layout. The point of using Lorem Ipsum is that it has a more less normal.',
			]
		);

		$repeater->add_control(
			'video_image',
			[
				'label'       => __( 'Video Image', 'themedraft-core' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'default'     => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'video_url',
			[
				'label'       => __( 'Video URL', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'https://vimeo.com/100902001',
			]
		);

		$this->add_control(
			'testimonials',
			[
				'label'       => __('Testimonial List', 'themedraft-core'),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'author_name'        => 'Darrell Steward',
						'designation'        => 'UI/UX Designer',
						'testimonial_text' => 'It is ore long established fact that a reader will been distracted by the readable content of a page whent looking at its layout. The point of using Lorem Ipsum is that it has a more less normal.',
					],
				],
				'title_field' => '{{{ author_name }}}',
			]
		);

		$this->add_control(
			'image_animation',
			[
				'label'   => __( 'Image Animation', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => themedraft_core_get_animation_options(),
			],
		);

		$this->add_control(
			'content_animation',
			[
				'label'   => __( 'Content Animation', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => themedraft_core_get_animation_options(),
			],
		);

        $this->add_control(
            'selected_icon',
            [
                'label'            => esc_html__( 'Testimonial Icon', 'themedraft-core' ),
                'type'             => Controls_Manager::ICONS,
                'fa4compatibility' => 'icon',
                'label_block'      => true,
                'default'          => [
                    'value'   => 'flaticon-quotation',
                    'library' => 'themedraft-bizkorp-icon',
                ],
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'slider_options',
			[
				'label' => esc_html__( 'Slider Options', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'       => __( 'Autoplay', 'themedraft-core' ),
				'type'        => Controls_Manager::SWITCHER,
				'show_label'  => true,
				'label_block' => false,
				'default'     => 'yes',
			]
		);

		$this->add_control(
			'autoplay_interval',
			[
				'label'       => __( 'Autoplay Interval', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					'2000'  => __( '2 seconds', 'themedraft-core' ),
					'3000'  => __( '3 seconds', 'themedraft-core' ),
					'4000'  => __( '4 seconds', 'themedraft-core' ),
					'5000'  => __( '5 seconds', 'themedraft-core' ),
					'6000'  => __( '6 seconds', 'themedraft-core' ),
					'7000'  => __( '7 seconds', 'themedraft-core' ),
					'8000'  => __( '8 seconds', 'themedraft-core' ),
					'9000'  => __( '9 seconds', 'themedraft-core' ),
					'10000' => __( '10 seconds', 'themedraft-core' ),
				],
				'default'     => '4000',
				'condition'   => [
					'autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'infinity_loop',
			[
				'label'       => __( 'Loop', 'themedraft-core' ),
				'type'        => Controls_Manager::SWITCHER,
				'show_label'  => true,
				'label_block' => false,
				'default'     => 'yes',
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'video_popup_style',
			[
				'label' => esc_html__( 'Video Popup', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'video_height',
			[
				'label' => esc_html__( 'Height', 'themedraft-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .td-video-image' => 'height: {{SIZE}}px;',
				],
			]
		);


		$this->add_responsive_control(
			'btn_size',
			[
				'label' => esc_html__( 'Button Size', 'themedraft-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 150,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .td-video-button:before,{{WRAPPER}} .td-video-button:after' => 'height: {{SIZE}}px;width: {{SIZE}}px;',
				],
			]
		);

		$this->add_control('button_bg_color_note',
			[
				'label'         => '<span style="line-height: 22px;background-color: #d1ecf1;padding:10px;">Set button background color from below.</span>',
				'type'          => Controls_Manager::RAW_HTML,
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'btn_background',
				'label' => esc_html__( 'Button Background', 'themedraft-core' ),
				'types' => [ 'classic', 'gradient'],
				'selector' => '{{WRAPPER}} .td-video-button:before,{{WRAPPER}} .td-video-button:after',
			]
		);

		$this->add_control(
			'btn_color',
			[
				'label'       => esc_html__('Button Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-video-button i' => 'color: {{VALUE}};',
					'separator' => 'after',
				],
			]
		);

		$this->add_control(
			'overlay_color',
			[
				'label'       => esc_html__('Overlay Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-video-overlay' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'enable_overlay' => 'yes',
				],
			]
		);

		$this->add_responsive_control(
			'wrapper_margin',
			[
				'label'      => esc_html__( 'Margin', 'themedraft-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .td-img-with-video' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'close_icon_bg_color',
			[
				'label'       => esc_html__('Popup Close Background', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
			]
		);

		$this->add_control(
			'close_icon_cross_color',
			[
				'label'       => esc_html__('Popup Close Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
			]
		);

		$this->end_controls_section();


        $this->start_controls_section(
            'testimonial_style',
            [
                'label' => esc_html__( 'Testimonial Right Content', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'right_text_bg_color',
            [
                'label'       => esc_html__('Right Content Background', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .testimonial-two-right-content' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'right_text_border_color',
            [
                'label'       => esc_html__('Right Content Border Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .testimonial-two-right-content' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'text_color',
            [
                'label'       => esc_html__('Text Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .testimonial-two-text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'name_color',
            [
                'label'       => esc_html__('Name Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .testimonial-two-person-name' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'designation_color',
            [
                'label'       => esc_html__('Designation Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .testimonial-two-person-designation' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'text_content_padding',
            [
                'label'      => esc_html__( 'Content Padding', 'themedraft-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .testimonial-two-right-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
			'right_icon_bg_color',
			[
				'label'       => esc_html__('Right Icon Background', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-testimonial-two-icon' => 'background-color: {{VALUE}};',
				],
			]
		);

        $this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
        $slide_id = rand(100, 100000);
		?>

        <div class="td-testimonial-two-wrapper" id="td-testimonial-slider-<?php echo esc_attr($slide_id);?>">
	        <?php if($settings['testimonials']){
	        foreach ($settings['testimonials'] as $testimonial){
                $img_src = $testimonial['photo']['url'];
                $image_alt = get_post_meta( $testimonial['photo']['id'], '_wp_attachment_image_alt', true );
                $image_title = get_the_title( $testimonial['photo']['id']);
	        ?>
            <div class="td-testimonial-two-item">
                <div class="row">
                    <div class="col-xl-6">
                        <div class="testimonial-video-wrapper <?php echo $settings['image_animation'];?>">
                            <div class="td-img-with-video">
                                <div class="td-video-image td-cover-bg" style="background-image: url(<?php echo $testimonial['video_image']['url'];?>);">
                                    <a href="<?php echo $testimonial['video_url'];?>" class="td-video-button mfp-iframe">
                                        <i class="fas fa-play"></i>
                                    </a>
                                </div>
                            </div>

                            <script>
                                jQuery(document).ready(function ($) {
                                    $(".td-video-button").magnificPopup({
                                        type: 'video',
                                        mainClass: 'td-mfp-<?php echo $this->get_id();?>',
                                    });
                                });
                            </script>
                        </div>
                    </div>

                    <div class="col-xl-6">
                        <div class="testimonial-two-right-content-wrapper <?php echo $settings['content_animation'];?>">
                            <div class="testimonial-two-right-content">
                                <div class="testimonial-two-top-image">
                                    <img src="<?php echo esc_url ($img_src);?>" alt="<?php echo esc_url ($image_alt);?>" title="<?php echo esc_html ($image_title);?>">
                                </div>

                                <div class="testimonial-two-text td-last-p-0">
                                    <?php echo wp_kses($testimonial['testimonial_text'], bizkorp_allow_html());?>
                                </div>

                                <div class="testimonial-two-person">
                                    <span class="testimonial-two-person-name"><?php echo esc_html($testimonial['author_name']);?></span>
                                    <span class="testimonial-two-person-designation"><?php echo esc_html($testimonial['designation']);?></span>
                                </div>

                                <div class="td-testimonial-two-icon">
                                    <?php themedraft_custom_icon_render( $settings, 'icon', 'selected_icon' );?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
		        <?php
	        }
	        } ?>
        </div>

        <script>
            (function ($) {
                "use strict";
                $(document).ready(function () {
                    $("#td-testimonial-slider-<?php echo esc_attr($slide_id);?>").slick({
                        slidesToShow: 1,
                        autoplay: <?php echo json_encode( $settings['autoplay'] == 'yes' ? true : false ); ?>,
                        autoplaySpeed: <?php echo json_encode( $settings['autoplay_interval'] )?>, //interval
                        speed: 1500, // slide speed
                        dots: false,
                        arrows: false,
                        fade: true,
                        infinite: <?php echo json_encode( $settings['infinity_loop'] == 'yes' ? true : false ); ?>,
                        pauseOnHover: false,
                        centerMode: false,
                    });
                });
            })(jQuery);
        </script>

		<?php if ($settings['close_icon_bg_color']) :?>
            <style>
                .td-mfp-<?php echo $this->get_id();?> .mfp-close{
                    background-color: <?php echo $settings['close_icon_bg_color'];?>;
                    color: <?php echo $settings['close_icon_cross_color'];?>;

                }
            </style>
		<?php endif; ?>

		<?php
	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Testimonial_Two_Widget );