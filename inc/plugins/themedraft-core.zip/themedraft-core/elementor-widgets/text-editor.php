<?php

namespace Elementor;
class ThemeDraft_Text_Editor_One_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_text_editor_one';
	}

	public function get_title() {
		return esc_html__( 'Text Editor', 'themedraft-core' );
	}

	public function get_icon() {

		return 'td-icon eicon-text';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'text_options',
			[
				'label' => esc_html__( 'Text', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
		    'text',
		    [
		        'label'       => __( 'Text', 'themedraft-core' ),
		        'type'        => Controls_Manager::WYSIWYG,
		        'default'     => 'Whether you\'re a small business looking to streamline operations or an enterprise aiming to scale seamlessly, our platform offers cutting-edge tools.',
		        'label_block' => true,
		    ]
		);

		$this->add_control(
		    'enable_border',
		    [
		        'label'     => esc_html__( 'Enable Left Border', 'themedraft-core' ),
		        'type'      => Controls_Manager::SWITCHER,
		        'label_on'  => esc_html__( 'Yes', 'themedraft-core' ),
		        'label_off' => esc_html__( 'No', 'themedraft-core' ),
		        'default'   => 'yes',
		    ]
		);

		$this->add_control(
			'animation',
			[
				'label'   => __( 'Animation', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => themedraft_core_get_animation_options(),
			],
		);

		$this->end_controls_section();

		$this->start_controls_section(
		    'text_style',
		    [
		        'label' => esc_html__( 'Text', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

		$this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
		        'name' => 'text_typo',
		        'label' => esc_html__( 'Typography', 'themedraft-core' ),
		        'selector' => '{{WRAPPER}} .td-text-editor-text',
		    ]
		);

		$this->add_control(
		    'text_color',
		    [
		        'label'       => esc_html__('Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-text-editor-text' => 'color: {{VALUE}};',
		        ],
		    ]
		);

		$this->add_control(
		    'left_border_color',
		    [
		        'label'       => esc_html__('Left Border Color', 'themedraft-core'),
		        'type'        => Controls_Manager::COLOR,
		        'selectors'   => [
		            '{{WRAPPER}} .td-text-editor-text.left-border-enable' => 'border-color: {{VALUE}};',
		        ],
                'condition' => [
                    'enable_border' => 'yes',
                ],
		    ]
		);

		$this->add_responsive_control(
		    'text_margin',
		    [
		        'label'      => esc_html__( 'Margin', 'themedraft-core' ),
		        'type'       => Controls_Manager::DIMENSIONS,
		        'size_units' => [ 'px', '%', 'em' ],
		        'selectors'  => [
		            '{{WRAPPER}} .td-text-editor-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
		        ],
		    ]
		);

		$this->add_responsive_control(
		    'text_padding',
		    [
		        'label'      => esc_html__( 'Padding', 'themedraft-core' ),
		        'type'       => Controls_Manager::DIMENSIONS,
		        'size_units' => [ 'px', '%', 'em' ],
		        'selectors'  => [
		            '{{WRAPPER}} .td-text-editor-text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
		        ],
		    ]
		);

		$this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<div class="td-text-editor-text-wrapper">
			<div class="td-text-editor-text <?php echo $settings['animation']; if ($settings['enable_border']=='yes'){echo ' left-border-enable';}?>">
				<?php echo wp_kses($settings['text'], bizkorp_allow_html());?>
			</div>
		</div>

		<?php
	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Text_Editor_One_Widget );