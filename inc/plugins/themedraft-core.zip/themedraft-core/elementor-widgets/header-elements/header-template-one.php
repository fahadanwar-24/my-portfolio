<?php
namespace Elementor;
class ThemeDraft_Header_Template_One_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_header_template_one';
	}

	public function get_title() {
		return esc_html__( 'Header Template One', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon flaticon-sections';
	}

	public function get_categories() {
		return [ 'themedraft_header_template' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'logo_settings',
			[
				'label' => esc_html__( 'Logo & Menu', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'logo',
			[
				'label'       => __( 'Logo', 'themedraft-core' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'default'     => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->add_responsive_control(
			'logo_width',
			[
				'label' => esc_html__( 'Logo Width', 'themedraft-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .site-branding a img' => 'width: {{SIZE}}px;max-width: {{SIZE}}px;',
				],
			]
		);

		$this->add_responsive_control(
			'logo_height',
			[
				'label' => esc_html__( 'Logo Height', 'themedraft-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .site-branding a img' => 'height: {{SIZE}}px;max-height: {{SIZE}}px;',
				],
			]
		);

		$this->add_control(
			'menu_list',
			[
				'label'   => __( 'Select Menu', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' =>themedraft_get_custom_menu(),
			]
		);

        $this->add_responsive_control(
            'menu_align',
            [
                'label'       => esc_html__('Menu Align', 'themedraft-core'),
                'type'        => Controls_Manager::CHOOSE,
                'label_block' => false,
                'options' => [
                    'left' => [
                        'title' => __('Left', 'themedraft-core'),
                        'icon'  => 'eicon-text-align-left',
                    ],

                    'center' => [
                        'title' => __('Center', 'themedraft-core'),
                        'icon'  => 'eicon-text-align-center',
                    ],

                    'right' => [
                        'title' => __('Right', 'themedraft-core'),
                        'icon'  => 'eicon-text-align-right',
                    ],
                ],

                'devices' => ['desktop', 'tablet', 'mobile'],

                'selectors' => [
                    '{{WRAPPER}} .td-header-template-one .header-navigation-area' => 'text-align: {{VALUE}};',
                ],

            ]
        );

        $this->add_control(
            'sticky_header',
            [
                'label'     => esc_html__( 'Sticky Menu', 'themedraft-core' ),
                'type'      => Controls_Manager::SWITCHER,
                'label_on'  => esc_html__( 'Yes', 'themedraft-core' ),
                'label_off' => esc_html__( 'No', 'themedraft-core' ),
                'default'   => 'yes',
            ]
        );

		$this->add_control(
			'sticky_logo',
			[
				'label'       => __( 'Sticky Logo', 'themedraft-core' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
                'condition' => [
                    'sticky_header' => 'yes',
                ],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'header_buttons',
			[
				'label' => esc_html__( 'Buttons', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);


		$this->add_control(
			'enable_cta_btn',
			[
				'label'     => esc_html__( 'Enable CTA Button', 'themedraft-core' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Yes', 'themedraft-core' ),
				'label_off' => esc_html__( 'No', 'themedraft-core' ),
				'default'   => 'yes',
			]
		);

        $this->add_control(
            'cta_btn_text',
            [
                'label'       => __( 'Button One Text', 'themedraft-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => 'Get Started',
                'condition' => [
                    'enable_cta_btn' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'cta_url',
            [
                'label'         => __( 'Button One URL', 'themedraft-core' ),
                'type'          => Controls_Manager::URL,
                'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
                'show_external' => true,
                'default'       => [
                    'url'         => '',
                    'is_external' => false,
                    'nofollow'    => false,
                ],
                'condition' => [
	                'enable_cta_btn' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'btn_1_icon',
            [
                'label'            => esc_html__( 'Button One Icon', 'themedraft-core' ),
                'type'             => Controls_Manager::ICONS,
                'fa4compatibility' => 'icon',
                'label_block'      => true,
                'default'          => [
                    'value'   => 'icon-button-arrow-one',
                    'library' => 'bizkorp-icon',
                ],
                'condition' => [
	                'enable_cta_btn' => 'yes',
                ],
            ]
        );

		$this->add_control(
			'cta_btn2_text',
			[
				'label'       => __( 'Button Two Text', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'condition' => [
					'enable_cta_btn' => 'yes',
				],
			]
		);

		$this->add_control(
			'cta2_url',
			[
				'label'         => __( 'Button Two URL', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
				'condition' => [
					'enable_cta_btn' => 'yes',
					'cta_btn2_text!' => '',
				],
			]
		);

		$this->add_control(
			'btn_2_icon',
			[
				'label'            => esc_html__( 'Button Two Icon', 'themedraft-core' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'icon-button-arrow-one',
					'library' => 'bizkorp-icon',
				],
				'condition' => [
					'enable_cta_btn' => 'yes',
					'cta_btn2_text!' => '',
				],
			]
		);

        $this->add_responsive_control(
            'header_button_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'themedraft-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],

                'selectors' => [
                    '{{WRAPPER}} .td-button.td-header-btn-1,{{WRAPPER}} .td-button.td-header-btn-2' => 'border-radius: {{SIZE}}px;',
                ],
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'menu_area',
			[
				'label' => esc_html__( 'Menu Area', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'menu_typo',
                'label' => esc_html__( 'Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .main-navigation ul li a',
            ]
        );

		$this->add_control(
			'menu_color',
			[
				'label'       => esc_html__('Menu Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .main-navigation ul li a' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'active_menu_color',
			[
				'label'       => esc_html__('Active / Hover Menu Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .main-navigation ul li a:hover,{{WRAPPER}} .main-navigation ul li.current-menu-item > a,{{WRAPPER}} .main-navigation ul li.current_page_item > a,{{WRAPPER}} .main-navigation ul li.current-menu-ancestor > a,{{WRAPPER}} .main-navigation ul li.current_page_ancestor > a' => 'color: {{VALUE}};',
				],
			]
		);

        $this->add_control('overlay_color_note',
            [
                'label'         => '<span style="line-height: 22px;background-color: #d1ecf1;padding:10px;">Select Active / Hover Menu Background from below.</span>',
                'type'          => Controls_Manager::RAW_HTML,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'active_menu_bg_color',
                'label' => esc_html__( 'Active / Hover Menu Background', 'themedraft-core' ),
                'types' => ['gradient' ],
                'exclude' => [ 'image'],
                'selector' => '{{WRAPPER}} .main-navigation ul li a:after',
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
		    'dropdown_menu_style',
		    [
		        'label' => esc_html__( 'Dropdown Menu', 'themedraft-core' ),
		        'tab'   => Controls_Manager::TAB_STYLE,
		    ]
		);

        $this->add_control(
            'background_color',
            [
                'label'       => esc_html__('Background Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .main-navigation ul li ul' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'dm_text_color',
            [
                'label'       => esc_html__('Text Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .main-navigation ul li ul li a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'dm_active_color',
            [
                'label'       => esc_html__('Hover Text Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
	                '{{WRAPPER}} .main-navigation ul li ul li a:hover,{{WRAPPER}} .main-navigation ul li ul li.current-menu-item > a,{{WRAPPER}} .main-navigation ul li ul li.current_page_item > a,{{WRAPPER}} .main-navigation ul li ul li.current-menu-ancestor > a,{{WRAPPER}} .main-navigation ul li ul li.current_page_ancestor > a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'dm_bottom_border_color',
            [
                'label'       => esc_html__('Bottom Border Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .main-navigation ul li ul li' => 'border-color: {{VALUE}};',
                ],
            ]
        );

		$this->end_controls_section();



		// Start Button section
		$this->start_controls_section(
		    'td_button_one_style_options',
		    [
		        'label' => esc_html__('Buttons One Style', 'themedraft-core'),
		        'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'enable_cta_btn' => 'yes',
                ],
		    ]
		);

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'btn_one_typo',
                'label' => esc_html__( 'Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .td-button.td-header-btn-1',
            ]
        );

		$this->start_controls_tabs('td_button_one_style_tabs');

		//Default style tab start
		$this->start_controls_tab(
		    'td_btn_one_style_default',
		    [
		        'label' => esc_html__('Default', 'themedraft-core'),
		    ]
		);

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'cta_one_background',
                'label' => esc_html__( 'Background', 'themedraft-core' ),
                'types' => [ 'classic', 'gradient' ],
                'exclude' => [ 'image' ],
                'selector' => '{{WRAPPER}} .td-button.td-gradient-button.td-header-btn-1',
            ]
        );

		$this->add_control(
			'cta_btn_color',
			[
				'label'       => esc_html__('Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-button.td-header-btn-1' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();//Default style tab end

		//Hover style tab start
		$this->start_controls_tab(
		    'td_one_btn_style_hover',
		    [
		        'label' => esc_html__('Hover', 'themedraft-core'),
		    ]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'cta_one_hover_background',
				'label' => esc_html__( 'Background', 'themedraft-core' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .td-button.td-gradient-button.td-header-btn-1:after',
			]
		);

		$this->add_control(
			'cta_btn_hover_color',
			[
				'label'       => esc_html__('Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-button.td-header-btn-1:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tabs();//Hover style tab end

		$this->end_controls_section();// End Button section

		// Start Button 2 section
		$this->start_controls_section(
			'td_button_2_style_options',
			[
				'label' => esc_html__('Buttons Two Style', 'themedraft-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'enable_cta_btn' => 'yes',
					'cta_btn2_text!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'btn_two_typo',
				'label' => esc_html__( 'Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .td-button.td-header-btn-2',
			]
		);

		$this->start_controls_tabs('td_button_2_style_tabs');

		//Default style tab start
		$this->start_controls_tab(
			'td_btn_2_style_default',
			[
				'label' => esc_html__('Default', 'themedraft-core'),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'cta_two_background',
				'label' => esc_html__( 'Background', 'themedraft-core' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .td-button.td-gradient-button.td-header-btn-2',
			]
		);

		$this->add_control(
			'cta_btn2_color',
			[
				'label'       => esc_html__('Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-button.td-header-btn-2' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();//Default style tab end

		//Hover style tab start
		$this->start_controls_tab(
			'td_2_btn_style_hover',
			[
				'label' => esc_html__('Hover', 'themedraft-core'),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'cta_two_hover_background',
				'label' => esc_html__( 'Background', 'themedraft-core' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .td-button.td-gradient-button.td-header-btn-2:hover:after',
			]
		);

		$this->add_control(
			'cta_btn2_hover_color',
			[
				'label'       => esc_html__('Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-button.td-header-btn-2:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tabs();//Hover style tab end

		$this->end_controls_section();// End Button 2 section

        $this->start_controls_section(
            'header_wrapper',
            [
                'label' => esc_html__( 'Wrapper', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'wrapper_bg',
            [
                'label'       => esc_html__('Background Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .main-menu-area' => 'background-color: {{VALUE}};',
                ],
            ]
        );

		$this->add_control(
			'bottom_border_color',
			[
				'label'       => esc_html__('Bottom Border Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .main-menu-area' => 'border-bottom: 1px solid {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'wrapper_width',
			[
				'label' => esc_html__( 'Container Max Width', 'themedraft-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 1200,
						'max' => 2500,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .td-header-template-one .container' => 'max-width: {{SIZE}}px;',
				],
			]
		);

        $this->add_control(
            'wrapper_position',
            [
                'label'   => __( 'Wrapper Position', 'themedraft-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => 'wrapper-relative',
                'options' => [
                    'wrapper-relative' => __( 'Relative', 'themedraft-core' ),
                    'wrapper-absolute'  => __( 'Absolute', 'themedraft-core' ),
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'sticky_header_options',
            [
                'label' => esc_html__( 'Sticky Header', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'sticky_header' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'sticky_menu_bg',
            [
                'label'       => esc_html__('Background Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} header .main-menu-area.uk-sticky-fixed' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'sticky_menu_color',
            [
                'label'       => esc_html__('Text Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} header .main-menu-area.uk-sticky-fixed .main-navigation ul li a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'sticky_menu_active_color',
            [
                'label'       => esc_html__('Active Menu Text Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} header .main-menu-area.uk-sticky-fixed .main-navigation ul li.current-menu-item > a,{{WRAPPER}} header .main-menu-area.uk-sticky-fixed .main-navigation ul li a:hover,{{WRAPPER}} header .main-menu-area.uk-sticky-fixed .main-navigation ul li.current-menu-ancestor > a,{{WRAPPER}} header .main-menu-area.uk-sticky-fixed .main-navigation ul li.current_page_ancestor > a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'sticky_menu_bottom_border_color',
            [
                'label'       => esc_html__('Bottom Border Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .main-menu-area.uk-sticky-fixed' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'sticky_dropdown_active_color',
            [
                'label'       => esc_html__('Dropdown Active Menu Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} header .main-menu-area.uk-sticky-fixed .main-navigation ul li ul li a:hover,{{WRAPPER}} header .main-menu-area.uk-sticky-fixed .main-navigation ul li ul .current-menu-ancestor > a,{{WRAPPER}} header .main-menu-area.uk-sticky-fixed .main-navigation ul li ul li.current_page_item > a,{{WRAPPER}} header .main-menu-area.uk-sticky-fixed .main-navigation ul li ul li.current-menu-item a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'mobile_options',
			[
				'label' => esc_html__( 'Mobile Menu', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'menu_note_one',
			[
				'label' => esc_html__( '**', 'themedraft-core' ),
				'type' => Controls_Manager::RAW_HTML,
				'label_block' => false,
				'raw' => esc_html__( 'Color below use as mobile menu trigger icon color', 'themedraft-core' ),
			]
		);

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'mobile_menu_trigger_color',
                'label' => esc_html__( 'Trigger Icon Color', 'themedraft-core' ),
                'types' => [ 'classic', 'gradient'],
                'exclude' => [ 'image'],
                'selector' => '{{WRAPPER}} .td-header-template-one .mobile-menu-trigger span',
                'separator' => 'after',
                'label_block' => false,
            ]
        );


		$this->add_control(
			'menu_note_two',
			[
				'label' => esc_html__( '**', 'themedraft-core' ),
				'type' => Controls_Manager::RAW_HTML,
				'raw' => esc_html__( 'Color below use as mobile menu trigger icon color when header is sticky', 'themedraft-core' ),
				'label_block' => false,
			]
		);

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'sticky_mobile_menu_trigger_color',
                'label' => esc_html__( 'Sticky Trigger Icon Color', 'themedraft-core' ),
                'types' => [ 'classic', 'gradient'],
                'exclude' => [ 'image'],
                'selector' => '{{WRAPPER}} .td-header-template-one .uk-sticky-fixed .mobile-menu-trigger span',
                'label_block' => false,
            ]
        );

        $this->add_control(
            'mobile_menu_bg_color',
            [
                'label'       => esc_html__('Background Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .mobile-menu-container' => 'background-color: {{VALUE}};',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'mobile_menu_text_color',
            [
                'label'       => esc_html__('Text Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .slicknav_nav a,{{WRAPPER}} .slicknav_row a' => 'color: {{VALUE}};',
                ],
            ]
        );

		$this->add_control(
			'active_menu_text_color',
			[
				'label'       => esc_html__('Active Menu Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .slicknav_nav a:hover,{{WRAPPER}} .slicknav_item.slicknav_row:hover a,{{WRAPPER}} .slicknav_item.slicknav_row:hover .slicknav_arrow,{{WRAPPER}} .slicknav_menu .current-menu-item>a,{{WRAPPER}} .slicknav_menu .current-menu-ancestor>a,{{WRAPPER}} .slicknav_menu .current-menu-ancestor>.slicknav_row>a,{{WRAPPER}} .current-menu-ancestor>.slicknav_row .slicknav_arrow' => 'color: {{VALUE}};',
				],
			]
		);

        $this->add_control(
            'menu_border_color',
            [
                'label'       => esc_html__('Border Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .slicknav_nav li a' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'close_icon_color',
            [
                'label'       => esc_html__('Close Icon Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .mobile-menu-close::before,{{WRAPPER}} .mobile-menu-close::after' => 'background-color: {{VALUE}};',
                ],
            ]
        );

		$this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>
        <div class="mobile-menu-container">
            <div class="mobile-menu-close"></div>
            <div id="mobile-menu-wrap"></div>
        </div>

        <header class="header-area site-header">
            <div id="td-header-template-one" class="td-header-builder td-header-template-one <?php echo esc_attr($settings['wrapper_position']);?>">
                <div class="main-menu-area" <?php if($settings['sticky_header'] == 'yes' ){echo 'data-uk-sticky="top: 250; animation: uk-animation-slide-top;"';} ?>>
                    <div class="container">
                        <div class="row">
                            <div class="col-12">
                                <div class="td-header-two-wrapper">
                                    <div class="row align-items-center">
                                        <div class="col-lg-2 col-sm-3 col-6">
                                            <div class="site-branding<?php if ($settings['sticky_header'] == 'yes' && $settings['sticky_logo']['url']){echo ' td-have-sticky-logo';}?>">
                                                <a href="<?php echo esc_url( home_url( '/' ) ); ?>">
                                                    <?php
                                                    $logo_alt = get_post_meta( $settings['logo']['id'], '_wp_attachment_image_alt', true );
                                                    $logo_title = get_the_title( $settings['logo']['id']);
                                                    ?>
                                                    <img class="td-site-default-logo" src="<?php echo $settings['logo']['url'] ?>" alt="<?php echo $logo_alt;?>" title="<?php echo $logo_title;?>">
                                                    <?php if ($settings['sticky_header'] == 'yes' && $settings['sticky_logo']['url']) :?>
                                                    <img class="td-site-sticky-logo"  src="<?php echo $settings['sticky_logo']['url'] ?>" alt="<?php echo $logo_alt;?>" title="<?php echo $logo_title;?>">
                                                    <?php endif; ?>
                                                </a>
                                            </div>
                                        </div>

                                        <div class="col-lg-10 col-sm-9 col-6">
                                            <div class="header-nav-and-buttons">
                                                <div class="header-navigation-area">
                                                    <nav id="site-navigation" class="main-navigation td-list-style">
                                                        <?php
                                                        if($settings['menu_list']){
                                                            $header_menu = $settings['menu_list'];
                                                        }else{
                                                            $header_menu = '';
                                                        }

                                                        wp_nav_menu( array(
                                                            'menu'            => $header_menu,
                                                            'theme_location'  => 'main-menu',
                                                            'menu_id'         => 'main-menu',
                                                            'container_class' => 'main-menu-container',
                                                        ) );
                                                        ?>
                                                    </nav><!-- #site-navigation -->
                                                </div>
                                                <div class="header-buttons-area">
                                                    <ul class="header-buttons-wrapper td-list-style">
                                                        <?php if($settings['enable_cta_btn'] == 'yes'):?>
                                                        <li class="header-cta-button">
                                                            <a class="td-button td-gradient-button td-header-btn-1" href="<?php echo $settings['cta_url']['url'];?>">
                                                                <span><?php echo $settings['cta_btn_text'];?>
                                                                <?php if ( ! empty( $settings['btn_1_icon'] ) ) :
                                                                    themedraft_custom_icon_render( $settings, 'icon', 'btn_1_icon' );
                                                                endif; ?>
                                                                </span>
                                                            </a>
                                                            <?php if($settings['cta_btn2_text']) :?>
                                                            <a class="td-button td-gradient-button td-header-btn-2" href="<?php echo $settings['cta2_url']['url'];?>">
                                                                <span><?php echo $settings['cta_btn2_text'];?>
                                                                <?php if ( ! empty( $settings['btn_2_icon'] ) ) :
                                                                    themedraft_custom_icon_render( $settings, 'icon', 'btn_2_icon' );
                                                                endif; ?>
                                                                </span>
                                                            </a>
                                                            <?php endif;?>
                                                        </li>
                                                        <?php endif; ?>

                                                        <li class="mobile-menu-trigger"><span></span><span></span><span></span></li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>
		<?php
	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Header_Template_One_Widget );