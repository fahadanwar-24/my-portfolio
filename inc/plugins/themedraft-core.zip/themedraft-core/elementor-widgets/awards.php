<?php
namespace Elementor;

class ThemeDraft_Award_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_award_one';
	}

	public function get_title() {
		return esc_html__( 'Awards One', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon flaticon-discount';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'awards_options',
			[
				'label' => esc_html__( 'Awards', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
		    'title',
		    [
		        'label'       => __( 'Title', 'themedraft-core' ),
		        'type'        => Controls_Manager::TEXT,
		        'default'     => 'Dribble Award',
		        'label_block' => true,
		    ]
		);

		$repeater->add_control(
		    'year',
		    [
		        'label'       => __( 'Year', 'themedraft-core' ),
		        'label_block'       => true,
		        'type'        => Controls_Manager::TEXT,
		        'default'     => '2025 /',
		    ]
		);

		$repeater->add_control(
		    'award_category',
		    [
		        'label'       => __( 'Award Category', 'themedraft-core' ),
		        'label_block'       => true,
		        'type'        => Controls_Manager::TEXT,
		        'default'     => 'Audience Choice',
		    ]
		);

		$repeater->add_control(
		    'award_details',
		    [
		        'label'         => __( 'Details URL', 'themedraft-core' ),
		        'type'          => Controls_Manager::URL,
		        'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
		        'show_external' => true,
		        'default'       => [
		            'url'         => '',
		            'is_external' => false,
		            'nofollow'    => false,
		        ],
		    ]
		);

		$this->add_control(
		    'awards',
		    [
		        'label'       => __( 'Awards List', 'themedraft-core' ),
		        'type'        => Controls_Manager::REPEATER,
		        'fields'      => $repeater->get_controls(),
		        'default'     => [
		            [
		                'title' => __( 'Dribble Award', 'themedraft-core' ),
		                'year' => '2025 /',
		                'award_category' => 'Audience Choice',
		            ],
		        ],
		        'title_field' => '{{{ title }}}',
		    ]
		);

        $this->add_control(
            'animation',
            [
                'label'   => __( 'Animation', 'themedraft-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => themedraft_core_get_animation_options(),
            ],
        );


		$this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<div class="awards-wrapper">
            <?php if($settings['awards']){
                foreach ($settings['awards'] as $award){ ?>
                    <div class="award-one-item <?php echo $settings['animation'];?>">
                        <div class="award-winning-year">
                            <?php echo $award['year'];?>
                        </div>
                        <div class="award-title-and-catagory">
                            <h6 class="award-title"><?php echo $award['title'];?></h6>
                            <span class="award-category"><?php echo $award['award_category'];?></span>
                        </div>
                        <div class="award-details">
                            <a href="<?php echo $award['award_details']['url'];?>">
                                <i class="flaticon-right-arrow-1"></i>
                            </a>
                        </div>
                    </div>
            <?php    }
            } ?>
		</div>

		<?php
	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Award_Widget );