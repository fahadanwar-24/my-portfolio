<?php
namespace Elementor;

class ThemeDraft_Pricing_Table_One_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_pricing_table_one';
	}

	public function get_title() {
		return esc_html__( 'Pricing Table One', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon flaticon-pricing';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	protected function register_controls() {
		$this->start_controls_section(
			'pricing_options',
			[
				'label' => esc_html__( 'Pricing Options', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'title',
			[
				'label'       => __( 'Title', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Regular Plan',
			]
		);

        $this->add_control(
            'table_icon',
            [
                'label'            => esc_html__( 'Table Icon', 'themedraft-core' ),
                'type'             => Controls_Manager::ICONS,
                'fa4compatibility' => 'icon',
                'label_block'      => true,
                'default'          => [
                    'value'   => 'flaticon-promotion',
                    'library' => 'themedraft-bizkorp-icon',
                ],
            ]
        );

        $this->add_control(
            'top_image',
            [
                'label'       => __( 'Top Image', 'themedraft-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

		$this->add_control(
			'price',
			[
				'label'       => __( 'Price', 'themedraft-core' ),
				'label_block'       => false,
				'type'        => Controls_Manager::TEXT,
				'default'     => '$250',
			]
		);

		$this->add_control(
			'time_duration',
			[
				'label'       => __( 'Duration', 'themedraft-core' ),
				'label_block'       => false,
				'type'        => Controls_Manager::TEXT,
				'default'     => '/ Month',
			]
		);

		$this->add_control(
			'btn_text',
			[
				'label'       => __( 'Button Text', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Purchase Now',
			]
		);

		$this->add_control(
			'button_link',
			[
				'label'         => __( 'Button Link', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '#',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

        $this->add_control(
            'animation',
            [
                'label'   => __( 'Animation', 'themedraft-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => themedraft_core_get_animation_options(),
            ],
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'features_list_settings',
			[
				'label' => esc_html__( 'Pricing Features', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'text',
			[
				'label'       => __( 'Text', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => __( 'List Item Text', 'themedraft-core' ),
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'selected_icon',
			[
				'label'            => __( 'Icon', 'themedraft-core' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'fas fa-check-circle',
					'library' => 'solid',
				],
			]
		);

		$repeater->add_control(
			'item_link',
			[
				'label'         => __( 'Link', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'list_items',
			[
				'label'       => __( 'List', 'themedraft-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'text' => __( 'List Item Text', 'themedraft-core' ),
					],
				],
				'title_field' => '{{{ text }}}',
			]
		);
		$this->end_controls_section();

		$this->start_controls_section(
			'pricing_style_options',
			[
				'label' => esc_html__( 'Pricing Style', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->start_controls_tabs('td_default_and_hover_style_tabs_start');

		//Default style tab start
		$this->start_controls_tab(
		    'td_team_style_default',
		    [
		        'label' => esc_html__('Default', 'themedraft-core'),
		    ]
		);

        $this->add_control('overlay_one_color_note',
            [
                'label'         => '<span style="line-height: 22px;background-color: #d1ecf1;padding:10px;">Set top overlay color from below.</span>',
                'type'          => Controls_Manager::RAW_HTML,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'top_overlay_bg_color',
                'label' => esc_html__( 'Overlay Background', 'themedraft-core' ),
                'types' => [ 'classic', 'gradient' ],
                'exclude' => [ 'image' ],
                'selector' => '{{WRAPPER}} .td-price-one-top-overlay',
            ]
        );

        $this->add_control('icon_bg_color_note_one',
            [
                'label'         => '<span style="line-height: 22px;background-color: #d1ecf1;padding:10px;">Set icon background color from below.</span>',
                'type'          => Controls_Manager::RAW_HTML,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'default_icon_bg_color',
                'label' => esc_html__( 'Icon Background', 'themedraft-core' ),
                'types' => [ 'classic', 'gradient' ],
                'exclude' => [ 'image' ],
                'selector' => '{{WRAPPER}} .td-price-one-top-content .top-icon',
            ]
        );

		$this->add_control('btn_bg_color_note_one',
			[
				'label'         => '<span style="line-height: 22px;background-color: #d1ecf1;padding:10px;">Set button background color from below.</span>',
				'type'          => Controls_Manager::RAW_HTML,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'default_btn_bg_color',
				'label' => esc_html__( 'Button Background', 'themedraft-core' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .td-button.td-gradient-button',
			]
		);


		$this->end_controls_tab();//Default style tab end

		//Hover style tab start
		$this->start_controls_tab(
		    'td_team_style_hover',
		    [
		        'label' => esc_html__('Hover', 'themedraft-core'),
		    ]
		);

		$this->add_control('overlay_two_color_note',
			[
				'label'         => '<span style="line-height: 22px;background-color: #d1ecf1;padding:10px;">Set top overlay color from below.</span>',
				'type'          => Controls_Manager::RAW_HTML,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'hover_top_overlay_bg_color',
				'label' => esc_html__( 'Overlay Background', 'themedraft-core' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .td-price-one-top-overlay-two',
			]
		);

		$this->add_control('icon_bg_color_note_twoe',
			[
				'label'         => '<span style="line-height: 22px;background-color: #d1ecf1;padding:10px;">Set icon background color from below.</span>',
				'type'          => Controls_Manager::RAW_HTML,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'hover_icon_bg_color',
				'label' => esc_html__( 'Icon Background', 'themedraft-core' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .top-icon-overlay',
			]
		);

		$this->add_control('btn_bg_color_note_two',
			[
				'label'         => '<span style="line-height: 22px;background-color: #d1ecf1;padding:10px;">Set button background color from below.</span>',
				'type'          => Controls_Manager::RAW_HTML,
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'hover_btn_bg_color',
				'label' => esc_html__( 'Button Background', 'themedraft-core' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image' ],
				'selector' => '{{WRAPPER}} .td-button.td-gradient-button:after',
			]
		);

		$this->end_controls_tabs();//Hover style tab end

		$this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$target = $settings['button_link']['is_external'] ? ' target="_blank"' : '';
		$nofollow = $settings['button_link']['nofollow'] ? ' rel="nofollow"' : '';
		?>

		<div class="td-pricing-table-one-wrapper <?php echo $settings['animation'];?>">
			<div class="td-price-one-top-part td-cover-bg" style="background-image: url(<?php echo $settings['top_image']['url'];?>)">
                <div class="td-price-one-top-overlay"></div>
                <div class="td-price-one-top-overlay-two"></div>
				<div class="td-price-one-top-content">
                    <span class="pricing-one-title"><?php echo $settings['title'];?></span>
                    <div class="top-icon">
                        <div class="top-icon-overlay"></div>
						<?php themedraft_custom_icon_render( $settings, 'icon', 'table_icon' ); ?>
                    </div>
                </div>
			</div>

            <div class="td-price-one-content">
                <div class="td-price-one-wrapper">
                    <span class="td-pricing-one-price"><?php echo $settings['price'];?></span>
                    <span class="td-pricing-one-subscription-period"><?php echo $settings['time_duration'];?></span>
                </div>

                <div class="td-pricing-one-features">
                    <ul class="td-list-style">
			            <?php
			            if ( $settings['list_items'] ) {
				            foreach ( $settings['list_items'] as $list_item ) { ?>
                                <li>
                                <span class="td-pricing-one-list-icon">
                                    <?php ThemeDraft_Custom_Icon_Render( $list_item, 'icon', 'selected_icon' ); ?>
                                </span>

						            <?php if ( ! empty( $list_item['item_link']['url'] ) ) :
						            $target = $list_item['item_link']['is_external'] ? ' target="_blank"' : '';
						            $nofollow = $list_item['item_link']['nofollow'] ? ' rel="nofollow"' : '';
						            ?>
                                    <a href="<?php echo $list_item['item_link']['url']; ?>" <?php echo $target . $nofollow; ?>>
							            <?php endif;
							            ?>
							            <?php echo $list_item['text']; ?>
							            <?php if ( ! empty( $list_item['item_link']['url'] ) ) : ?>
                                    </a>
					            <?php endif;
					            ?>
                                </li>
					            <?php
				            }
			            }
			            ?>
                    </ul>
                </div>

                <div class="td-pricing-one-button">
                    <a class="td-button td-gradient-button" href="<?php echo $settings['button_link']['url']; ?>" <?php echo $target . $nofollow; ?>><span><?php echo $settings['btn_text'];?></span></a>
                </div>
            </div>
		</div>
		<?php
	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Pricing_Table_One_Widget );