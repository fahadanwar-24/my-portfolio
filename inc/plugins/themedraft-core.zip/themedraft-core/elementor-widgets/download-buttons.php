<?php
namespace Elementor;
use ThemeDraft_Gradient_Color;
class ThemeDraft_Bizkorp_Download_Buttons_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_bizkorp_download_button_widget';
	}

	public function get_title() {
		return esc_html__( 'Download Button', 'themedraft-core' );
	}

	public function get_icon() {

		return 'td-icon flaticon-database-storage';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	protected function register_controls() {
        $this->start_controls_section(
            'widget_title_options',
            [
                'label' => esc_html__( 'Title', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'download_title',
            [
                'label'       => esc_html__( 'Title', 'themedraft-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => esc_html__( 'Download Now', 'themedraft-core' ),
                'placeholder' => esc_html__( '', 'themedraft-core' ),
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'button_one_option',
			[
				'label' => esc_html__( 'Button One', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'btn_one_text',
			[
				'label'       => __( 'Text', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Download PDF'
			]
		);

		$this->add_control(
			'btn_one_url',
			[
				'label'         => __( 'URL', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '#',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'enable_btn_one_icon',
			[
				'label'     => esc_html__( 'Enable Icon', 'themedraft-core' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Yes', 'themedraft-core' ),
				'label_off' => esc_html__( 'No', 'themedraft-core' ),
				'default'   => 'yes',
			]
		);

		$this->add_control(
			'selected_btn_1_icon',
			[
				'label'            => esc_html__( 'Select Icon', 'themedraft-core' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'far fa-file-pdf',
					'library' => 'regular',
				],
				'condition' => [
					'enable_btn_one_icon' => 'yes',
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'button_one_style_options',
			[
				'label' => esc_html__( 'Button One', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'btn_one_typo',
				'label' => esc_html__( 'Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .themedraft-button.themedraft-button-one',
			]
		);

		$this->start_controls_tabs('td_btn_one_style_tabs');

		//Default style tab start
		$this->start_controls_tab(
			'td_btn_one_style_default',
			[
				'label' => esc_html__('Default', 'themedraft-core'),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'btn_one_default_background',
				'label' => esc_html__( 'Background', 'themedraft-core' ),
				'types' => [ 'gradient' ],
				'exclude' => [ 'image'],
				'selector' => '{{WRAPPER}} .td-gradient-button.themedraft-button.themedraft-button-one,{{WRAPPER}} .td-gradient-button.themedraft-button.themedraft-button-one:after',
			]
		);

		$this->add_control(
			'btn_one_default_text_color',
			[
				'label'     => esc_html__('Text Color', 'themedraft-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .td-gradient-button.themedraft-button.themedraft-button-one' => 'color: {{VALUE}};',
					'{{WRAPPER}} .td-gradient-button.themedraft-button.themedraft-button-one svg path' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'button_one_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'themedraft-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .td-gradient-button.themedraft-button.themedraft-button-one' => 'border-radius: {{SIZE}}px;',
				],
			]
		);

		$this->end_controls_tab();//Default style tab end

		//Hover style tab start
		$this->start_controls_tab(
			'td_btn_one_style_hover',
			[
				'label' => esc_html__('Hover', 'themedraft-core'),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'btn_one_hover_background',
				'label' => esc_html__( 'Background', 'themedraft-core' ),
				'types' => [ 'gradient' ],
				'exclude' => [ 'image'],
				'selector' => '{{WRAPPER}} .td-button.td-gradient-button.themedraft-button-one:hover:after',
			]
		);

		$this->add_control(
			'btn_one_hover_color',
			[
				'label'       => esc_html__('Text Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-button.td-gradient-button.themedraft-button-one:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tabs();//Hover style tab end
		$this->end_controls_section();


		// Button two

		$this->start_controls_section(
			'button_two_option',
			[
				'label' => esc_html__( 'Button Two', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'btn_two_text',
			[
				'label'       => __( 'Text', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'        => __( 'download brochure', 'themedraft-core' ),
			]
		);

		$this->add_control(
			'btn_two_url',
			[
				'label'         => __( 'URL', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '#',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'enable_btn_two_icon',
			[
				'label'     => esc_html__( 'Enable Icon', 'themedraft-core' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Yes', 'themedraft-core' ),
				'label_off' => esc_html__( 'No', 'themedraft-core' ),
				'default'   => 'yes',
			]
		);

		$this->add_control(
			'selected_btn_2_icon',
			[
				'label'            => esc_html__( 'Select Icon', 'themedraft-core' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'far fa-file-pdf',
					'library' => 'regular',
				],
				'condition' => [
					'enable_btn_two_icon' => 'yes',
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'button_two_style_options',
			[
				'label' => esc_html__( 'Button Two', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [
					'btn_two_text!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'btn_two_typo',
				'label' => esc_html__( 'Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .themedraft-button.themedraft-button-two',
			]
		);

		$this->start_controls_tabs('td_btn_two_style_tabs');

		//Default style tab start
		$this->start_controls_tab(
			'td_btn_two_style_default',
			[
				'label' => esc_html__('Default', 'themedraft-core'),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'btn_two_default_background',
				'label' => esc_html__( 'Background', 'themedraft-core' ),
				'types' => [ 'gradient' ],
				'exclude' => [ 'image'],
				'selector' => '{{WRAPPER}} .td-gradient-button.themedraft-button.themedraft-button-two,{{WRAPPER}} .td-gradient-button.themedraft-button.themedraft-button-two:after',
			]
		);

		$this->add_control(
			'btn_two_default_text_color',
			[
				'label'     => esc_html__('Text Color', 'themedraft-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .td-gradient-button.themedraft-button.themedraft-button-two' => 'color: {{VALUE}};',
					'{{WRAPPER}} .td-gradient-button.themedraft-button.themedraft-button-two svg path' => 'fill: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'button_two_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'themedraft-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .td-gradient-button.themedraft-button.themedraft-button-two' => 'border-radius: {{SIZE}}px;',
				],
			]
		);

		$this->add_responsive_control(
			'btn_two_margin',
			[
				'label'      => esc_html__( 'Margin', 'themedraft-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'separator' => 'before',
				'selectors'  => [
					'{{WRAPPER}} .themedraft-button.themedraft-button-two' => 'Margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();//Default style tab end

		//Hover style tab start
		$this->start_controls_tab(
			'td_btn_two_style_hover',
			[
				'label' => esc_html__('Hover', 'themedraft-core'),
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'btn_two_hover_background',
				'label' => esc_html__( 'Background', 'themedraft-core' ),
				'types' => [ 'gradient' ],
				'exclude' => [ 'image'],
				'selector' => '{{WRAPPER}} .td-button.td-gradient-button.themedraft-button-two:hover:after',
			]
		);

		$this->add_control(
			'btn_two_hover_color',
			[
				'label'       => esc_html__('Text Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-button.td-gradient-button.themedraft-button-two:hover' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_tabs();//Hover style tab end
		$this->end_controls_section();

		// Wrapper
		$this->start_controls_section(
			'wrapper_options',
			[
				'label' => esc_html__( 'Wrapper', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_responsive_control(
			'text_align',
			[
				'label'       => esc_html__('Alignment', 'themedraft-core'),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,

				'options' => [
					'left' => [
						'title' => __('Left', 'themedraft-core'),
						'icon'  => 'eicon-text-align-left',
					],

					'center' => [
						'title' => __('Center', 'themedraft-core'),
						'icon'  => 'eicon-text-align-center',
					],

					'right' => [
						'title' => __('Right', 'themedraft-core'),
						'icon'  => 'eicon-text-align-right',
					],
				],

				'devices' => ['desktop', 'tablet', 'mobile'],

				'selectors' => [
					'{{WRAPPER}} .themedraft-button-wrapper' => 'text-align: {{VALUE}};',
				],

			]
		);

		$this->add_responsive_control(
			'wrapper_margin',
			[
				'label'      => esc_html__( 'Wrapper Margin', 'themedraft-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .themedraft-button-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'animation',
			[
				'label'   => __( 'Animation', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => themedraft_core_get_animation_options(),
			],
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'btn_icon_size',
			[
				'label' => esc_html__( 'Button Icon', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'icon_size',
			[
				'label' => esc_html__( 'Icon Size', 'themedraft-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'%' => [
						'min' => 15,
						'max' => 50,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'selectors' => [
					'{{WRAPPER}} .themedraft-button i' => 'font-size: {{SIZE}}px;',
					'{{WRAPPER}} .themedraft-button svg' => 'height: {{SIZE}}px;width: {{SIZE}}px;',
				],
			]
		);

		$this->add_responsive_control(
			'icon_margin',
			[
				'label'      => esc_html__( 'Icon Margin', 'themedraft-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .themedraft-button i,{{WRAPPER}} .themedraft-button svg' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();

		$btn_one_text = $settings['btn_one_text'];
		$btn_one_url   = $settings['btn_one_url']['url'];
		$btn_one_target   = $settings['btn_one_url']['is_external'] ? ' target="_blank"' : '';
		$btn_one_nofollow = $settings['btn_one_url']['nofollow'] ? ' rel="nofollow"' : '';
		?>

		<div class="td-el-sidebar-widget widget td_download_button_widget <?php echo $settings['animation'];?>">
			<h4 class="widget-title"><?php echo $settings['download_title'];?></h4>

			<div class="td-download-button-widget-wrapper">
				<div class="themedraft-button-wrapper td-button-el-widget">

					<a href="<?php echo esc_url($btn_one_url);?>" class="themedraft-button td-button td-gradient-button themedraft-button-one" <?php echo esc_attr($btn_one_target . $btn_one_nofollow);?>><span><?php echo esc_html($btn_one_text);?></span>
						<?php if($settings['enable_btn_one_icon'] == 'yes') :?>
							<?php themedraft_custom_icon_render( $settings, 'icon', 'selected_btn_1_icon' );?>
						<?php endif; ?>
					</a>

					<?php if($settings['btn_two_text']) :
						$btn_two_text = $settings['btn_two_text'];
						$btn_two_url   = $settings['btn_two_url']['url'];
						$btn_two_target   = $settings['btn_two_url']['is_external'] ? ' target="_blank"' : '';
						$btn_two_nofollow = $settings['btn_two_url']['nofollow'] ? ' rel="nofollow"' : '';
						?>

						<a href="<?php echo esc_url($btn_two_url);?>" class="themedraft-button td-button td-gradient-button themedraft-button-two" <?php echo esc_attr($btn_two_target . $btn_two_nofollow);?>><span><?php echo esc_html($btn_two_text);?></span>
							<?php if($settings['enable_btn_two_icon'] == 'yes') :?>
								<?php themedraft_custom_icon_render( $settings, 'icon', 'selected_btn_2_icon' );?>
							<?php endif; ?>
						</a>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<?php
	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Bizkorp_Download_Buttons_Widget );