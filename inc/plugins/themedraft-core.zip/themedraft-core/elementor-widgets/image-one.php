<?php
namespace Elementor;

class ThemeDraft_Image_One_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_image_one';
	}

	public function get_title() {
		return esc_html__( 'Image One', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon flaticon-image';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	public function get_script_depends() {
		return ['counterup'];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'image_one_options',
			[
				'label' => esc_html__( 'Image', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'image',
			[
				'label'       => __( 'Image', 'themedraft-core' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'default'     => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
        
        $this->add_control(
            'enable_content',
            [
                'label'     => esc_html__( 'Enable Content', 'themedraft-core' ),
                'type'      => Controls_Manager::SWITCHER,
                'label_on'  => esc_html__( 'Yes', 'themedraft-core' ),
                'label_off' => esc_html__( 'No', 'themedraft-core' ),
                'default'   => 'yes',
            ]
        );

		$this->add_control(
			'count_title',
			[
				'label'       => __( 'Count Up Title', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'Years Expires',
				'label_block' => true,
                'condition' => [
                    'enable_content' => 'yes',
                ],
			]
		);

		$this->add_control(
			'number',
			[
				'label'       => __( 'Number', 'themedraft-core' ),
				'label_block'       => false,
				'type'        => Controls_Manager::TEXT,
				'default'     => '45',
				'condition' => [
					'enable_content' => 'yes',
				],
			]
		);

		$this->add_control(
			'unit',
			[
				'label'   => 'Counter Unit',
				'type'    => Controls_Manager::TEXT,
				'default' => '+',
				'condition' => [
					'enable_content' => 'yes',
				],
			]
		);

		$this->add_control(
			'animation',
			[
				'label'   => __( 'Animation', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => themedraft_core_get_animation_options(),
			],
		);


		$this->end_controls_section();

		$this->start_controls_section(
			'image_three_style',
			[
				'label' => esc_html__( 'Image Three', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'content_align',
			[
				'label'       => esc_html__('Align', 'themedraft-core'),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options' => [
					'left' => [
						'title' => __('Left', 'themedraft-core'),
						'icon'  => 'eicon-text-align-left',
					],

					'center' => [
						'title' => __('Center', 'themedraft-core'),
						'icon'  => 'eicon-text-align-center',
					],

					'right' => [
						'title' => __('Right', 'themedraft-core'),
						'icon'  => 'eicon-text-align-right',
					],
				],

				'devices' => ['desktop', 'tablet', 'mobile'],

				'selectors' => [
					'{{WRAPPER}} .td-image-one-wrapper' => 'text-align: {{VALUE}};',
				],

			]
		);

		$this->add_responsive_control(
			'wrapper_margin',
			[
				'label'      => esc_html__( 'Wrapper Margin', 'themedraft-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .td-image-one-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$image_src = $settings['image']['url'];
		$image_alt = get_post_meta( $settings['image']['id'], '_wp_attachment_image_alt', true );
		$image_title = get_the_title( $settings['image']['id']);
		$count_id = rand(100, 100000);
		?>

		<div class="td-image-one-wrapper td-counter-box-<?php echo esc_attr($count_id);?>">
			<div class="td-image-one <?php echo $settings['animation'];?>">
				<img src="<?php echo esc_url($image_src);?>" alt="<?php echo esc_attr($image_alt);?>" title="<?php echo esc_attr($image_title);?>">
				<?php if ($settings['enable_content'] == 'yes') :?>
                <div class="td-img-counter">
					<div class="td-count-number-and-unit">
						<span class="td-count-number"><?php echo esc_html( $settings['number'] ) ?></span><?php echo esc_html( $settings['unit'] ) ?>
					</div>

					<div class="td-count-one-title"><?php echo esc_html( $settings['count_title'] ) ?></div>
				</div>
                <?php endif; ?>
			</div>
		</div>

        <script>
            (function ($) {
                "use strict";
                /*====  Document Ready Function =====*/
                jQuery(document).ready(function($){
                    $(".td-counter-box-<?php echo esc_attr($count_id);?> .td-count-number").counterUp({
                        delay: 10,
                        time: 2000
                    });
                });
            }(jQuery));
        </script>
		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Image_One_Widget );