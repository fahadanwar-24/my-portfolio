<?php
namespace Elementor;
use ThemeDraft_Gradient_Color;
class ThemeDraft_Service_One_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_service_one';
	}

	public function get_title() {
		return esc_html__( 'Service One', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon flaticon-layers';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'service_one_settings',
			[
				'label' => esc_html__( 'Service Box', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'       => __( 'Title', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 5,
				'default'     => 'Web Development',
			]
		);

		$repeater->add_control(
			'desc',
			[
				'label'       => __( 'Description', 'themedraft-core' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => 'Whether you\'re a small business look in streamline operations enterprise is then aiming to scale seamlessly.',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'type',
			[
				'label'       => esc_html__( 'Icon Type', 'themedraft-core' ),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options'     => [
					'icon'  => [
						'title' => esc_html__( 'Icon', 'themedraft-core' ),
						'icon'  => 'fa fa-smile',
					],
					'image' => [
						'title' => esc_html__( 'Image', 'themedraft-core' ),
						'icon'  => 'fa fa-image',
					],
				],
				'default'     => 'icon',
				'toggle'      => false,
			]
		);

		$repeater->add_control(
			'selected_icon',
			[
				'label'            => esc_html__( 'Select Icon', 'themedraft-core' ),
				'type'             => Controls_Manager::ICONS,
				'fa4compatibility' => 'icon',
				'label_block'      => true,
				'default'          => [
					'value'   => 'flaticon-computer',
					'library' => 'themedraft-bizkorp-icon',
				],
				'condition'        => [
					'type' => 'icon'
				]
			]
		);

		$repeater->add_control(
			'image',
			[
				'label'     => esc_html__( 'Image', 'themedraft-core' ),
				'type'      => Controls_Manager::MEDIA,
				'default'   => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'type' => 'image'
				],
				'dynamic'   => [
					'active' => true,
				]
			]
		);

		$repeater->add_control(
            'hover_img',
            [
                'label'       => __( 'Hover Image', 'themedraft-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

		$repeater->add_control(
			'details_url',
			[
				'label'         => __( 'Details Url', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'services',
			[
				'label'       => __( 'Service List', 'themedraft-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title' => 'Web Development',
						'desc' => 'Whether you\'re a small business look in streamline operations enterprise is then aiming to scale seamlessly.',
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

        $this->add_control(
            'details_btn_text',
            [
                'label'       => __( 'Button Text', 'themedraft-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => 'View Details',
            ]
        );

        $this->add_control(
            'animation',
            [
                'label'   => __( 'Animation', 'themedraft-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => themedraft_core_get_animation_options(),
            ],
        );

		$this->end_controls_section();


		$this->start_controls_section(
			'service_column_options',
			[
				'label' => esc_html__( 'Column', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'desktop_col',
			[
				'label'   => __( 'Columns On Desktop', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-xl-4',
				'options' => [
					'col-xl-12' => __( '1 Column', 'themedraft-core' ),
					'col-xl-6'  => __( '2 Column', 'themedraft-core' ),
					'col-xl-4'  => __( '3 Column', 'themedraft-core' ),
					'col-xl-3'  => __( '4 Column', 'themedraft-core' ),
				],
			]
		);

		$this->add_control(
			'iPad_pro_col',
			[
				'label'   => __( 'Columns On iPad Pro', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-lg-4',
				'options' => [
					'col-lg-12' => __( '1 Column', 'themedraft-core' ),
					'col-lg-6'  => __( '2 Column', 'themedraft-core' ),
					'col-lg-4'  => __( '3 Column', 'themedraft-core' ),
					'col-lg-3'  => __( '4 Column', 'themedraft-core' ),
				],
			]
		);

		$this->add_control(
			'tab_col',
			[
				'label'   => __( 'Columns On Tablet', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'col-md-6',
				'options' => [
					'col-md-12' => __( '1 Column', 'themedraft-core' ),
					'col-md-6'  => __( '2 Column', 'themedraft-core' ),
					'col-md-4'  => __( '3 Column', 'themedraft-core' ),
					'col-md-3'  => __( '4 Column', 'themedraft-core' ),
				],
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'td_service_title_style_options',
			[
				'label' => esc_html__('Title', 'themedraft-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typo',
				'label' => esc_html__( 'Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .td-service-one-title',
			]
		);

		$this->add_responsive_control(
			'title_margin',
			[
				'label'      => esc_html__( 'Margin', 'themedraft-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .td-service-one-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'td_service_desc_style_options',
			[
				'label' => esc_html__('Description', 'themedraft-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'desc_typo',
				'label' => esc_html__( 'Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .td-service-one-desc',
			]
		);

		$this->add_responsive_control(
			'desc_margin',
			[
				'label'      => esc_html__( 'Margin', 'themedraft-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .td-service-one-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'td_service_details_link_style_options',
			[
				'label' => esc_html__('Details Button', 'themedraft-core'),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'details_btn_typo',
				'label' => esc_html__( 'Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .service-one-details-btn',
			]
		);

		$this->add_responsive_control(
			'details_btn_margin',
			[
				'label'      => esc_html__( 'Margin', 'themedraft-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .service-one-details-btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'box_style',
            [
                'label' => esc_html__( 'Box', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs('td_default_and_hover_style_tabs_start');

        //Default style tab start
        $this->start_controls_tab(
            'td_box_style_default',
            [
                'label' => esc_html__('Default', 'themedraft-core'),
            ]
        );

		$this->add_control(
			'default_title_color',
			[
				'label'       => esc_html__('Title Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-service-one-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'default_desc_color',
			[
				'label'       => esc_html__('Description Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .td-service-one-desc' => 'color: {{VALUE}};',
				],
			]
		);

        $this->add_control('default_icon_color_note',
            [
                'label'         => '<span style="line-height: 22px;background-color: #d1ecf1;padding:10px;">Set icon color from below.</span>',
                'type'          => Controls_Manager::RAW_HTML,
                'separator' => 'before',
            ]
        );

		$this->add_group_control(
			Themedraft_Gradient_Color::get_type(),
			[
				'label' => esc_html__( 'Icon Color', 'themedraft-core' ),
				'name' => 'default_icon_color',
				'selector' => '{{WRAPPER}} .td-service-one-icon i',
			]
		);

        $this->end_controls_tab();//Default style tab end

        //Hover style tab start
        $this->start_controls_tab(
            'td_box_style_hover',
            [
                'label' => esc_html__('Hover', 'themedraft-core'),
            ]
        );

        $this->add_control(
            'hover_icon_color',
            [
                'label'       => esc_html__('Icon Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-single-service-one-item:hover .td-service-one-icon i' => '-webkit-text-fill-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'hover_title_color',
            [
                'label'       => esc_html__('Title Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-single-service-one-item:hover .td-service-one-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'hover_desc_color',
            [
                'label'       => esc_html__('Description Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-single-service-one-item:hover .td-service-one-desc' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'hover_button_bg',
            [
                'label'       => esc_html__('Button Background', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-single-service-one-item:hover .service-one-details-btn' => 'background-color: {{VALUE}};border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'hover_button_color',
            [
                'label'       => esc_html__('Button Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-single-service-one-item:hover .service-one-details-btn' => 'color: {{VALUE}};',
                ],
            ]
        );

		$this->add_control('overlay_color_note',
			[
				'label'         => '<span style="line-height: 22px;background-color: #d1ecf1;padding:10px;">Set overlay color from below.</span>',
				'type'          => Controls_Manager::RAW_HTML,
				'separator' => 'before',
			]
		);

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'hover_overlay_background',
                'label' => esc_html__( 'Background', 'themedraft-core' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .td-service-one-overlay',
            ]
        );

        $this->end_controls_tabs();//Hover style tab end

        $this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$column = $settings['desktop_col'] . ' ' . $settings['iPad_pro_col'] . ' ' . $settings['tab_col'];
		?>

        <div class="td-service-one-wrapper">
            <div class="service-one row">
                <?php if ( $settings['services'] ) {
                    foreach ( $settings['services'] as $service ) {
                        $details_url      = $service['details_url']['url'];
                        $target   = $service['details_url']['is_external'] ? ' target="_blank"' : '';
                        $nofollow = $service['details_url']['nofollow'] ? ' rel="nofollow"' : '';

                        $hover_img_src = $service['hover_img']['url'];
                        ?>
                        <div class="<?php echo esc_attr($column);?>">
                            <div class="td-single-service-one-item <?php echo $settings['animation'];?>">
                                <div class="td-service-one-overlay"></div>
                                <div class="td-service-one-hover-image td-cover-bg" style="background-image: url(<?php echo $hover_img_src;?>)"></div>
                                <div class="td-service-one-icon">
                                    <?php if ( $service['type'] === 'image' && $service['image']['id'] ) : ?>
                                        <img src="<?php echo $service['image']['url']; ?>"
                                             alt="<?php echo get_post_meta( $service['image']['id'], '_wp_attachment_image_alt', true ); ?>">
                                    <?php elseif ( ! empty( $service['icon'] ) || ! empty( $service['selected_icon'] ) ) :
                                        themedraft_custom_icon_render( $service, 'icon', 'selected_icon' );?>
                                    <?php endif; ?>
                                </div>
                                <h4 class="td-service-one-title"><?php echo nl2br($service['title']);?></h4>

                                <div class="td-service-one-desc td-last-p-0"><?php echo $service['desc'];?></div>

                                <a href="<?php echo $details_url;?>" class="service-one-details-btn">
                                    <?php echo $settings['details_btn_text'];?>
                                </a>
                            </div>
                        </div>
                    <?php }
                } ?>
            </div>

        </div>
		<?php
	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Service_One_Widget );