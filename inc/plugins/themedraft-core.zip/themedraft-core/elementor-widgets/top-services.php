<?php
namespace Elementor;

class ThemeDraft_Top_Services_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_top_services';
	}

	public function get_title() {
		return esc_html__( 'Top Services', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon flaticon-layers';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}


	protected function register_controls() {

		$this->start_controls_section(
			'top_services_options',
			[
				'label' => esc_html__( 'Top Services', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'title',
			[
				'label'       => __( 'Title', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'UI/UX Design',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'list',
			[
				'label'       => __( 'LIst', 'themedraft-core' ),
				'type'        => Controls_Manager::WYSIWYG,
				'default'     => '<ul>
                                    <li>Brand Research</li>
                                    <li>Design Analysis</li>
                                    <li>Design Structure</li>
                                 </ul>',
				'label_block' => true,
			]
		);

		$repeater->add_control(
			'desc',
			[
				'label'       => __( 'Description', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 5,
				'default'     => 'Whether you\'re a small business looking to streamline operations or an enterprise aiming to scale seamlessly.',
			]
		);

		$repeater->add_control(
			'details_url',
			[
				'label'         => __( 'Details Url', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'services',
			[
				'label'       => __( 'Service List', 'themedraft-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => [
					[
						'title' => 'UI/UX Design',
						'list' => '<ul>
                                    <li>Brand Research</li>
                                    <li>Design Analysis</li>
                                    <li>Design Structure</li>
                                 </ul>',
						'desc' => 'Whether you\'re a small business looking to streamline operations or an enterprise aiming to scale seamlessly.',
					],
				],
				'title_field' => '{{{ title }}}',
			]
		);

        $this->add_control(
            'btn_text',
            [
                'label'       => __( 'Button Text', 'themedraft-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => 'Get Started Now',
            ]
        );

        $this->add_control(
            'animation',
            [
                'label'   => __( 'Animation', 'themedraft-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => themedraft_core_get_animation_options(),
            ],
        );

		$this->end_controls_section();

        $this->start_controls_section(
            'top_service_style',
            [
                'label' => esc_html__( 'Top Services', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'label' => esc_html__( 'Title Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .top-service-title a',
            ]
        );

        $this->start_controls_tabs('td_default_and_hover_style_tabs_start');

        //Default style tab start
        $this->start_controls_tab(
            'td_team_style_default',
            [
                'label' => esc_html__('Default', 'themedraft-core'),
            ]
        );


        $this->end_controls_tab();//Default style tab end

        //Hover style tab start
        $this->start_controls_tab(
            'td_team_style_hover',
            [
                'label' => esc_html__('Hover', 'themedraft-core'),
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'hover_background',
                'label' => esc_html__( 'Background', 'themedraft-core' ),
                'types' => [ 'classic', 'gradient'],
                'selector' => '{{WRAPPER}} .top-service-item:before',
            ]
        );

        $this->end_controls_tabs();//Hover style tab end

        $this->end_controls_section();

	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		?>

		<div class="top-service-wrapper">
			<?php if ($settings['services']){
				$counter = 1; // Initialize counter
				foreach ($settings['services'] as $service){
					$number = str_pad($counter, 2, '0', STR_PAD_LEFT);
                    ?>
					<div class="top-service-item">
                        <div class="container">
                            <div class="row">
                                <div class="col-12">
                                    <div class="top-service-item-content <?php echo $settings['animation'];?>">
                                        <div class="row">
                                            <div class="col-xl-4 col-lg-5 col-md-12">
                                                <h4 class="top-service-title">
                                                    <a href="<?php echo $service['details_url']['url'];?>">
                                                        <span><?php echo $number; ?></span>
                                                        <?php echo $service['title'];?>
                                                    </a>
                                                </h4>
                                            </div>

                                            <div class="col-xl-3 col-lg-3 col-md-4">
                                                <div class="top-service-list">
                                                    <?php echo $service['list'];?>
                                                </div>
                                            </div>

                                            <div class="col-xl-5 col-lg-4 col-md-8">
                                                <div class="top-service-desc-wrapper">
                                                    <div class="top-service-desc td-last-p-0">
                                                        <?php echo $service['desc'];?>
                                                    </div>

                                                    <div class="top-service-details">
                                                        <a href="<?php echo $service['details_url']['url'];?>"><?php echo $settings['btn_text'];?></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
					</div>
			<?php	$counter++;}
			} ?>
		</div>

		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Top_Services_Widget );