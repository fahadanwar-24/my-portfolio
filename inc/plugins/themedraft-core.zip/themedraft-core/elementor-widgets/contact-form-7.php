<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class ThemeDraft_ContactForm7_Layout_One_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_contact_form_seven_layout_one';
	}

	public function get_title() {
		return __( 'Contact Form 7', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon eicon-mail';
	}
	public function get_categories() {
		return array( 'themedraft_elements' );
	}

	protected function register_controls() {


		$this->start_controls_section(
			'contact_form_accordion',
			[
				'label' => __( 'Contact Form', 'themedraft-core' ),
				'tab' => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'wpcf7_form_list',
			[
				'label' => __( 'Select Contact Form', 'themedraft-core' ),
				'label_block' => true,
				'type' => Controls_Manager::SELECT,
				'options' => $this->themedraft_contact_form_layout_one(),
			]
		);

		$this->end_controls_section();


		$this->start_controls_section(
			'themedraft_contact_field_style',
			[
				'label' => __( 'Field Style', 'themedraft-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'field_typo',
                'label' => esc_html__( 'Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .themedraft-contact-form-container',
            ]
        );

		$this->add_control(
			'field_bg_color',
			[
				'label'       => esc_html__('Field Background Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .themedraft-contact-form-container select' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container input' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container textarea' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'selector' => '{{WRAPPER}} .themedraft-contact-form-container input,{{WRAPPER}} div.themedraft-contact-form-container textarea',
                'exclude' => [ 'color' ],
			]
		);

		$this->add_control(
			'field_border_color',
			[
				'label'       => esc_html__('Field Border Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .themedraft-contact-form-container select' => 'border-color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container input' => 'border-color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container textarea' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'field_border_color_on_focus',
			[
				'label'       => esc_html__('Field Border Color On Focus', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .themedraft-contact-form-container select:focus' => 'border-color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container input:focus' => 'border-color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container textarea:focus' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'field_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'themedraft-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .themedraft-contact-form-container select,{{WRAPPER}} .themedraft-contact-form-container input,{{WRAPPER}} .themedraft-contact-form-container textarea' => 'border-radius: {{SIZE}}px;',
				],
			]
		);

		$this->add_control(
			'field_text_color',
			[
				'label'       => esc_html__('Field Text Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .themedraft-contact-form-container ::placeholder' => 'color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container :-ms-input-placeholder' => 'color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container ::-ms-input-placeholder' => 'color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container select' => 'color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container input' => 'color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container textarea' => 'color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container .select-arrow:before' => 'border-top-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'textarea_height',
			[
				'label' => __( 'Textarea Height', 'themedraft-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 100,
						'max' => 1000,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],
				'selectors' => [
					'{{WRAPPER}} .themedraft-contact-form-container textarea' => 'height: {{SIZE}}px;',
				],
			]
		);

        $this->add_responsive_control(
            'field_padding',
            [
                'label'      => esc_html__( 'Padding', 'themedraft-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} input[type="text"],{{WRAPPER}} input[type="email"],{{WRAPPER}} textarea' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );


		$this->end_controls_section();

		$this->start_controls_section(
			'themedraft_contact_submit_style',
			[
				'label' => __( 'Submit Button', 'themedraft-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
            'btn_full_width',
            [
                'label'     => esc_html__( 'Button Full Width', 'themedraft-core' ),
                'type'      => Controls_Manager::SWITCHER,
                'label_on'  => esc_html__( 'Yes', 'themedraft-core' ),
                'label_off' => esc_html__( 'No', 'themedraft-core' ),
                'default'   => 'no',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'submit_btn_typo',
                'label' => esc_html__( 'Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .themedraft-contact-form-container input[type="submit"],{{WRAPPER}} .themedraft-contact-form-container button[type="submit"]',
            ]
        );

        $this->add_responsive_control(
            'btn_padding',
            [
                'label'      => esc_html__( 'Button Padding', 'themedraft-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .themedraft-contact-form-container input[type="submit"],{{WRAPPER}} .themedraft-contact-form-container button[type="submit"]' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'btn_margin',
            [
                'label'      => esc_html__( 'Button Margin', 'themedraft-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .themedraft-contact-form-container input[type="submit"],{{WRAPPER}} .themedraft-contact-form-container button[type="submit"]' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->add_responsive_control(
			'button_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'themedraft-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .themedraft-contact-form-container input[type="submit"],{{WRAPPER}} .themedraft-contact-form-container button[type="submit"]' => 'border-radius: {{SIZE}}px;',
				],
			]
		);

		//Normal & hover option start
		$this->start_controls_tabs('td_btn_styles');

		//Normal style start
		$this->start_controls_tab(
			'btn_normal_style',
			[
				'label' => esc_html__('Default', 'themedraft-core'),
			]
		);

		$this->add_control(
			'normal_txt_color',
			[
				'label'     => esc_html__('Text Color', 'themedraft-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .themedraft-contact-form-container input[type="submit"]' => 'color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container button[type="submit"]' => 'color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container button[type="submit"] svg path' => 'fill: {{VALUE}};',
				],
			]
		);

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'default_background',
                'label' => esc_html__( 'Background', 'themedraft-core' ),
                'types' => [ 'classic', 'gradient' ],
                'exclude' => [ 'image'],
                'selector' => '{{WRAPPER}} .themedraft-contact-form-container input[type="submit"],{{WRAPPER}} .themedraft-contact-form-container button[type="submit"]',
            ]
        );

        $this->add_control(
            'border_default_color',
            [
                'label'       => esc_html__('Border Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .themedraft-contact-form-container input[type="submit"],{{WRAPPER}} .themedraft-contact-form-container button[type="submit"]' => 'border-color: {{VALUE}};',
                ],
            ]
        );

		$this->end_controls_tab();
		//Normal style end

		//Hover style start
		$this->start_controls_tab(
			'btn_hover_style',
			[
				'label' => esc_html__('Hover', 'themedraft-core'),
			]
		);

		$this->add_control(
			'hover_txt_color',
			[
				'label'     => esc_html__('Text Color', 'themedraft-core'),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .themedraft-contact-form-container input[type="submit"]:hover' => 'color: {{VALUE}};',
					'{{WRAPPER}} .themedraft-contact-form-container button[type="submit"]:hover' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'hover_bg_color',
				'label' => esc_html__( 'Background', 'themedraft-core' ),
				'types' => [ 'classic', 'gradient' ],
				'exclude' => [ 'image'],
				'selector' => '{{WRAPPER}} .themedraft-contact-form-container input[type="submit"]:hover,{{WRAPPER}} .themedraft-contact-form-container button[type="submit"]:hover',
			]
		);

		$this->add_control(
			'border_hover_color',
			[
				'label'       => esc_html__('Border Color', 'themedraft-core'),
				'type'        => Controls_Manager::COLOR,
				'selectors'   => [
					'{{WRAPPER}} .themedraft-contact-form-container input[type="submit"],{{WRAPPER}} .themedraft-contact-form-container button[type="submit"]' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();
		//Hover style end
		$this->end_controls_tabs();
		//Normal & hover option end

		$this->end_controls_section();

        $this->start_controls_section(
            'form_wrapper_options',
            [
                'label' => esc_html__( 'Wrapper Style', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'form_wrapper_background',
                'label' => esc_html__( 'Background', 'themedraft-core' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .td-cf7-contact-form',
            ]
        );

        $this->add_responsive_control(
            'wrapper_padding',
            [
                'label'      => esc_html__( 'Padding', 'themedraft-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .td-cf7-contact-form' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'wrapper_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'themedraft-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],

                'selectors' => [
                    '{{WRAPPER}} .td-cf7-contact-form' => 'border-radius: {{SIZE}}px;',
                ],
            ]
        );

        $this->end_controls_section();

	}

	protected function themedraft_contact_form_layout_one( ) {

		if ( ! class_exists( 'WPCF7_ContactForm' ) ) {
			return array();
		}

		$forms = \WPCF7_ContactForm::find( array(
			'orderby' => 'title',
			'order'   => 'ASC',
		) );

		if ( empty( $forms ) ) {
			return array();
		}

		$result = array();

		foreach ( $forms as $item ) {
			$key            = sprintf( '%1$s::%2$s', $item->id(), $item->title() );
			$result[ $key ] = $item->title();
		}

		return $result;
	}


	protected function render()  {
		$settings = $this->get_settings();
		?>
            <div class="td-cf7-contact-form">
                <div class="td-contact-form-container">
                    <?php if ( ! empty( $settings['wpcf7_form_list'] ) ) {?>
                        <div class="themedraft-contact-form-container <?php if($settings['btn_full_width']=='yes'){echo 'form-btn-full-width';}?>">
                            <?php echo do_shortcode( '[contact-form-7 id="' . $settings['wpcf7_form_list'] . '" ]' );?>
                        </div>
                    <?php } ?>
                </div>

            </div>
        <?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_ContactForm7_Layout_One_Widget );