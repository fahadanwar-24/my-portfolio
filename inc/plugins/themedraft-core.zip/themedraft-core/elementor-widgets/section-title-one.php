<?php

namespace Elementor;
use ThemeDraft_Gradient_Color;
class ThemeDraft_Title_With_Text_One_Widget extends Widget_Base {

	public function get_name() {

		return 'themedraft_title_with_text_one';
	}

	public function get_title() {
		return esc_html__( 'Section Title One', 'themedraft-core' );
	}

	public function get_icon() {

		return 'td-icon flaticon-t';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'section_title_options',
			[
				'label' => esc_html__( 'Section Title', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

        $this->add_control(
            'subtitle',
            [
                'label'       => __( 'Subtitle', 'themedraft-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => 'About Us.',
            ]
        );

        $this->add_control(
            'title',
            [
                'label'       => __( 'Title', 'themedraft-core' ),
                'type'        => Controls_Manager::TEXTAREA,
                'rows'        => 5,
                'description' => esc_html__( 'Use<span></span> for different color text.', 'themedraft-core' ),
                'default'     => 'Optimizing Digital Performance.',
            ]
        );

		$this->add_control(
			'title_tag',
			[
				'label'   => __( 'Title Tag', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => [
					'h1' => __( 'H1', 'themedraft-core' ),
					'h2' => __( 'H2', 'themedraft-core' ),
					'h3' => __( 'H3', 'themedraft-core' ),
					'h4' => __( 'H4', 'themedraft-core' ),
					'h5' => __( 'H5', 'themedraft-core' ),
					'h6' => __( 'H6', 'themedraft-core' ),
					'span' => __( 'SPAN', 'themedraft-core' ),
				],
			]
		);

		$this->add_control(
			'insert_image',
			[
				'label'     => esc_html__( 'Insert Title Image', 'themedraft-core' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Yes', 'themedraft-core' ),
				'label_off' => esc_html__( 'No', 'themedraft-core' ),
				'default'   => 'no',
			]
		);

		$this->add_control(
			'title_image',
			[
				'label'       => __( 'Title Image', 'themedraft-core' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'default'     => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'insert_image' => 'yes',
				],
			]
		);

		$this->add_control(
			'word_count',
			[
				'label'       => __( 'Word Count', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 2,
				'condition' => [
					'insert_image' => 'yes',
				],
				'description'       => __( 'After which number of word you want to show image.', 'themedraft-core' ),
			]
		);

        $this->add_control(
            'title_image_link',
            [
                'label'         => __( 'Title Image Link', 'themedraft-core' ),
                'type'          => Controls_Manager::URL,
                'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
                'show_external' => true,
                'default'       => [
                    'url'         => '',
                    'is_external' => false,
                    'nofollow'    => false,
                ],
                'condition' => [
	                'insert_image' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'desc',
            [
                'label'       => esc_html__( 'Description', 'themedraft-core' ),
                'type'        => Controls_Manager::WYSIWYG,
                'label_block' => true,
            ]
        );

        $this->add_control(
            'enable_container',
            [
                'label'     => esc_html__( 'Enable Bootstrap Container', 'themedraft-core' ),
                'type'      => Controls_Manager::SWITCHER,
                'label_on'  => esc_html__( 'Yes', 'themedraft-core' ),
                'label_off' => esc_html__( 'No', 'themedraft-core' ),
                'default'   => 'no',
            ]
        );

        $this->add_control(
            'title_animation',
            [
                'label'   => __( 'Animation', 'themedraft-core' ),
                'type'    => Controls_Manager::SELECT,
                'default' => '',
                'options' => themedraft_core_get_animation_options(),
            ],
        );

		$this->end_controls_section();

        $this->start_controls_section(
            'subtitle_style',
            [
                'label' => esc_html__( 'Subtitle', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'subtitle!' => '',
                ],
            ]
        );

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'subtitle_typography',
				'label'    => esc_html__( 'Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .td-section-title-one-subtitle',
			]
		);

		$this->add_group_control(
			Themedraft_Gradient_Color::get_type(),
			[
				'label' => esc_html__( 'Color', 'themedraft-core' ),
				'name' => 'subtitle_color',
				'selector' => '{{WRAPPER}} .td-section-title-one-subtitle',
			]
		);

		$this->add_responsive_control(
			'subtitle_margin',
			[
				'label'      => esc_html__( 'Margin', 'themedraft-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .td-section-title-one-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();


		$this->start_controls_section(
			'title_style',
			[
				'label'     => esc_html__( 'Title', 'themedraft-core' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'title!' => '',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'label'    => esc_html__( 'Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .td-section-title-one-title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'themedraft-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .td-section-title-one-title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_color_two',
			[
				'label'     => esc_html__( 'Color Two', 'themedraft-core' ),
				'type'      => Controls_Manager::COLOR,
                'description' => esc_html__( 'If you use text inside <span></span> you can change those text color from here.', 'themedraft-core' ),
				'selectors' => [
					'{{WRAPPER}} .td-section-title-one-title span' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_margin',
			[
				'label'      => esc_html__( 'Margin', 'themedraft-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .td-section-title-one-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_padding',
			[
				'label'      => esc_html__( 'Padding', 'themedraft-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .td-section-title-one-title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'image_style',
            [
                'label' => esc_html__( 'Image', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'insert_image' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_img_size',
            [
                'label' => esc_html__( 'Image Size', 'themedraft-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 300,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],

                'selectors' => [
                    '{{WRAPPER}} .td-section-title-one-title img' => 'width: {{SIZE}}px;height: {{SIZE}}px;',
                ],
            ]
        );

		$this->add_responsive_control(
			'title_img_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'themedraft-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['%'],
				'range' => [
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .td-section-title-one-title img' => 'border-radius: {{SIZE}}%;',
				],
			]
		);

        $this->add_responsive_control(
            'title_image_margin',
            [
                'label'      => esc_html__( 'Margin', 'themedraft-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .td-section-title-one-title img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'desc_style_option',
            [
                'label' => esc_html__( 'Description', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'desc!' => '',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'desc_typo',
                'label' => esc_html__( 'Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .section-desc-wrapper',
            ]
        );

        $this->add_control(
            'desc_color',
            [
                'label'       => esc_html__('Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .section-desc-wrapper' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'desc_margin',
            [
                'label'      => esc_html__( 'Margin', 'themedraft-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .section-desc-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'wrapper_style',
			[
				'label' => esc_html__( 'Wrapper', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'content_width',
			[
				'label'      => esc_html__( 'Width (%)', 'themedraft-core' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ '%' ],
				'range'      => [
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'devices'    => [ 'desktop', 'tablet', 'mobile' ],
				'selectors'  => [
					'{{WRAPPER}} .td-section-title-one-content' => 'width: {{SIZE}}%; display: inline-block;',
				],
			]
		);

		$this->add_responsive_control(
			'wrapper_text_align',
			[
				'label'       => esc_html__( 'Text Align', 'themedraft-core' ),
				'type'        => Controls_Manager::CHOOSE,
				'label_block' => false,

				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'themedraft-core' ),
						'icon'  => 'eicon-text-align-left',
					],

					'center' => [
						'title' => esc_html__( 'Center', 'themedraft-core' ),
						'icon'  => 'eicon-text-align-center',
					],

					'right' => [
						'title' => esc_html__( 'Right', 'themedraft-core' ),
						'icon'  => 'eicon-text-align-right',
					],
				],

				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .td-section-title-one-wrapper' => 'text-align: {{VALUE}};',
				],

			]
		);

        $this->add_responsive_control(
            'wrapper_margin',
            [
                'label'      => esc_html__( 'Wrapper Margin', 'themedraft-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .td-section-title-one-wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->add_responsive_control(
			'wrapper_padding',
			[
				'label'      => esc_html__( 'Wrapper Padding', 'themedraft-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .td-section-title-one-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();
	}

	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
			$subtitle       = $settings['subtitle'];
			$title       = $settings['title'];
		?>

        <div class="td-section-title-one-wrapper<?php if ($settings['enable_container'] == 'yes'){echo ' container';}?>">
            <div class="td-section-title-one-content <?php echo $settings['title_animation'];?>">
                <?php if (!empty($subtitle)) : ?>
                    <div class="td-section-title-one-subtitle">
                        <?php echo $subtitle;?>
                    </div>
                <?php endif; ?>

                <<?php echo $settings['title_tag'];?> class="td-section-title-one-title">
                    <?php if($settings['insert_image'] == 'yes'){
                        $image_src = $settings['title_image']['url'];
                        $image_alt = get_post_meta( $settings['title_image']['id'], '_wp_attachment_image_alt', true );
                        $image_title = get_the_title( $settings['title_image']['id']);
                        $image_link = !empty($settings['title_image_link']['url']) ? esc_url($settings['title_image_link']['url']) : '';
                        $word_position = $settings['word_count'];
                        $words = explode(' ', $title);

                        // Check if a link is provided, wrap the image in a link only if available
                        $image_html = '<img class="td-spin-animation" src="' . esc_url($image_src) . '" alt="' . esc_attr($image_alt) . '" title="' . esc_attr($image_title) . '">';

                        if (!empty($image_link)) {
                            $image_html = '<a href="' . $image_link . '">' . $image_html . '</a>';
                        }

                        if (isset($words[$word_position])) {
                            array_splice($words, $word_position, 0, $image_html);
                        }
                        $title = implode(' ', $words);
                        echo $title;
                    } else {
                        echo wp_kses($title, bizkorp_allow_html());
                    } ?>
                </<?php echo $settings['title_tag'];?>>
                
                <?php if($settings['desc']) :?>
                <div class="section-desc-wrapper">
                    <?php echo $settings['desc'];?>
                </div>
                <?php endif; ?>
            </div>
        </div>

		<?php
	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Title_With_Text_One_Widget );