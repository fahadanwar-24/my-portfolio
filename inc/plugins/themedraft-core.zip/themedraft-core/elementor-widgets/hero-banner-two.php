<?php
namespace Elementor;
use ThemeDraft_Gradient_Color;
class ThemeDraft_Hero_Banner_Two_Widget extends Widget_Base {

	public function get_name() {
		return 'themedraft_hero_banner_two';
	}

	public function get_title() {
		return esc_html__( 'Hero Banner Two', 'themedraft-core' );
	}

	public function get_icon() {
		return 'td-icon flaticon-flag';
	}

	public function get_categories() {
		return [ 'themedraft_elements' ];
	}

	protected function register_controls() {

		$this->start_controls_section(
			'hero_banner_content',
			[
				'label' => esc_html__( 'Banner Content', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
		    'subtitle',
		    [
		        'label'       => __( 'Subtitle', 'themedraft-core' ),
		        'type'        => Controls_Manager::TEXTAREA,
		        'rows'        => 5,
		        'default'     => 'A brief supporting statement',
		    ]
		);

		$this->add_control(
		    'title_one',
		    [
		        'label'       => __( 'Title One', 'themedraft-core' ),
		        'type'        => Controls_Manager::TEXTAREA,
		        'rows'        => 5,
		        'default'     => 'We Design & Build',
		    ]
		);

		$this->add_control(
			'title_one_tag',
			[
				'label'   => __( 'Title One Tag', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => [
					'h1' => __( 'H1', 'themedraft-core' ),
					'h2' => __( 'H2', 'themedraft-core' ),
					'h3' => __( 'H3', 'themedraft-core' ),
					'h4' => __( 'H4', 'themedraft-core' ),
					'h5' => __( 'H5', 'themedraft-core' ),
					'h6' => __( 'H6', 'themedraft-core' ),
					'span' => __( 'SPAN', 'themedraft-core' ),
				],
				'condition' => [
					'title_one!' => '',
				],
			]
		);

		$this->add_control(
			'title_two',
			[
				'label'       => __( 'Title Two', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 5,
				'default'     => 'Digital Product.',
			]
		);

		$this->add_control(
			'title_two_tag',
			[
				'label'   => __( 'Title Two Tag', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'h2',
				'options' => [
					'h1' => __( 'H1', 'themedraft-core' ),
					'h2' => __( 'H2', 'themedraft-core' ),
					'h3' => __( 'H3', 'themedraft-core' ),
					'h4' => __( 'H4', 'themedraft-core' ),
					'h5' => __( 'H5', 'themedraft-core' ),
					'h6' => __( 'H6', 'themedraft-core' ),
					'span' => __( 'SPAN', 'themedraft-core' ),
				],
				'condition' => [
					'title_two!' => '',
				],
			]
		);

		$this->add_control(
			'insert_image',
			[
				'label'     => esc_html__( 'Insert Image', 'themedraft-core' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Yes', 'themedraft-core' ),
				'label_off' => esc_html__( 'No', 'themedraft-core' ),
				'default'   => 'yes',
			]
		);

		$this->add_control(
			'title_two_image',
			[
				'label'       => __( 'Title Two Image', 'themedraft-core' ),
				'type'        => Controls_Manager::MEDIA,
				'label_block' => true,
				'default'     => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'condition' => [
					'insert_image' => 'yes',
				],
			]
		);

		$this->add_control(
			'word_count',
			[
				'label'       => __( 'Word Count', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 0,
				'condition' => [
					'insert_image' => 'yes',
				],
				'description'       => __( 'After which number of word you want to show image.', 'themedraft-core' ),
			]
		);

		$this->add_control(
		    'desc',
		    [
		        'label'       => __( 'Description', 'themedraft-core' ),
		        'type'        => Controls_Manager::WYSIWYG,
		        'default'     => 'we are dedicated to transforming ideas into impactful realities. Our team of creative thinkers strategists and innovators collaborates to success.',
		        'label_block' => true,
		    ]
		);

		$this->add_control(
			'circle_btn_text',
			[
				'label'       => __( 'Circle Button Text', 'themedraft-core' ),
				'label_block'       => true,
				'type'        => Controls_Manager::TEXT,
				'default'     => 'get in touch - get in touch - get in touch -',
			]
		);

		$this->add_control(
			'circle_btn_url',
			[
				'label'         => __( 'Button URL', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
				'show_external' => true,
				'default'       => [
					'url'         => '#',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

        $this->add_control(
            'user_image',
            [
                'label'       => __( 'User Image', 'themedraft-core' ),
                'type'        => Controls_Manager::MEDIA,
                'label_block' => true,
                'default'     => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'user_image_btn_text',
            [
                'label'       => __( 'User Image Button Text', 'themedraft-core' ),
                'label_block'       => true,
                'type'        => Controls_Manager::TEXT,
                'default'     => 'Contact Our Experts',
            ]
        );

        $this->add_control(
            'user_image_btn_url',
            [
                'label'         => __( 'User Image Button URL', 'themedraft-core' ),
                'type'          => Controls_Manager::URL,
                'placeholder'   => __( 'https://your-link.com', 'themedraft-core' ),
                'show_external' => true,
                'default'       => [
                    'url'         => '',
                    'is_external' => false,
                    'nofollow'    => false,
                ],
            ]
        );

		$this->end_controls_section();

		$this->start_controls_section(
			'brand_slider_images',
			[
				'label' => __( 'Brand Images', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'enable_image_link',
			[
				'label'     => esc_html__( 'Enable Image Link', 'themedraft-core' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Yes', 'themedraft-core' ),
				'label_off' => esc_html__( 'No', 'themedraft-core' ),
				'default'   => 'no',
			]
		);

		//Repeater Start
		$repeater = new Repeater();

		$repeater->add_control(
			'brand_name',
			[
				'label'       => esc_html__( 'Brand Name', 'themedraft-core' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'description' => esc_html__( 'This field is optional.', 'themedraft-core' ),
			]
		);

		$repeater->add_control(
			'image',
			[
				'label'       => esc_html__( 'Image', 'themedraft-core' ),
				'description' => esc_html__( '', 'themedraft-core' ),
				'type'        => Controls_Manager::MEDIA,
				'default'     => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);

		$repeater->add_control(
			'image_link',
			[
				'label'         => esc_html__( 'Image Link', 'themedraft-core' ),
				'type'          => Controls_Manager::URL,
				'placeholder'   => esc_url( 'https://your-link.com' ),
				'show_external' => true,
				'default'       => [
					'url'         => '',
					'is_external' => false,
					'nofollow'    => false,
				],
			]
		);

		$this->add_control(
			'brands',
			[
				'label'       => esc_html__( 'Images', 'themedraft-core' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'title_field' => '{{{ brand_name }}}',
				'condition' => [
					'enable_image_link' => 'yes',
				],
			]
		);
		//Repeater End

		$this->add_control(
			'brand_images',
			[
				'label' => __( 'Add Images', 'themedraft-core' ),
				'type' => Controls_Manager::GALLERY,
				'default' => [],
				'condition' => [
					'enable_image_link!' => 'yes',
				],
			]
		);

		$this->add_control(
			'autoplay',
			[
				'label'       => __( 'Autoplay', 'themedraft-core' ),
				'type'        => Controls_Manager::SWITCHER,
				'show_label'  => true,
				'label_block' => false,
				'default'     => 'no',
			]
		);

		$this->add_control(
			'autoplay_interval',
			[
				'label'       => __( 'Autoplay Interval', 'themedraft-core' ),
				'type'        => Controls_Manager::SELECT,
				'show_label'  => true,
				'label_block' => false,
				'options'     => [
					'2000'  => __( '2 seconds', 'themedraft-core' ),
					'3000'  => __( '3 seconds', 'themedraft-core' ),
					'4000'  => __( '4 seconds', 'themedraft-core' ),
					'5000'  => __( '5 seconds', 'themedraft-core' ),
					'6000'  => __( '6 seconds', 'themedraft-core' ),
					'7000'  => __( '7 seconds', 'themedraft-core' ),
					'8000'  => __( '8 seconds', 'themedraft-core' ),
					'9000'  => __( '9 seconds', 'themedraft-core' ),
					'10000' => __( '10 seconds', 'themedraft-core' ),
				],
				'default'     => '4000',
				'condition'   => [
					'autoplay' => 'yes',
				],
			]
		);

		$this->add_control(
			'infinity_loop',
			[
				'label'       => __( 'Loop', 'themedraft-core' ),
				'type'        => Controls_Manager::SWITCHER,
				'show_label'  => true,
				'label_block' => false,
				'default'     => 'yes',
			]
		);

		$this->add_control(
			'desktop_count',
			[
				'label'   => __( 'Desktop Column', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 5,
				'options' => [
					1  => __( '1 Column', 'themedraft-core' ),
					2  => __( '2 Column', 'themedraft-core' ),
					3  => __( '3 Column', 'themedraft-core' ),
					4  => __( '4 Column', 'themedraft-core' ),
					5  => __( '5 Column', 'themedraft-core' ),
					6  => __( '6 Column', 'themedraft-core' ),
					7  => __( '7 Column', 'themedraft-core' ),
					8  => __( '8 Column', 'themedraft-core' ),
					9  => __( '9 Column', 'themedraft-core' ),
					10 => __( '10 Column', 'themedraft-core' ),
					11 => __( '11 Column', 'themedraft-core' ),
					12 => __( '12 Column', 'themedraft-core' ),
				],
			]
		);

		$this->add_control(
			'ipad_pro_count',
			[
				'label'   => __( 'Tablet Column', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 5,
				'options' => [
					1  => __( '1 Column', 'themedraft-core' ),
					2  => __( '2 Column', 'themedraft-core' ),
					3  => __( '3 Column', 'themedraft-core' ),
					4  => __( '4 Column', 'themedraft-core' ),
					5  => __( '5 Column', 'themedraft-core' ),
					6  => __( '6 Column', 'themedraft-core' ),
					7  => __( '7 Column', 'themedraft-core' ),
					8  => __( '8 Column', 'themedraft-core' ),
					9  => __( '9 Column', 'themedraft-core' ),
					10 => __( '10 Column', 'themedraft-core' ),
					11 => __( '11 Column', 'themedraft-core' ),
					12 => __( '12 Column', 'themedraft-core' ),
				],
			]
		);

		$this->add_control(
			'tab_count',
			[
				'label'   => __( 'Tablet Column', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 4,
				'options' => [
					1  => __( '1 Column', 'themedraft-core' ),
					2  => __( '2 Column', 'themedraft-core' ),
					3  => __( '3 Column', 'themedraft-core' ),
					4  => __( '4 Column', 'themedraft-core' ),
					5  => __( '5 Column', 'themedraft-core' ),
					6  => __( '6 Column', 'themedraft-core' ),
					7  => __( '7 Column', 'themedraft-core' ),
					8  => __( '8 Column', 'themedraft-core' ),
					9  => __( '9 Column', 'themedraft-core' ),
					10 => __( '10 Column', 'themedraft-core' ),
					11 => __( '11 Column', 'themedraft-core' ),
					12 => __( '12 Column', 'themedraft-core' ),
				],
			]
		);

		$this->add_control(
			'mobile_count',
			[
				'label'   => __( 'Mobile Column', 'themedraft-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 2,
				'options' => [
					1 => __( '1 Column', 'themedraft-core' ),
					2 => __( '2 Column', 'themedraft-core' ),
					3 => __( '3 Column', 'themedraft-core' ),
					4 => __( '4 Column', 'themedraft-core' ),
				],
			]
		);

		$this->add_responsive_control(
			'wrapper_height',
			[
				'label'     => __( 'Item Height', 'themedraft-core' ),
				'type'      => Controls_Manager::SLIDER,
				'range'     => [
					'px' => [
						'min' => 0,
						'max' => 1000,
					],
				],
				'devices'   => [ 'desktop', 'tablet', 'mobile' ],
				'description'   => __('Useful for different height\'s image.', 'themedraft-core' ),
				'selectors' => [
					'{{WRAPPER}} .td-brand-item.slick-slide' => 'height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .td-brand-images' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'enable_grayscale',
			[
				'label'     => esc_html__( 'Enable Grayscale', 'themedraft-core' ),
				'type'      => Controls_Manager::SWITCHER,
				'label_on'  => esc_html__( 'Yes', 'themedraft-core' ),
				'label_off' => esc_html__( 'No', 'themedraft-core' ),
				'default'   => 'no',
			]
		);

		$this->end_controls_section();

        $this->start_controls_section(
            'subtitle_style',
            [
                'label' => esc_html__( 'Subtitle', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
                'condition' => [
                    'subtitle!' => '',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'subtitle_typo',
                'label' => esc_html__( 'Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .td-hero-two-subtitle',
            ]
        );

		$this->add_group_control(
			Themedraft_Gradient_Color::get_type(),
			[
				'label' => esc_html__( 'Color', 'themedraft-core' ),
				'name' => 'subtitle_text_color_type',
				'selector' => '{{WRAPPER}} .td-hero-two-subtitle',
			]
		);

        $this->add_responsive_control(
            'subtitle_margin',
            [
                'label'      => esc_html__( 'Margin', 'themedraft-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .td-hero-two-subtitle' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'title_one_style',
            [
                'label' => esc_html__( 'Title One', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_one_typo',
                'label' => esc_html__( 'Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .td-hero-two-title-one',
            ]
        );

        $this->add_control(
            'title_one_color',
            [
                'label'       => esc_html__('Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-hero-two-title-one' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

		$this->start_controls_section(
			'title_two_style',
			[
				'label' => esc_html__( 'Title Two', 'themedraft-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_two_typo',
				'label' => esc_html__( 'Typography', 'themedraft-core' ),
				'selector' => '{{WRAPPER}} .td-hero-two-title-two',
			]
		);

		$this->add_group_control(
			Themedraft_Gradient_Color::get_type(),
			[
				'label' => esc_html__( 'Color', 'themedraft-core' ),
				'name' => 'title_two_color_type',
				'selector' => '{{WRAPPER}} .td-hero-two-title-two',
			]
		);

        $this->add_responsive_control(
            'title_two_img_height',
            [
                'label' => esc_html__( 'Image Height & Width', 'themedraft-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 100,
                        'max' => 300,
                    ],
                ],
                'devices' => [ 'desktop', 'tablet', 'mobile' ],

                'selectors' => [
                    '{{WRAPPER}} div .td-hero-two-title-two img' => 'width: {{SIZE}}px;height: {{SIZE}}px;',
                ],
            ]
        );

		$this->end_controls_section();

        $this->start_controls_section(
            'desc_style',
            [
                'label' => esc_html__( 'Description', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'desc_typo',
                'label' => esc_html__( 'Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .td-hero-two-right-desc',
            ]
        );

        $this->add_responsive_control(
            'desc_padding',
            [
                'label'      => esc_html__( 'Padding', 'themedraft-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .td-hero-two-bottom-right-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'desc_margin',
            [
                'label'      => esc_html__( 'Margin', 'themedraft-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .td-hero-two-right-desc' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'circle_btn_style',
            [
                'label' => esc_html__( 'Circle Button', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'circle_btn_typo',
                'label' => esc_html__( 'Typography', 'themedraft-core' ),
                'selector' => '{{WRAPPER}} .td-circle-button-one-wrapper',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'circle_btn_background',
                'label' => esc_html__( 'Background', 'themedraft-core' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .td-circle-button-one-wrapper',
                'exclude' => ['image'],
            ]
        );

		$this->add_responsive_control(
			'circle_btn_size',
			[
				'label' => esc_html__( 'Button Size', 'themedraft-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => ['px'],
				'range' => [
					'px' => [
						'min' => 100,
						'max' => 300,
					],
				],
				'devices' => [ 'desktop', 'tablet', 'mobile' ],

				'selectors' => [
					'{{WRAPPER}} .td-circle-button-one-wrapper' => 'width: {{SIZE}}px;height: {{SIZE}}px;',
				],
			]
		);

        $this->add_control(
            'circle_btn_color',
            [
                'label'       => esc_html__('Color', 'themedraft-core'),
                'type'        => Controls_Manager::COLOR,
                'selectors'   => [
                    '{{WRAPPER}} .td-circle-button-one-wrapper svg' => 'fill: {{VALUE}};',
                    '{{WRAPPER}} .td-circle-button-one-wrapper i' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'wrapper_style',
            [
                'label' => esc_html__( 'Wrapper', 'themedraft-core' ),
                'tab'   => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'wrapper_background',
                'label' => esc_html__( 'Background', 'themedraft-core' ),
                'types' => [ 'classic', 'gradient', 'video' ],
                'selector' => '{{WRAPPER}} .td-hero-two-wrapper',
            ]
        );

        $this->add_responsive_control(
            'wrapper_padding',
            [
                'label'      => esc_html__( 'Wrapper Padding', 'themedraft-core' ),
                'type'       => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors'  => [
                    '{{WRAPPER}} .td-hero-two-wrapper' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

	}


	//Render
	protected function render() {
		$settings = $this->get_settings_for_display();
		$subtitle       = $settings['subtitle'];
		$title_one       = $settings['title_one'];
		$title_two       = $settings['title_two'];
		$desc       = $settings['desc'];
		$slider_id = rand(100, 1000);
		?>
        <div class="td-hero-two-wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-xl-10">
                        <div class="td-hero-two-content-wrapper">
                            <span class="td-hero-two-subtitle wow td-top-to-bottom"><?php echo $subtitle;?></span>

                            <<?php echo $settings['title_one_tag'];?> class="td-hero-two-title-one wow td-top-to-bottom">
	                            <?php echo $title_one;?> <span class="td-hero-two-title-two-small-device"><?php echo $title_two;?></span>
                            </<?php echo $settings['title_one_tag'];?>>

                            <<?php echo $settings['title_two_tag'];?> class="td-hero-two-title-two wow td-top-to-bottom">
                                <?php if($settings['insert_image'] == 'yes'){
                                    $image_src = $settings['title_two_image']['url'];
                                    $image_alt = get_post_meta( $settings['title_two_image']['id'], '_wp_attachment_image_alt', true );
                                    $image_title = get_the_title( $settings['title_two_image']['id']);
                                    $word_position = $settings['word_count'];
                                    $words = explode(' ', $title_two);
                                    $image_html = '<img src="' . $image_src . '" alt="' . $image_alt . '" title="' . $image_title . '">';
                                    if (isset($words[$word_position])) {
                                        array_splice($words, $word_position, 0, $image_html);
                                    }
                                    $title = implode(' ', $words);
                                    echo $title;
                                }else{
                                    echo wp_kses( $title_two, bizkorp_allow_html() );
                                } ?>
                            </<?php echo $settings['title_two_tag'];?>>
                        </div>
                    </div>
                    <div class="col-xl-2 my-auto">
                        <div class="td-banner-two-circle-button wow td-top-to-bottom td-banner-two-circle-button-sm-hide">
                            <a href="<?php echo esc_url($settings['circle_btn_url']['url']);?>" class="td-circle-button-one-wrapper">
                                <i class="icon-button-arrow-one"></i>
                                <svg viewBox="0 0 100 100" class="td-spin-animation">
                                    <defs>
                                        <path id="td-circle-button-one" d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0"></path>
                                    </defs>
                                    <text>
                                        <textPath xlink:href="#td-circle-button-one">
	                                        <?php echo esc_html($settings['circle_btn_text']);?>
                                        </textPath>
                                    </text>
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xl-8">
                        <div class="td-hero-two-brand-slider-wrapper wow td-top-to-bottom">
                            <div class="td-brand-img-wrapper">
                                <div class="<?php if($settings['enable_grayscale'] == 'yes'){echo 'td-grayscale-enable';}?>">
                                    <div id="td-brand-slider-<?php echo $slider_id;?>" class="td-brand-images">
                                        <?php if($settings['enable_image_link'] == 'yes') : ?>

                                            <?php foreach ( $settings['brands'] as $brand ) :

                                                $target = $brand['image_link']['is_external'] ? ' target="_blank"' : '';
                                                $nofollow = $brand['image_link']['nofollow'] ? ' rel="nofollow"' : '';

                                                $image_src = $brand['image']['url'];
                                                $image_alt = get_post_meta( $brand['image']['id'], '_wp_attachment_image_alt', true );
                                                $image_title = get_the_title( $brand['image']['id']);

                                                $image_link = $brand['image_link']['url'];

                                                ?>
                                                <div class="td-brand-item">
                                                    <div class="td-table">
                                                        <div class="td-table-cell">
                                                            <?php if ( $image_link ) : ?>
                                                            <a href="<?php echo esc_url($image_link);?>" <?php echo $target . $nofollow;?>>
                                                                <?php endif; ?>

                                                                <img src="<?php echo esc_url($image_src); ?>" alt="<?php echo esc_attr($image_alt);?>" title="<?php echo esc_attr($image_title);?>">

                                                                <?php if ( $image_link ) : ?>
                                                            </a>
                                                        <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach;?>
                                        <?php else : ?>


                                            <?php foreach ($settings['brand_images'] as $brand ) :
                                                $image_src = $brand['url'];
                                                $image_alt = get_post_meta( $brand['id'], '_wp_attachment_image_alt', true );
                                                $image_title = get_the_title( $brand['id']);
                                                ?>
                                                <div class="td-brand-item">
                                                    <div class="td-table">
                                                        <div class="td-table-cell">
                                                            <img src="<?php echo esc_url($image_src);?>" alt="<?php echo esc_attr($image_alt);?>" title="<?php echo $image_title;?>">
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach;?>

                                        <?php endif; ?>
                                    </div>

                                </div>
                            </div>

                            <script>
                                (function ($) {
                                    "use strict";
                                    $(document).ready(function () {
                                        $("#td-brand-slider-<?php echo $slider_id;?>").slick({
                                            slidesToShow: <?php echo json_encode( $settings['desktop_count'] )?>,
                                            autoplay: <?php echo json_encode( $settings['autoplay'] == 'yes' ? true : false ); ?>,
                                            autoplaySpeed: <?php echo json_encode( $settings['autoplay_interval'] )?>, //interval
                                            speed: 1500, // slide speed
                                            dots: false,
                                            arrows: false,
                                            prevArrow: '<i class="slick-arrow slick-prev eicon-chevron-left"></i>',
                                            nextArrow: '<i class="slick-arrow slick-next eicon-chevron-right"></i>',
                                            infinite: <?php echo json_encode( $settings['infinity_loop'] == 'yes' ? true : false ); ?>,
                                            pauseOnHover: false,
                                            centerMode: false,
                                            responsive: [
                                                {
                                                    breakpoint: 1025,
                                                    settings: {
                                                        slidesToShow: <?php echo json_encode( $settings['ipad_pro_count'] )?>, // 992-1024
                                                        arrows: false,
                                                    }
                                                },
                                                {
                                                    breakpoint: 992,
                                                    settings: {
                                                        slidesToShow: <?php echo json_encode( $settings['tab_count'] )?>, //768-991
                                                    }
                                                },
                                                {
                                                    breakpoint: 768,
                                                    settings: {
                                                        slidesToShow: <?php echo json_encode( $settings['mobile_count'] )?>, // 0 -767
                                                    }
                                                }
                                            ]
                                        });
                                    });
                                })(jQuery);
                            </script>
                        </div>
                    </div>

                    <div class="col-xl-4">
                        <div class="td-hero-two-bottom-right-content">
                            <div class="td-hero-two-right-desc wow td-top-to-bottom td-last-p-0">
                                <?php echo $desc;?>
                            </div>

                            <div class="td-hero-two-users-and-buttons wow td-top-to-bottom">
                                <div class="td-banner-two-circle-button td-banner-two-circle-button-lg-hide">
                                    <a href="<?php echo esc_url($settings['circle_btn_url']['url']);?>" class="td-circle-button-one-wrapper">
                                        <i class="icon-button-arrow-one"></i>
                                        <svg viewBox="0 0 100 100" class="td-spin-animation">
                                            <defs>
                                                <path id="td-circle-button-one" d="M 50, 50 m -37, 0 a 37,37 0 1,1 74,0 a 37,37 0 1,1 -74,0"></path>
                                            </defs>
                                            <text>
                                                <textPath xlink:href="#td-circle-button-one">
	                                                <?php echo esc_html($settings['circle_btn_text']);?>
                                                </textPath>
                                            </text>
                                        </svg>
                                    </a>
                                </div>

                                <div class="td-hero-two-users">
                                    <?php
                                    $user_image_src = $settings['user_image']['url'];
                                    $user_image_alt = get_post_meta( $settings['user_image']['id'], '_wp_attachment_image_alt', true );
                                    $user_image_title = get_the_title( $settings['user_image']['id']);
                                    ?>
                                    <img src="<?php echo $user_image_src;?>" alt="<?php echo $user_image_alt;?>" title="<?php echo $user_image_title;?>">
                                    <a class="td-hero-two-user-text-button" href="<?php echo $settings['user_image_btn_url']['url'];?>"><?php echo $settings['user_image_btn_text'];?></a>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
		<?php

	}
}

Plugin::instance()->widgets_manager->register( new ThemeDraft_Hero_Banner_Two_Widget );