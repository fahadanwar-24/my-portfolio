<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/*
 *  Recent Post Widget
 */
require_once ('recent-post-widget.php');

/*
 *  Contact Info
 */
require_once ('contact-info-widget.php');

/*
 *  Custom Nav
 */
require_once ('custom-navigation-widget.php');

/*
 *  Sidebar Contact Info
 */
require_once ('sidebar-contact-info-widget.php');

/*
 * Download Button
 */
require_once ('download-button-widget.php');