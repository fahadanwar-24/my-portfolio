<?php

// Control core classes for avoid errors
if ( class_exists( 'CSF' ) ) {

	CSF::createWidget( 'themedraft_sidebar_contact_info', array(
		'title'       => esc_html__( 'ThemeDraft : Sidebar Contact Info Widget ', 'themedraft-core' ),
		'classname'   => 'themedraft_sidebar_contact_info_widget',
		'description' => esc_html__( 'Themedraft sidebar contact info widget.', 'themedraft-core' ),
		'fields'      => array(

			array(
				'id'    => 'title',
				'type'  => 'text',
				'title' => esc_html__( 'Title', 'themedraft-core' ),
			),

			array(
				'id'           => 'image',
				'type'         => 'media',
				'title'        => esc_html__('Background Image', 'themedraft-core'),
				'library'      => 'image',
				'url'          => false,
				'button_title' => esc_html__('Upload Image', 'themedraft-core'),

			),

			array(
				'id'    => 'big_title',
				'type'  => 'textarea',
				'title' => esc_html__( 'Big Title', 'themedraft-core' ),
				'default' => esc_html__('Feel Free to contact with us','themedraft-core' ),
			),

			array(
				'id'           => 'contact_info_text',
				'type'         => 'group',
				'title'        => esc_html__( 'Info Text', 'themedraft-core' ),
				'subtitle'     => esc_html__( 'Add / edit info text from here.', 'themedraft-core' ),
				'desc'         => esc_html__( 'Click "Add Info" button to add new Information.', 'themedraft-core' ),
				'button_title' => esc_html__( 'Add Info', 'themedraft-core' ),
				'fields'       => array(

					array(
						'id'            => 'contact_info_subtitle',
						'type'          => 'text',
						'title'         => esc_html__( 'Subtitle', 'themedraft-core' ),
						'default'         => esc_html__( 'Call Us', 'themedraft-core' ),
					),

					array(
						'id'            => 'contact_info',
						'type'          => 'wp_editor',
						'media_buttons' => false,
						'height'        => '80px',
						'title'         => esc_html__( 'Info Text', 'themedraft-core' ),
						'desc'          => esc_html__( 'Type info text here.', 'themedraft-core' ),
					),

					array(
						'id'    => 'contact_info_icon',
						'type'  => 'icon',
						'title' => esc_html__( 'Icon', 'themedraft-core' ),
						'desc'  => esc_html__( 'Select icon', 'themedraft-core' ),
					),


				),
				'default'      => array(
					array(
						'contact_info_subtitle' => 'Call Us',
						'contact_info' => '<a href="tel:+410123456789">+410 123 456 789</a>',
						'contact_info_icon' => 'flaticon-phone-call-1',
					),

					array(
						'contact_info_subtitle' => 'Email Us',
						'contact_info' => '<a href="mailto:noreplay@themedraft.net">info@themedraft.net</a>',
						'contact_info_icon' => 'flaticon-mail-inbox-app',
					),

					array(
						'contact_info_subtitle' => 'Visit Us',
						'contact_info' => 'Obere Haltenstrasse Switzerland.',
						'contact_info_icon' => 'flaticon-map-1',
					),
				),
			),
		)
	) );

	//
	// Front-end display of widget
	// Attention: This function named considering above widget base id.
	//
	if ( ! function_exists( 'themedraft_sidebar_contact_info' ) ) {
		function themedraft_sidebar_contact_info( $args, $instance ) {

			echo $args['before_widget'];

			if ( ! empty( $instance['title'] ) ) {
				echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
			}
			?>
			<div class="td-sidebar-contact-info-wrapper td-cover-bg" style="background-image: url(<?php echo $instance['image']['url'];?>)">
                <div class="td-sidebar-contact-info-wrapper-overlay"></div>

				<h4 class="td-sidebar-contact-info-big-title"><?php echo $instance['big_title'];?></h4>

				<ul class="td-list-style widget-sidebar-contact-info-list">
					<?php
					$contact_info_text = $instance['contact_info_text'];
					if(is_array($contact_info_text)){
						foreach ($contact_info_text as $contact){ ?>
							<li>
								<i class="<?php echo esc_attr($contact['contact_info_icon']);?>"></i>
                                <span class="td-sidebar-contact-info-subtitle"><?php echo esc_html($contact['contact_info_subtitle']);?></span>
                                <?php echo wp_kses_post($contact['contact_info']);?>
							</li>
							<?php
						}
					}
					?>
				</ul>
			</div>
			<?php
			echo $args['after_widget'];
		}
	}
}
