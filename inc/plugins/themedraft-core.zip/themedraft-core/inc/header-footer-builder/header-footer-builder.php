<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

function themedraft_register_header_footer_custom_post() {

	// Register Footer Builder Post Type
	register_post_type('bizkorp_header',
		array(
			'labels'       => array(
				'name'                  => esc_html__('Bizkorp Headers', 'themedraft-core'),
				'singular_name'         => esc_html__('Header', 'themedraft-core'),
				'add_new_item'          => esc_html__('Add New Header', 'themedraft-core'),
				'all_items'             => esc_html__('All Headers', 'themedraft-core'),
				'add_new'               => esc_html__('Add New', 'themedraft-core'),
				'edit_item'             => esc_html__('Edit Header', 'themedraft-core'),
			),
			'rewrite'      => array(
				'slug'       => 'header',
				'with_front' => true,
			),
			'hierarchical' => true,
			'public' => true,
			'show_ui' => true,
			'exclude_from_search' => true,
			'publicly_queryable' => true,
			'query_var'          => true,
			'has_archive'        => true,
			'menu_icon'    => 'dashicons-editor-kitchensink',
			'show_in_rest'    => false,
			'supports'     => array('title', 'editor'),
		)
	);

	// Register Footer Builder Post Type
	register_post_type('bizkorp_footer',
		array(
			'labels'       => array(
				'name'                  => esc_html__('Bizkorp Footers', 'themedraft-core'),
				'singular_name'         => esc_html__('Footer', 'themedraft-core'),
				'add_new_item'          => esc_html__('Add New Footer', 'themedraft-core'),
				'all_items'             => esc_html__('All Footers', 'themedraft-core'),
				'add_new'               => esc_html__('Add New', 'themedraft-core'),
				'edit_item'             => esc_html__('Edit Footer', 'themedraft-core'),
			),
			'rewrite'      => array(
				'slug'       => 'footer',
				'with_front' => true,
			),
			'hierarchical' => true,
			'public' => true,
			'show_ui' => true,
			'exclude_from_search' => true,
			'publicly_queryable' => true,
			'query_var'          => true,
			'has_archive'        => true,
			'menu_icon'    => 'dashicons-editor-kitchensink',
			'show_in_rest'    => false,
			'supports'     => array('title', 'editor'),
		)
	);
}

add_action( 'init', 'themedraft_register_header_footer_custom_post' );


/**
 *  Footer Canvas
 */
function themedraft_header_footer_builder_canvas() {
	global $post;

	// Check if its a correct post type/types to apply template
	if ( !in_array( $post->post_type, ['bizkorp_header','bizkorp_footer'] ) || !did_action( 'elementor/loaded' ) ) {
		return;
	}
	// Check that a template is not set already
	if ( '' !== $post->page_template ) {
		return;
	}
	// Make sure its not a page for posts
	if ( get_option( 'page_for_posts' ) === $post->ID ) {
		return;
	}

	//Finally set the page template
	$post->page_template = 'elementor_canvas';
	update_post_meta( $post->ID, '_wp_page_template', 'elementor_canvas' );
}

add_action( 'add_meta_boxes', 'themedraft_header_footer_builder_canvas', 10 );